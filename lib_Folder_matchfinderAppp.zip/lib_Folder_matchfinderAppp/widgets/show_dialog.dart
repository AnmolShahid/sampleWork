import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:matchfinder/const/const.dart';
import 'package:matchfinder/utils/style.dart';
import 'package:matchfinder/widgets/text_field.dart';

showPhotoAlertDialog(
    BuildContext context, screenSize, String btnText, Widget column, height,
    {Function onSave, Map params}) async {
  return await showGeneralDialog(
      barrierColor: Colors.black.withOpacity(0.5),
      transitionBuilder: (context, a1, a2, widget) {
        return StatefulBuilder(builder: (context, setState) {
          final curvedValue = Curves.easeInOutBack.transform(a1.value) - 1.0;
          return Transform(
            transform: Matrix4.translationValues(0.0, curvedValue * 200, 0.0),
            child: Opacity(
              opacity: a1.value,
              child: AlertDialog(
                // shape: OutlineInputBorder(
                //     borderRadius: BorderRadius.circular(16.0)),
                content: Container(
                  height: height + 50,
                  width: screenSize.width * 0.95,
                  child: new ListView(
                    padding: EdgeInsets.all(0),
                    children: <Widget>[
                      column,
                      SizedBox(
                        height: 20,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          GestureDetector(
                            onTap: onSave,
                            child: Container(
                              width: screenSize.width * 0.3,
                              color: greenBtn,
                              height: 50,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Text(btnText, style: smallWhiteTextStyle),
                                ],
                              ),
                            ),
                          ),
                          GestureDetector(
                            onTap: () => Navigator.pop(context),
                            child: Container(
                              width: screenSize.width * 0.3,
                              color: redBtn,
                              height: 50,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Text('Cancel', style: smallWhiteTextStyle),
                                ],
                              ),
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ),
            ),
          );
        });
      },
      transitionDuration: Duration(milliseconds: 200),
      barrierDismissible: true,
      barrierLabel: '',
      context: context,
      pageBuilder: (context, animation1, animation2) {});
}

showAlertDialog(
    BuildContext context, screenSize, String btnText, Widget column, height,
    {Function onSave, Map params, String btnText2, bool showButtons = true}) async {
  return await showGeneralDialog(
      barrierColor: Colors.black.withOpacity(0.5),
      transitionBuilder: (context, a1, a2, widget) {
        return StatefulBuilder(builder: (context, setState) {
          final curvedValue = Curves.easeInOutBack.transform(a1.value) - 1.0;
          return Transform(
            transform: Matrix4.translationValues(0.0, curvedValue * 200, 0.0),
            child: Opacity(
              opacity: a1.value,
              child: AlertDialog(
                // shape: OutlineInputBorder(
                //     borderRadius: BorderRadius.circular(16.0)),
                content: Container(
                  height: height,
                  width: screenSize.width * 0.95,
                  child: new ListView(
                    padding: EdgeInsets.all(0),
                    children: <Widget>[
                      column,
                      SizedBox(
                        height: 20,
                      ),
                      !showButtons ? Container() : Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          GestureDetector(
                            onTap: onSave,
                            child: Container(
                              width: screenSize.width * 0.3,
                              color: greenBtn,
                              height: 50,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Text(btnText, style: smallWhiteTextStyle),
                                ],
                              ),
                            ),
                          ),
                          GestureDetector(
                            onTap: () => Navigator.pop(context),
                            child: Container(
                              width: screenSize.width * 0.3,
                              color: redBtn,
                              height: 50,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Text(btnText2 == null ? 'Cancel' : btnText2, style: smallWhiteTextStyle),
                                ],
                              ),
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ),
            ),
          );
        });
      },
      transitionDuration: Duration(milliseconds: 200),
      barrierDismissible: true,
      barrierLabel: '',
      context: context,
      pageBuilder: (context, animation1, animation2) {});
}

showExpressInterestDialog(
    BuildContext context, screenSize, searchController, String btnText, height,
    {Function onSave, Map params, String btnText2, bool showButtons = true}) async {

  List<String> options = ['I like your profile. Let me know your interest',
    'I think we make a perfect match. I am serious about your profile',
    'My family likes your profile. We would like to take this forward with your parents!',
    'Our preferences match. Let me know your interest'];
  String selectedOption = '';

  return await showGeneralDialog(
      barrierColor: Colors.black.withOpacity(0.5),
      transitionBuilder: (context, a1, a2, widget) {
        return StatefulBuilder(builder: (context, setState) {
          final curvedValue = Curves.easeInOutBack.transform(a1.value) - 1.0;
          return Transform(
            transform: Matrix4.translationValues(0.0, curvedValue * 200, 0.0),
            child: Opacity(
              opacity: a1.value,
              child: AlertDialog(
                // shape: OutlineInputBorder(
                //     borderRadius: BorderRadius.circular(16.0)),
                content: Container(
                  height: height,
                  width: screenSize.width * 0.95,
                  child: new ListView(
                    padding: EdgeInsets.all(0),
                    children: <Widget>[
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text(
                                'Express Interest',
                                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                              ),
                              Container(
                                child: InkWell(
                                  child: Icon(
                                    Icons.close,
                                    color: black,
                                  ),
                                  onTap: () {
                                    Navigator.of(context).pop();
                                  },
                                ),
                              )
                            ],
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          TextFormField(
                            controller: searchController,
                            keyboardType: TextInputType.text,
                            autofocus: false,
                            maxLines: 2,
                            onChanged: (val) {},
                            decoration: InputDecoration(
                              // border: InputBorder.none,
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(color: greyColor, width: 1),
                              ),
                              labelText: 'Upgrade Plan to write Custom message',
                              contentPadding: const EdgeInsets.all(10.0),
                              labelStyle: TextStyle(
                                color: Colors.grey,
                              ),
                            ),
                          ),
                          ListView.builder(
                              shrinkWrap: true,
                              primary: false,
                              itemCount: options.length,
                              itemBuilder: (context, index){
                                return Container(
                                  child: Row(
                                    children: [
                                      Radio(
                                        value: options[index],
                                        groupValue: selectedOption,
                                        activeColor: appColor,
                                        onChanged: (String value) {
                                          setState(() {
                                            selectedOption = options[index];
                                          });
                                        },
                                      ),
                                      Expanded(child: Text(options[index], style: TextStyle(fontSize: 14),)),
                                    ],
                                  ),
                                );
                              })
                        ],
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      !showButtons ? Container() : Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          GestureDetector(
                            onTap: onSave,
                            child: Container(
                              width: screenSize.width * 0.3,
                              color: greenBtn,
                              height: 50,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Text(btnText, style: smallWhiteTextStyle),
                                ],
                              ),
                            ),
                          ),
                          GestureDetector(
                            onTap: () => Navigator.pop(context),
                            child: Container(
                              width: screenSize.width * 0.3,
                              color: greenBtn,
                              height: 50,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Text(btnText2 == null ? 'Cancel' : btnText2, style: smallWhiteTextStyle),
                                ],
                              ),
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ),
            ),
          );
        });
      },
      transitionDuration: Duration(milliseconds: 200),
      barrierDismissible: true,
      barrierLabel: '',
      context: context,
      pageBuilder: (context, animation1, animation2) {});
}

showAlert(BuildContext context, String text, {Function onPressed}) async {
  return await showGeneralDialog(
      barrierColor: Colors.black.withOpacity(0.5),
      transitionBuilder: (context, a1, a2, widget) {
        return StatefulBuilder(builder: (context, setState) {
          final curvedValue = Curves.easeInOutBack.transform(a1.value) - 1.0;
          return Transform(
            transform: Matrix4.translationValues(0.0, curvedValue * 200, 0.0),
            child: Opacity(
              opacity: a1.value,
              child: AlertDialog(
                shape: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16.0)),
                content: new Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Column(
                      children: <Widget>[
                        SizedBox(
                          height: 10,
                        ),
                        Text(
                          text,
                          style: TextStyle(
                            fontSize: 14,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        new Padding(
                          padding: const EdgeInsets.only(bottom: 20),
                        ),
                      ],
                    ),
                    RaisedButton(
                      color: appColor,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(25.0),
                      ),
                      onPressed: () {
                        if (onPressed == null) {
                          Navigator.pop(context);
                        } else {
                          onPressed();
                        }
                        //onPressed??Navigator.pop(context);
                      },
                      padding: EdgeInsets.all(12),
                      child: Text('OK',
                          style: TextStyle(color: Colors.white, fontSize: 14)),
                    ),
                  ],
                ),
              ),
            ),
          );
        });
      },
      transitionDuration: Duration(milliseconds: 200),
      barrierDismissible: false,
      barrierLabel: '',
      context: context,
      pageBuilder: (context, animation1, animation2) {});
}
