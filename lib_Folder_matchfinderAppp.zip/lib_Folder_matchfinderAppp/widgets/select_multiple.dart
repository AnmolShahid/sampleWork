import 'package:flutter/material.dart';
import 'package:matchfinder/const/const.dart';

class SelectMultiple extends StatefulWidget {
  var list, selectedItems;

  SelectMultiple(this.list, this.selectedItems);

  SelectMultipleState createState() => SelectMultipleState();
}

class SelectMultipleState extends State<SelectMultiple> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  TextEditingController _textController = TextEditingController();

  List newDataList;
  String selectedItems = '';
  List<String> selectedItemIds = [];

  @override
  initState(){
    newDataList = widget.list;
    selectedItems = widget.selectedItems;
    var tempList = selectedItems.split(',');
    for(var i=0;i<tempList.length-1;i++){
      var index = newDataList.indexWhere((element) => element[1] == tempList[i].trim());
      if(index > -1){
        var obj = newDataList[index];
        selectedItemIds.add(obj[0]);
        newDataList.removeAt(index);
        newDataList.insert(0, obj);
      }
    }
    super.initState();
  }

  onItemChanged(String value) {
    newDataList = [];
    setState(() {
      casteList.forEach((element) {
        if (element.toString().toLowerCase().contains(value)) {
          setState(() {
            newDataList.add(element);
          });
        }
      });
    });
  }

  buildAppBar(BuildContext context) {
    return AppBar(
      // shadowColor: appColor,
      backgroundColor: Colors.transparent,
      elevation: 0,
      automaticallyImplyLeading: false,
      leading: IconButton(
        icon: Icon(
          Icons.arrow_back,
          color: appColor,
        ),
        onPressed: () {
          Navigator.pop(context);
        },
      ),
      actions: [
        Container(
          padding: EdgeInsets.all(10),
          child: RaisedButton(
            onPressed: () {
              if(selectedItems.endsWith(", ")){
                selectedItems = selectedItems.substring(0, selectedItems.length-2);
              }
              Navigator.pop(context, [selectedItems, selectedItemIds.join(',')]);
            },
            child: Text(
              'Done',
              style: TextStyle(color: white),
            ),
            color: appColor,
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: buildAppBar(context),
      body: SafeArea(
        child: Column(
          children: <Widget>[
            // Row(
            //   mainAxisAlignment: MainAxisAlignment.end,
            //   children: [
            //     RaisedButton(
            //       onPressed: () {
            //         if(selectedItems.endsWith(", ")){
            //           selectedItems = selectedItems.substring(0, selectedItems.length-2);
            //         }
            //         Navigator.pop(context, selectedItems);
            //       },
            //       child: Text(
            //         'Done',
            //         style: TextStyle(color: white),
            //       ),
            //       color: appColor,
            //     ),
            //     SizedBox(
            //       width: 10,
            //     )
            //   ],
            // ),
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: TextField(
                controller: _textController,
                decoration: InputDecoration(
                  hintText: 'Search Here...',
                ),
                onChanged: onItemChanged,
              ),
            ),
            Expanded(
              child: ListView(
                padding: EdgeInsets.all(12.0),
                children: newDataList.map((data) {
                  return Card(
                    color: selectedItemIds.contains(data[0]) ? Colors.grey : Colors.white,
                    child: ListTile(
                      title: Text(data[1]),
                      onTap: () {
                        setState(() {
                          if(selectedItemIds.contains(data[0])){
                            selectedItems = selectedItems.replaceFirst(data[1]+", ", "");
                            selectedItemIds.remove(data[0]);
                          }
                          else{
                            selectedItems += data[1] + ', ';
                            selectedItemIds.add(data[0]);
                            // var index = newDataList.indexWhere((element) => element == data);
                            // print(index);
                            // newDataList.removeAt(index);
                            // newDataList.insert(0, data);
                          }
                        });
                        // print(selectedItems);
                      },
                    ),
                  );
                }).toList(),
              ),
            )
          ],
        ),
      ),
    );
  }
}
