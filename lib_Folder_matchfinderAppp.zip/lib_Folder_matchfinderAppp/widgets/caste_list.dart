import 'package:flutter/material.dart';
import 'package:matchfinder/const/const.dart';

class ListSearch extends StatefulWidget {
  ListSearchState createState() => ListSearchState();
}

class ListSearchState extends State<ListSearch> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  TextEditingController _textController = TextEditingController();

  List newDataList = casteList;

  onItemChanged(String value) {
    newDataList=[];
    setState(() {
      casteList.forEach((element) {
        if(element.toString().toLowerCase().contains(value)){
          setState(() {
            newDataList.add(element);
          });
        }
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      body: SafeArea(
        child: Column(
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                RaisedButton(onPressed:(){
                  Navigator.pop(context);
                },child:Text('Done',style: TextStyle(color: white),),color: appColor,),
                SizedBox(width: 10,)
              ],
            ),
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: TextField(
                controller: _textController,
                decoration: InputDecoration(
                  hintText: 'Search Here...',
                ),
                onChanged: onItemChanged,
              ),
            ),
            Expanded(
              child: ListView(
                padding: EdgeInsets.all(12.0),
                children: newDataList.map((data) {
                  return Card(
                    child: ListTile(
                      title: Text(data[1]),
                      onTap: (){

                        setState(() {
                          if(!preferCast.contains(data)){
                            preferCast.add(data);
                            newDataList.remove(data);
                            _scaffoldKey.currentState.showSnackBar(SnackBar(content: Text("cast: ${data[1]} added")));
                          }
                          else{
                            _scaffoldKey.currentState.showSnackBar(SnackBar(content: Text("Already added")));
                          }
                        });
                        print(data[1]);
                      },),
                  );
                }).toList(),
              ),
            )
          ],
        ),
      ),
    );
  }
}