import 'package:flutter/material.dart';
import 'package:matchfinder/const/const.dart';

class NoRecordFound extends StatelessWidget {
  final String msg;

  NoRecordFound({this.msg = ''});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
          padding: EdgeInsets.symmetric(vertical: 15.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                    msg.isEmpty ? "No Record Found!" : msg,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                      color: black,
                    ),
                  ),
            ],
          )),
    );
  }
}
