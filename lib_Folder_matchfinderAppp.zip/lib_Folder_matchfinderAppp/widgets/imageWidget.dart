import 'dart:convert';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ImageWidget extends StatelessWidget {
  String name;
  String image;
  double height;
  double radius;
  double width;

  ImageWidget(
      {this.name,
        this.image = '',
        this.radius = 10,
      this.width = 80,
      this.height = 60});

  @override
  Widget build(BuildContext context) {

    return image.contains('http') ? CachedNetworkImage(
      imageUrl: image,
      placeholder: (context, url) =>
          Image.asset('assets/sample_image.png'),
      imageBuilder: (context, imageProvider) => Container(
        width: width,
        height: height,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius??10.0),
          image: DecorationImage(
            image: imageProvider,
            fit: BoxFit.cover,
          ),
        ),
      )
    ) :
    Container(
        width: width,
        height: height,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(radius??10.0),
            image: DecorationImage(
                image:
                image.contains('assets') || image == ''
                    ? AssetImage(image)
                    : MemoryImage(base64Decode(image)),
                fit: BoxFit.fill)),
    );
  }
}
