import 'package:flutter/material.dart';
import 'package:matchfinder/const/const.dart';

class SearchCast extends StatefulWidget {
  SearchCastState createState() => SearchCastState();
}

class SearchCastState extends State<SearchCast> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  TextEditingController _textController = TextEditingController();

  List newDataList = casteList;

  onItemChanged(String value) {
    newDataList=[];
    setState(() {
      casteList.forEach((element) {
        if(element.toString().toLowerCase().contains(value)){
          setState(() {
            newDataList.add(element);
          });
        }
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      body: SafeArea(
        child: Column(
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                RaisedButton(onPressed:(){
                  Navigator.pop(context,_textController.text.trim());
                },child:Text('Done',style: TextStyle(color: white),),color: appColor,),
                SizedBox(width: 10,)
              ],
            ),
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: TextField(
                controller: _textController,
                decoration: InputDecoration(
                  hintText: 'Search Here...',
                ),
                onChanged: onItemChanged,
              ),
            ),
            Expanded(
              child: ListView(
                padding: EdgeInsets.all(12.0),
                children: newDataList.map((data) {
                  return Card(
                    child: ListTile(
                      title: Text(data[1]),
                      onTap: (){
                        Navigator.pop(context,data[1]);
                      },),
                  );
                }).toList(),
              ),
            )
          ],
        ),
      ),
    );
  }
}