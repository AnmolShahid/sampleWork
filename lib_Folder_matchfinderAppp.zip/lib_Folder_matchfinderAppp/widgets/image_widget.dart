import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

class AssetImageWidget extends StatelessWidget {
  String image;
  double height;
  Color color;
  double width;

  AssetImageWidget(
      {this.image = '',
        this.color,
        this.width = 30,
        this.height = 30});

  @override
  Widget build(BuildContext context) {
    return SvgPicture.asset(
        image,
        color: color,
        width: width,
        height: height
    );
    // return Image.asset(image, width: width, height: height,);
  }
}