import 'package:flutter/material.dart';
import 'package:matchfinder/const/const.dart';
import 'package:matchfinder/utils/style.dart';

class Button extends StatelessWidget {
  Button({
    @required this.text,
    @required this.onPressed,
  });

  final String text;
  final Function onPressed;

  @override
  Widget build(BuildContext context) {
    return MaterialButton(
      onPressed: onPressed,
      color: appColor,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(23.0),
      ),
      child: Container(
        padding: EdgeInsets.symmetric(
          vertical: 14,
          horizontal: 69,
        ),
        child: Text(
          text,
          textAlign: TextAlign.center,
          style: smallWhiteTextStyle,
        ),
      ),
    );
  }

}