import 'dart:core';
import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'package:matchfinder/const/const.dart';
import 'package:matchfinder/utils/style.dart';

class AppDrawer extends StatefulWidget {
  final context;
  final String heading;
  final Function onSave;
  final Widget list;
  bool showHeader;
  bool showButtons;

  @override
  AppDrawer({this.context, this.heading, this.list, this.onSave, this.showHeader = true, this.showButtons = true});
  _AppDrawerState createState() => new _AppDrawerState();
}

class _AppDrawerState extends State<AppDrawer> {

  @override
  void initState() {
    super.initState();
  }

  Widget build(BuildContext context) {

    var screenSize = MediaQuery.of(context).size;
    return SafeArea(
      child: new Container(
        width: screenSize.width * 0.9,
        child: Drawer(
          child: Padding(
            padding: const EdgeInsets.all(25),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                widget.showHeader ?
                Column(
                  children: [
                    Text(widget.heading,
                        style: smallGreyTextStyle),
                    SizedBox(
                      height: 10,
                    ),
                    Divider(color: greyColor),
                  ],
                ) : Container(),
                SizedBox(
                  height: 10,
                ),
                Expanded(child: widget.list),
                widget.showButtons ? Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    GestureDetector(
                      onTap: widget.onSave,
                      child: Container(
                        width: screenSize.width * 0.35,
                        color: greenBtn,
                        height: 60,
                        child: Center(child: Text('Save', style: headingWhiteTextStyle)),
                      ),
                    ),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        width: screenSize.width * 0.35,
                        color: redBtn,
                        height: 60,
                        child: Center(child: Text('Cancel', style: headingWhiteTextStyle)),
                      ),
                    ),
                  ],
                ) : Container()
              ],
            ),
          )
        ),
      ),
    );
  }
}
