import 'dart:async';
import 'package:flutter/material.dart';
import 'package:matchfinder/const/const.dart';
import 'package:matchfinder/const/general_methods.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'mainScreen.dart';

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  startTime() async {
    var _duration = Duration(seconds: 2);
    // final prefs = await SharedPreferences.getInstance();

    return Timer(_duration, navigationPage);
  }

  void navigationPage() {
    changeScreenReplacement(context, MainScreen());
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    startTime();
  }

  @override
  Widget build(BuildContext context) {
//FlutterStatusbarcolor.setStatusBarColor(Colors.transparent);
    return Scaffold(
      backgroundColor: appColor,
      body: GestureDetector(
        // onTap: () => navigationPage(),
        child: Padding(
          padding: const EdgeInsets.all(30.0),
          child: Center(child: Image.asset('assets/logowhite.png')),
        ),
      ),
    );
  }
}
