import 'package:flutter/material.dart';
import 'package:matchfinder/const/general_methods.dart';
import 'package:matchfinder/core/auth/login.dart';
import 'package:matchfinder/core/auth/register.dart';
import 'package:matchfinder/const/const.dart';
import './../../utils/clip_path.dart';
import 'package:matchfinder/utils/style.dart';

class MainScreen extends StatefulWidget {
  @override
  _MainScreenState createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appColor,

      body: Column(
            children: [
              ClipPath(
                clipper: CustomClipPath(),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height/1.1,
                  color: white,
                  child: buildColumn(context),
                ),
              ),
              buildGestureDetector(context),
            ],
          ),
    );
  }

  buildColumn(BuildContext context) {
    return Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Spacer(),
                    SizedBox(
                      height: 30,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          'Most Affordable Matrimony',
                          style: headingItalicTextStyle,
                        ),
                      ],
                    ),
                    Spacer(),
                    Image.asset(
                      'assets/drum.png',
                      fit: BoxFit.fitWidth,
                      height: 160,
                    ),
                    Spacer(),
                    Text(
                      'New User?',
                      style: headingAppColorTextStyle,
                    ),
                    SizedBox(
                      height: 15,
                    ),

                    RaisedButton(
                      onPressed: ()async{
                      changeScreen(context, Register());
                      },
                      color:appColor,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(18.0),
                          side: BorderSide(color: appColor)
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          '        Register Here        ',
                          style: headingWhiteTextStyle,
                        ),
                      ),
                    ),
                    SizedBox(height: 18,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        buildCircle( HexColor('EEECEC')),
                        buildCircle( HexColor('D1CECE')),
                        buildCircle( HexColor('D1CECE')),
                        buildCircle(HexColor('D1CECE')),

                      ],
                    ),
                  ],
                );
  }

  buildGestureDetector(BuildContext context) {
    return GestureDetector(
              onTap: ()=> changeScreenReplacement(context, Login()),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Already have an account?',
                    style: smallWhiteTextStyle,
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(
                        24,
                      ),
                      border: Border.all(
                        color: white,
                        width: 1,
                      ),
                    ),
                    padding: EdgeInsets.symmetric(
                        vertical: 8, horizontal: 25),
                    child: Text(
                      'Login',
                      style: smallWhiteTextStyle,
                    ),
                  ),
                ],
              ),
            );
  }

  buildCircle(Color color) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(
          90,
        ),
        color:color,
      ),
      margin: EdgeInsets.only(
        bottom: 70,
        right: 10,
      ),
      padding: EdgeInsets.all(
        8,
      ),
    );
  }
}
