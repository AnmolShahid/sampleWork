import 'package:expandable_bottom_sheet/expandable_bottom_sheet.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_swiper/flutter_swiper.dart';
import 'package:matchfinder/const/const.dart';
import 'package:matchfinder/const/general_methods.dart';
import 'package:matchfinder/core/home/match_profile.dart';
import 'package:matchfinder/model/profile_list.dart';
import 'package:matchfinder/utils/appBar.dart';
import 'package:matchfinder/utils/style.dart';
import 'package:matchfinder/widgets/imageWidget.dart';
import 'package:matchfinder/widgets/image_widget.dart';

class PhotoView extends StatefulWidget {

  String photo;
  PhotoView(this.photo);

  @override
  _PhotoViewState createState() => _PhotoViewState();
}

class _PhotoViewState extends State<PhotoView> {
  // TextEditingController searchController = new TextEditingController();
  // List<dynamic> _profiles = new List<dynamic>();
  // var _menus = List<Map<String, dynamic>>();
  // var _options = List<Map<String, dynamic>>();
  var selectedIndex = 0;
  var picWidth = 0;
  var picHeight = 0;
  bool isLoading = true;
  var _index = 0;

  @override
  void initState() {
    // _menus.add({
    //   'title': 'All PhotoView',
    //   'filter': 'all',
    // });
    // _menus.add({
    //   'title': 'Daily PhotoView',
    //   'filter': 'daily',
    // });
    // _menus.add({
    //   'title': 'Weekly PhotoView',
    //   'filter': 'weekly',
    // });
    // _menus.add({
    //   'title': 'Blocked',
    //   'filter': 'blocked',
    // });
    // _menus.add({
    //   'title': 'Shortlisted',
    //   'filter': 'shortlisted',
    // });
    // _menus.add({
    //   'title': 'Ignored',
    //   'filter': 'ignored',
    // });
    //
    // _options.add({
    //   'title': 'Chat',
    //   'icon': 'assets/chat_msgs.svg',
    // });
    // _options.add({'title': 'Horoscope', 'icon': 'assets/horoscope.svg'});
    // _options.add({
    //   'title': 'Call',
    //   'icon': 'assets/call.svg',
    // });
    // _options.add({
    //   'title': 'Block',
    //   'icon': 'assets/remove_user.svg',
    // });
    // _options.add({
    //   'title': 'Request Photo',
    //   'icon': 'assets/request_photo.svg',
    // });
    // _options.add({
    //   'title': 'Photo Password',
    //   'icon': 'assets/photo_password.svg',
    // });
    // _options.add({
    //   'title': 'Request Horoscope',
    //   'icon': 'assets/request_horoscope.svg',
    // });
    // getPhotoView('all');
    getHeight();
    super.initState();
  }

  getHeight() async {
    var img = await rootBundle.load(widget.photo);
    var decodedImage = await decodeImageFromList(img.buffer.asUint8List());
    picWidth = decodedImage.width;
    picHeight = decodedImage.height;
    // print(decodedImage.width);
    // print(decodedImage.height);
    setState(() { });
  }

  // getPhotoView(filter) {
  //   _profiles.clear();
  //   _profiles.add({
  //     'id': 'T5869321',
  //     'name': 'Sri Lallitha',
  //     'photoUrl': "assets/1.jpg",
  //     'Age': '26 Yrs, 5\'2"',
  //     'Religion': 'Hindu, Brahmin',
  //     'Star': 'Moola',
  //     'Location': 'Hyderabad Tala, India',
  //     'Education': 'BSc IT / Computer science',
  //     'Profession': 'Banking Professional',
  //   });
  //   _profiles.add({
  //     'id': 'T5869321',
  //     'name': 'Sri Lallitha',
  //     'photoUrl': "assets/1.jpg",
  //     'Age': '26 Yrs, 5\'2"',
  //     'Religion': 'Hindu, Brahmin',
  //     'Star': 'Moola',
  //     'Location': 'Hyderabad Tala, India',
  //     'Education': 'BSc IT / Computer science',
  //     'Profession': 'Banking Professional',
  //   });
  //   _profiles.add({
  //     'id': 'T5869321',
  //     'name': 'Sri Lallitha',
  //     'photoUrl': "assets/1.jpg",
  //     'Age': '26 Yrs, 5\'2"',
  //     'Religion': 'Hindu, Brahmin',
  //     'Star': 'Moola',
  //     'Location': 'Hyderabad Tala, India',
  //     'Education': 'BSc IT / Computer science',
  //     'Profession': 'Banking Professional',
  //   });
  // }

  @override
  Widget build(BuildContext context) {
    var screenSize = MediaQuery.of(context).size;

    // print(screenSize.width);

    return Scaffold(
        appBar: AppBarWidget(
          heading: 'View Profile',
          showIcon: true,
        ),
        body: Container(
          color: white,
          child: Column(
            children: [
              picWidth.toDouble() * 1.2 > screenSize.width ? SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                  child: Container(
                    height: picHeight.toDouble() * 1.2,
                    width: picWidth.toDouble() * 1.2,
                    child: Swiper(
                    loop: true,
                    itemCount: 3,
                    control: SwiperControl(
                        color: grey,
                        padding: EdgeInsets.only(left: 15, right: 15),
                        size: 40),
                    itemBuilder: (BuildContext context, int index) {
                      return Container(
                        color: backGroundColor,
                        margin: EdgeInsets.only(right: 5, left: 5),
                        alignment: Alignment.center,
                        child: ImageWidget(
                          width: picWidth.toDouble() * 1.2,
                          height: picHeight.toDouble() * 1.2,
                          image: widget.photo,
                        ),
                      );
                    },
                    // viewportFraction: 0.8,
                    // scale: 0.6,
                    index: _index,
                    onIndexChanged: (index) {
                      setState(() {
                        _index = index;
                      });
                    },
                    pagination: new SwiperPagination(
                      margin: new EdgeInsets.only(bottom: 30.0),
                      alignment: Alignment.bottomCenter,
                      builder: new DotSwiperPaginationBuilder(
                          color: grey, activeColor: appColor),
                    ),
                  ),
                  )
              ) :
              Container(
                height: picHeight.toDouble() * 1.2,
                width: picWidth.toDouble() * 1.2,
                child: Swiper(
                  loop: true,
                  itemCount: 3,
                  control: SwiperControl(
                      color: grey,
                      padding: EdgeInsets.only(left: 10, right: 5),
                      size: 40),
                  itemBuilder: (BuildContext context, int index) {
                    return Container(
                      color: backGroundColor,
                      alignment: Alignment.center,
                      child: ImageWidget(
                        width: picWidth.toDouble() * 1.2,
                        height: picHeight.toDouble() * 1.2,
                        image: widget.photo,
                      ),
                    );
                  },
                  // viewportFraction: 0.8,
                  scale: 0.6,
                  index: _index,
                  onIndexChanged: (index) {
                    setState(() {
                      _index = index;
                    });
                  },
                  pagination: new SwiperPagination(
                    margin: new EdgeInsets.only(bottom: 30.0),
                    alignment: Alignment.bottomCenter,
                    builder: new DotSwiperPaginationBuilder(
                        color: grey, activeColor: appColor),
                  ),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Container(
                padding: EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: backGroundColor,
                  border: Border.all(
                    width: 2.00,
                    color: grey,
                  ),
                  borderRadius: BorderRadius.circular(20.00),
                ),
                child: Text(
                    'This is text. This is text. This is text. This is text.'),
              ),
              SizedBox(
                height: 20,
              ),
              Align(
                alignment: Alignment.topRight,
                child: Container(
                  width: 50,
                  alignment: Alignment.center,
                  margin: EdgeInsets.all(5),
                  padding: EdgeInsets.all(5),
                  decoration: BoxDecoration(
                    color: appColor,
                    borderRadius: BorderRadius.circular(5.00),
                  ),
                  child: Text(
                    (_index+1).toString()+'/3',
                    style: TextStyle(color: white),
                  ),
                ),
              )
            ],
          ),
        ));
  }
}
