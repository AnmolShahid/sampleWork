import 'package:expandable_bottom_sheet/expandable_bottom_sheet.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_swiper/flutter_swiper.dart';
import 'package:matchfinder/const/const.dart';
import 'package:matchfinder/const/general_methods.dart';
import 'package:matchfinder/core/home/photos.dart';
import 'package:matchfinder/core/home/viewPhoto.dart';
import 'package:matchfinder/utils/appBar.dart';
import 'package:matchfinder/utils/style.dart';
import 'package:matchfinder/widgets/imageWidget.dart';
import 'package:matchfinder/widgets/image_widget.dart';
import 'package:matchfinder/widgets/material_button.dart';

class MatchProfile extends StatefulWidget {
  var profile;
  MatchProfile({this.profile});
  @override
  _MatchProfileState createState() => _MatchProfileState();
}

class _MatchProfileState extends State<MatchProfile> {
  var _index = 0;
  var picWidth = 0;
  var picHeight = 0;

  @override
  void initState() {
    getHeight();
    super.initState();
  }

  getHeight() async {
    var img = await rootBundle.load(widget.profile['photoUrl_500']);
    var decodedImage = await decodeImageFromList(img.buffer.asUint8List());
    picWidth = decodedImage.width;
    picHeight = decodedImage.height;
    // print(decodedImage.width);
    // print(decodedImage.height);
    setState(() { });
  }

  @override
  Widget build(BuildContext context) {
    var screenSize = MediaQuery.of(context).size;

    return Scaffold(
        appBar: AppBarWidget(
          heading: '',
          showIcon: true,
          color: white,
          actions: [
            AssetImageWidget(
              image: 'assets/chat.svg',
              color: greyColor,
            ),
            SizedBox(
              width: 20,
            ),
            AssetImageWidget(image: 'assets/horoscope.svg'),
            SizedBox(
              width: 20,
            ),
            AssetImageWidget(image: 'assets/call.svg'),
            SizedBox(
              width: 20,
            ),
            AssetImageWidget(image: 'assets/remove_user.svg'),
            SizedBox(
              width: 20,
            ),
          ],
        ),
        body: Container(
          color: white,
          child: Column(
            children: [
              Expanded(
                child: ExpandableBottomSheet(
                  background: Container(
                      // height: screenSize.height * 0.55,
                      child: GestureDetector(
                        child: picWidth.toDouble() * 1.2 > screenSize.width ? SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Container(
                            child: ImageWidget(
                                height: picHeight.toDouble() * 1.2,
                                width: picWidth.toDouble() * 1.2,
                                image: widget.profile['photoUrl_500']),
                          ),
                        ) : Container(
                          // width: screenSize.width,
                          child: ImageWidget(
                              height: picHeight.toDouble() * 1.2,
                              width: picWidth.toDouble() * 1.2,
                              image: widget.profile['photoUrl_500']),
                        ),
                        onTap: () {
                          changeScreen(context, PhotoView(widget.profile['photoUrl_500']));
                        },
                      )),
                  persistentContentHeight: screenSize.height * 0.35,
                  expandableContent: Container(
                      height: screenSize.height, // * 2,
                      width: screenSize.width,
                      padding: EdgeInsets.all(25),
                      decoration: BoxDecoration(
                          color: white,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.1),
                              spreadRadius: 2,
                              blurRadius: 3,
                              offset: Offset(0, 0), // changes position of shadow
                            ),
                          ],
                          border: Border.all(width: 1, color: grey),
                          borderRadius: new BorderRadius.only(
                            topLeft: Radius.circular(25.0),
                            topRight: Radius.circular(25.0),
                          )),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          switcher == 1
                              ? SizedBox(
                                  height: 10,
                                )
                              : SizedBox(
                                  height: 0,
                                ),
                          switcher == 1
                              ? Container(
                                  child: Row(
                                    children: [
                                      Container(
                                        child: Row(
                                          children: [
                                            Image.asset(
                                              'assets/icon/verified.png',
                                              color: appColor,
                                              height: 20,
                                            ),
                                            SizedBox(
                                              width: 10,
                                            ),
                                            Text(
                                              'Verified.',
                                              style: headingGreyStyle,
                                            ),
                                          ],
                                        ),
                                      ),
                                      SizedBox(
                                        width: 30,
                                      ),
                                      Container(
                                        child: Row(
                                          children: [
                                            IconButton(
                                                icon: Container(
                                                  child: Image.asset(
                                                    'assets/icon/crown.png',
                                                    color: appColor,
                                                    height: 20,
                                                  ),
                                                ),
                                                onPressed: () {}),
                                            Text(
                                              'Premium NRI',
                                              style: headingGreyStyle,
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                )
                              : SizedBox(
                                  height: 0,
                                ),
                          SizedBox(
                            height: 20,
                          ),
                          Text(
                            widget.profile['name'],
                            style: headingSmallBlackStyle,
                          ),
                          SizedBox(
                            height: 15,
                          ),
                          Text(
                            '${widget.profile['id']} | ${widget.profile['Age']} | ${widget.profile['Religion']}',
                            style: headingGreyStyle,
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          /*   Divider(
                            color: grey,
                            thickness: 2,
                          ),*/
                          SizedBox(
                            height: 10,
                          ),
                          Container(
                              child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Container(
                                padding: EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color: white,
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.grey.withOpacity(0.3),
                                      spreadRadius: 2,
                                      blurRadius: 3,
                                      offset: Offset(
                                          0, 0), // changes position of shadow
                                    ),
                                  ],
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(25.0)),
                                ),
                                child: new Text(
                                  'Send Interest',
                                  style: miniGreyTextStyle,
                                ),
                              ),
                              SizedBox(
                                width: 20,
                              ),
                              Container(
                                padding: EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color: white,
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.grey.withOpacity(0.3),
                                      spreadRadius: 2,
                                      blurRadius: 3,
                                      offset: Offset(
                                          0, 0), // changes position of shadow
                                    ),
                                  ],
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(25.0)),
                                ),
                                child: new Text(
                                  'Shortlist',
                                  style: miniGreyTextStyle,
                                ),
                              ),
                              SizedBox(
                                width: 20,
                              ),
                              Container(
                                padding: EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color: white,
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.grey.withOpacity(0.3),
                                      spreadRadius: 2,
                                      blurRadius: 3,
                                      offset: Offset(
                                          0, 0), // changes position of shadow
                                    ),
                                  ],
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(25.0)),
                                ),
                                child: new Text(
                                  'Ignore',
                                  style: miniGreyTextStyle,
                                ),
                              )
                            ],
                          )),
                          SizedBox(
                            height: 20,
                          ),
                          Text(
                            'About Her',
                            style: headingSmallBlackStyle,
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Container(
                            child: Row(
                              children: [
                                IconButton(
                                    icon: Container(
                                      child: Image.asset(
                                        'assets/icon/identification.png',
                                        color: appColor,
                                        height: 20,
                                      ),
                                    ),
                                    onPressed: () {}),
                                Text(
                                  'Profile created by parent.',
                                  style: headingGreyStyle,
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Container(
                            child: Row(
                              children: [
                                IconButton(
                                    icon: Container(
                                      child: Image.asset(
                                        'assets/icon/pencil.png',
                                        color: appColor,
                                        height: 20,
                                      ),
                                    ),
                                    onPressed: () {}),
                                SizedBox(
                                  child: Text(
                                    'My daughter is a student. other description ' +
                                        'other description other description ' +
                                        'other description other description ' +
                                        'other description other description other ' +
                                        'description...  ',
                                    textAlign: TextAlign.justify,
                                    style: headingGreyStyle,
                                  ),
                                  width:
                                      MediaQuery.of(context).size.width - 100,
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Container(
                            child: Row(
                              children: [
                                IconButton(
                                    icon: Container(
                                      child: Image.asset(
                                        'assets/icon/user.png',
                                        color: appColor,
                                        height: 20,
                                      ),
                                    ),
                                    onPressed: () {}),
                                Text(
                                  '28 yrs 8 months,${5.2}',
                                  style: headingGreyStyle,
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Container(
                            child: Row(
                              children: [
                                IconButton(
                                    icon: Container(
                                      child: Image.asset(
                                        'assets/icon/height.png',
                                        color: appColor,
                                        height: 20,
                                      ),
                                    ),
                                    onPressed: () {}),
                                Text(
                                  'Average Build',
                                  style: headingGreyStyle,
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Container(
                            child: Row(
                              children: [
                                IconButton(
                                    icon: Container(
                                      child: Image.asset(
                                        'assets/icon/wed.png',
                                        color: appColor,
                                        height: 20,
                                      ),
                                    ),
                                    onPressed: () {}),
                                Text(
                                  'Never Married',
                                  style: headingGreyStyle,
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Container(
                            child: Row(
                              children: [
                                IconButton(
                                    icon: Container(
                                      child: Image.asset(
                                        'assets/icon/user.png',
                                        color: appColor,
                                        height: 20,
                                      ),
                                    ),
                                    onPressed: () {}),
                                Text(
                                  'Mother Tongue is Telugu',
                                  style: headingGreyStyle,
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Container(
                            child: Row(
                              children: [
                                IconButton(
                                    icon: Container(
                                      child: Image.asset(
                                        'assets/icon/pin.png',
                                        color: appColor,
                                        height: 20,
                                      ),
                                    ),
                                    onPressed: () {}),
                                Text(
                                  'Lives in Khammam, Telangana, India',
                                  style: headingGreyStyle,
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Container(
                            child: Row(
                              children: [
                                IconButton(
                                    icon: Container(
                                      child: Image.asset(
                                        'assets/icon/flags.png',
                                        color: appColor,
                                        height: 20,
                                      ),
                                    ),
                                    onPressed: () {}),
                                Text(
                                  'Indian citizen',
                                  style: headingGreyStyle,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                  ),
                ),
              ),
              Container(
                width: screenSize.width,
                decoration: BoxDecoration(
                  color: white,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.8),
                      spreadRadius: 2,
                      blurRadius: 3,
                      offset: Offset(0, 0), // changes position of shadow
                    ),
                  ],
                ),
                padding: EdgeInsets.only(top: 10, bottom: 10),
                child:
                    // Button(
                    //   onPressed: (){
                    //
                    //   },
                    //   text: 'Upgrade Now',
                    // ),
                    GestureDetector(
                  onTap: () {},
                  child: Container(
                    margin: EdgeInsets.only(
                        left: screenSize.width * 0.3,
                        right: screenSize.width * 0.3),
                    width: 100,
                    height: 50,
                    decoration: BoxDecoration(
                      color: appColor,
                      borderRadius: BorderRadius.circular(23.0),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Icon(Icons.payment),
                        SizedBox(
                          width: 5,
                        ),
                        Text(
                          'Upgrade Now',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: white,
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ));
  }
}
