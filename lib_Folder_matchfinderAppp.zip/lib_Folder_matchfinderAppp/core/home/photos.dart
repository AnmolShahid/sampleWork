import 'package:expandable_bottom_sheet/expandable_bottom_sheet.dart';
import 'package:flutter/material.dart';
import 'package:flutter_swiper/flutter_swiper.dart';
import 'package:matchfinder/const/const.dart';
import 'package:matchfinder/const/general_methods.dart';
import 'package:matchfinder/core/home/match_profile.dart';
import 'package:matchfinder/model/profile_list.dart';
import 'package:matchfinder/utils/appBar.dart';
import 'package:matchfinder/utils/style.dart';
import 'package:matchfinder/widgets/imageWidget.dart';
import 'package:matchfinder/widgets/image_widget.dart';

class Photos extends StatefulWidget {
  String photo;
  Photos(this.photo);

  @override
  _PhotoViewState createState() => _PhotoViewState();
}

class _PhotoViewState extends State<Photos> {
  TextEditingController searchController = new TextEditingController();
  List<dynamic> _profiles = new List<dynamic>();
  var _menus = List<Map<String, dynamic>>();
  var _options = List<Map<String, dynamic>>();
  var selectedIndex = 0;
  bool isLoading = true;
  var _index = 0;

  @override
  void initState() {
    // _menus.add({
    //   'title': 'All Photos',
    //   'filter': 'all',
    // });
    // _menus.add({
    //   'title': 'Daily Photos',
    //   'filter': 'daily',
    // });
    // _menus.add({
    //   'title': 'Weekly Photos',
    //   'filter': 'weekly',
    // });
    // _menus.add({
    //   'title': 'Blocked',
    //   'filter': 'blocked',
    // });
    // _menus.add({
    //   'title': 'Shortlisted',
    //   'filter': 'shortlisted',
    // });
    // _menus.add({
    //   'title': 'Ignored',
    //   'filter': 'ignored',
    // });
    //
    // _options.add({
    //   'title': 'Chat',
    //   'icon': 'assets/chat_msgs.svg',
    // });
    // _options.add({'title': 'Horoscope', 'icon': 'assets/horoscope.svg'});
    // _options.add({
    //   'title': 'Call',
    //   'icon': 'assets/call.svg',
    // });
    // _options.add({
    //   'title': 'Block',
    //   'icon': 'assets/remove_user.svg',
    // });
    // _options.add({
    //   'title': 'Request Photo',
    //   'icon': 'assets/request_photo.svg',
    // });
    // _options.add({
    //   'title': 'Photo Password',
    //   'icon': 'assets/photo_password.svg',
    // });
    // _options.add({
    //   'title': 'Request Horoscope',
    //   'icon': 'assets/request_horoscope.svg',
    // });
    // getPhotoView('all');
    super.initState();
  }

  // getPhotoView(filter) {
  //   _profiles.clear();
  //   _profiles.add({
  //     'id': 'T5869321',
  //     'name': 'Sri Lallitha',
  //     'photoUrl': "assets/sample_pic.png",
  //     'Age': '26 Yrs, 5\'2"',
  //     'Religion': 'Hindu, Brahmin',
  //     'Star': 'Moola',
  //     'Location': 'Hyderabad Tala, India',
  //     'Education': 'BSc IT / Computer science',
  //     'Profession': 'Banking Professional',
  //   });
  //   _profiles.add({
  //     'id': 'T5869321',
  //     'name': 'Sri Lallitha',
  //     'photoUrl': "assets/sample_pic.png",
  //     'Age': '26 Yrs, 5\'2"',
  //     'Religion': 'Hindu, Brahmin',
  //     'Star': 'Moola',
  //     'Location': 'Hyderabad Tala, India',
  //     'Education': 'BSc IT / Computer science',
  //     'Profession': 'Banking Professional',
  //   });
  //   _profiles.add({
  //     'id': 'T5869321',
  //     'name': 'Sri Lallitha',
  //     'photoUrl': "assets/sample_pic.png",
  //     'Age': '26 Yrs, 5\'2"',
  //     'Religion': 'Hindu, Brahmin',
  //     'Star': 'Moola',
  //     'Location': 'Hyderabad Tala, India',
  //     'Education': 'BSc IT / Computer science',
  //     'Profession': 'Banking Professional',
  //   });
  // }

  @override
  Widget build(BuildContext context) {
    var screenSize = MediaQuery.of(context).size;

    return Scaffold(
        appBar: AppBarWidget(
          heading: 'Photos',
          showIcon: true,
        ),
        body: Container(
          color: white,
          child: Container(
            height: screenSize.height,
            child: Swiper(
              loop: true,
              itemCount: 3,
              control: SwiperControl(
                  color: white,
                  padding: EdgeInsets.only(left: 10, right: 10),
                  size: 40),
              itemBuilder: (BuildContext context, int index) {
                return Container(
                  width: screenSize.width,
                  child: ImageWidget(
                      width: screenSize.width * 0.9,
                      height: screenSize.height * 0.3,
                      image: widget.photo),
                );
              },
              // viewportFraction: 0.8,
              scale: 0.6,
              index: _index,
              onIndexChanged: (index) {
                setState(() {
                  _index = index;
                });
              },
              pagination: new SwiperPagination(
                margin: new EdgeInsets.only(bottom: 30.0),
                alignment: Alignment.bottomCenter,
                builder: new DotSwiperPaginationBuilder(
                    color: grey, activeColor: appColor),
              ),
            ),
          ),
        ));
  }
}
