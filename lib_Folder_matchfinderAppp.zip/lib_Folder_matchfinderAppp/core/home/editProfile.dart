import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:matchfinder/const/const.dart';
import 'package:matchfinder/core/intro_screen/mainScreen.dart';
import 'package:matchfinder/utils/appBar.dart';
import 'package:matchfinder/utils/style.dart';
import 'package:matchfinder/widgets/customDrop.dart';
import 'package:matchfinder/widgets/image_widget.dart';
import '../../utils/custom_expansion_tile.dart' as custom;

class EditProfileView extends StatefulWidget {
  @override
  _EditProfileViewState createState() => _EditProfileViewState();
}

class _EditProfileViewState extends State<EditProfileView> {
  int index = 0;
  var groupValues;
  TextEditingController firstName = TextEditingController();
  TextEditingController lastName = TextEditingController();
  TextEditingController lang = TextEditingController();
  TextEditingController caste = TextEditingController();
  TextEditingController marital = TextEditingController();
  TextEditingController country = TextEditingController();
  TextEditingController state = TextEditingController();
  TextEditingController city = TextEditingController();
  TextEditingController place = TextEditingController();
  TextEditingController visa = TextEditingController();
  TextEditingController birth = TextEditingController();
  TextEditingController phone1 = TextEditingController();
  TextEditingController phone = TextEditingController();

  TextEditingController search = TextEditingController();
  var menus = List<Map<String, dynamic>>();
  bool basicEdit = false;
  bool basicEditForm = false;
  bool personalEdit = false;
  bool personalEditForm = true;
  bool familyEdit = false;
  bool familyEditForm = true;
  bool favEdit = false;
  bool favEditForm = false;
  bool eduEdit = false;
  bool eduEditForm = false;
  bool astrologicalEdit = false;
  bool astrologicalEditForm = false;
  Color headerBackgroundColor = Color(0xFFF7F7F7);
  int kujaDushaValue = -1;

  String martialStatus;
  List<DropdownMenuItem<String>> martialStatusDropDown =
      <DropdownMenuItem<String>>[];
  bool isMartialStatus;

  var valMonday = false;

  bool valTuesday = false;

  bool valWednesday = false;
  getMartialStatusDropDown(param0, String martial) async {
    List<dynamic> res = await param0;
    if (res.isNotEmpty) {
      List<dynamic> value = res.reversed.toList();
      List<DropdownMenuItem<String>> items = new List();
      for (int i = 0; i < value.length; i++) {
        setState(() {
          if (value[i][0] == martial) {
            martialStatus = value[i][0];
          }
          items.insert(
            0,
            DropdownMenuItem(
              child: Text(
                value[i][1],
              ),
              value: value[i][0],
            ),
          );
        });
      }
      return items;
    } else {
      return null;
    }
  }

  @override
  void initState() {
    super.initState();
    menus.add({
      'icon': 'assets/user.svg',
      'title': 'Basic Details',
    });
    menus.add({
      'icon': 'assets/identification.svg',
      'title': 'Personal Details',
    });
    menus.add({
      'icon': 'assets/family.svg',
      'title': 'Family Details',
    });
    menus.add({
      'icon': 'assets/star.svg',
      'title': 'Favourites',
    });
    menus.add({
      'icon': 'assets/graduation_cap.svg',
      'title': 'Education & Employment',
    });
    menus.add({
      'icon': 'assets/horoscope.svg',
      'title': 'Astrological Details',
    });
  }

  @override
  Widget build(BuildContext context) {
    var screenSize = MediaQuery.of(context).size;

    Widget _myRadioButton({String title, int value, Function onChanged}) {
      return RadioListTile(
        contentPadding: EdgeInsets.all(0),
        value: value,
        groupValue: kujaDushaValue,
        onChanged: onChanged,
        title: Text(title),
      );
    }

    var basicDetails = custom.ExpansionTile(
        headerBackgroundColor: headerBackgroundColor,
        title: getTitleRow(0, screenSize, basicEdit),
        trailing: basicEdit
            ? Container(
                width: 60,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    GestureDetector(
                        onTap: () {
                          setState(() {
                            basicEditForm = !basicEditForm;
                          });
                        },
                        child: AssetImageWidget(
                          image: 'assets/pencil.svg',
                          width: 25,
                          height: 25,
                        )),
                    SizedBox(width: 10),
                    Icon(Icons.arrow_forward_ios),
                  ],
                ),
              )
            : Icon(Icons.arrow_forward_ios),
        onExpansionChanged: (val) {
          setState(() {
            basicEdit = val;
          });
        },
        children: [
          Container(
            padding: EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: white,
              borderRadius: BorderRadius.only(
                  bottomRight: Radius.circular(10),
                  bottomLeft: Radius.circular(10)),
            ),
            child: ListView(
              shrinkWrap: true,
              primary: false,
              children: [
                SizedBox(
                  height: 10,
                ),
                Container(
                  width: screenSize.width * 0.38,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Container(
                            child: Text(
                              'Name: ',
                              style: miniBlackBoldFontWeightStyle,
                            ),
                          ),
                          basicEditForm
                              ? Container(
                                  width: 150,
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    'Sanjay ',
                                    style: miniBlackFontWeightStyle,
                                  ))
                              : Column(
                                  children: [
                                    Container(
                                      width: 220,
                                      height: 50,
                                      child: TextField(
                                          decoration: new InputDecoration(
                                            fillColor: appColor,
                                            hintText: 'First Name',
                                            border: new OutlineInputBorder(
                                                borderSide: new BorderSide(
                                                    color: Colors.black)),
                                          ),
                                          controller: firstName),
                                    ),
                                    SizedBox(
                                      height: 5,
                                    ),
                                    Container(
                                      width: 220,
                                      height: 50,
                                      child: TextField(
                                          decoration: new InputDecoration(
                                            fillColor: appColor,
                                            hintText: 'Last Name',
                                            border: new OutlineInputBorder(
                                                borderSide: new BorderSide(
                                                    color: Colors.black)),
                                          ),
                                          controller: lastName),
                                    ),
                                  ],
                                )
                        ],
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            child: Text(
                              'Birthday: ',
                              style: miniBlackBoldFontWeightStyle,
                            ),
                          ),
                          basicEditForm
                              ? Container(
                                  width: 150,
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    '15 May 1996 ',
                                    style: miniBlackFontWeightStyle,
                                  )
                          )
                              : Container(
                                  child: Column(
                                  children: [
                                    Container(
                                      width: 220,
                                      height: 50,
                                      child: DropdownButtonFormField<String>(
                                        decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                                borderSide: BorderSide(
                                                    color: Colors.grey))),
                                        onTap: () {
                                          FocusScope.of(context).unfocus();
                                        },
                                        value: martialStatus,
                                        hint: Text(''),
                                        style: smallGreyTextStyle,
                                        items: martialStatusDropDown,
                                        onChanged: (item) {
                                          setState(() {
                                            martialStatus = item;
                                            isMartialStatus = false;
                                          });
                                        },
                                        isExpanded: true,
                                        icon: Icon(Icons.keyboard_arrow_down),
                                      ),
                                    ),
                                    SizedBox(
                                      height: 5,
                                    ),
                                    Container(
                                      width: 220,
                                      height: 50,
                                      child: DropdownButtonFormField<String>(
                                        decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                                borderSide: BorderSide(
                                                    color: Colors.grey))),
                                        onTap: () {
                                          FocusScope.of(context).unfocus();
                                        },
                                        value: martialStatus,
                                        hint: Text(''),
                                        style: smallGreyTextStyle,
                                        items: martialStatusDropDown,
                                        onChanged: (item) {
                                          setState(() {
                                            martialStatus = item;
                                            isMartialStatus = false;
                                          });
                                        },
                                        isExpanded: true,
                                        icon: Icon(Icons.keyboard_arrow_down),
                                      ),
                                    ),
                                    SizedBox(
                                      height: 5,
                                    ),
                                    Container(
                                      width: 220,
                                      height: 50,
                                      child: DropdownButtonFormField<String>(
                                        decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                                borderSide: BorderSide(
                                                    color: Colors.grey))),
                                        onTap: () {
                                          FocusScope.of(context).unfocus();
                                        },
                                        value: martialStatus,
                                        hint: Text(''),
                                        style: smallGreyTextStyle,
                                        items: martialStatusDropDown,
                                        onChanged: (item) {
                                          setState(() {
                                            martialStatus = item;
                                            isMartialStatus = false;
                                          });
                                        },
                                        isExpanded: true,
                                        icon: Icon(Icons.keyboard_arrow_down),
                                      ),
                                    )
                                  ],
                                ))
                        ],
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            child: Text(
                              'Mother Tongue: ',
                              style: miniBlackBoldFontWeightStyle,
                            ),
                          ),
                          basicEditForm
                              ? Container(
                                  width: 150,
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    'Hindi ',
                                    style: miniBlackFontWeightStyle,
                                  ))
                              : Container(
                                  width: 220,
                                  height: 50,
                                  child: DropdownButtonFormField<String>(
                                    decoration: InputDecoration(
                                        border: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.grey))),
                                    onTap: () {
                                      FocusScope.of(context).unfocus();
                                    },
                                    value: martialStatus,
                                    style: smallGreyTextStyle,
                                    items: martialStatusDropDown,
                                    onChanged: (item) {
                                      setState(() {
                                        martialStatus = item;
                                        isMartialStatus = false;
                                      });
                                    },
                                    isExpanded: true,
                                    icon: Icon(Icons.keyboard_arrow_down),
                                  ),
                                )
                        ],
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            child: Text(
                              'Religion: ',
                              style: miniBlackBoldFontWeightStyle,
                            ),
                          ),
                          basicEditForm
                              ? Container(
                                  width: 150,
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    'Muslim ',
                                    style: miniBlackFontWeightStyle,
                                  ))
                              : Container(
                                  width: 220,
                                  height: 50,
                                  child: DropdownButtonFormField<String>(
                                    decoration: InputDecoration(
                                        border: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.grey))),
                                    onTap: () {
                                      FocusScope.of(context).unfocus();
                                    },
                                    value: martialStatus,
                                    style: smallGreyTextStyle,
                                    items: martialStatusDropDown,
                                    onChanged: (item) {
                                      setState(() {
                                        martialStatus = item;
                                        isMartialStatus = false;
                                      });
                                    },
                                    isExpanded: true,
                                    icon: Icon(Icons.keyboard_arrow_down),
                                  ),
                                )
                        ],
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            child: Text(
                              'Caste: ',
                              style: miniBlackBoldFontWeightStyle,
                            ),
                          ),
                          basicEditForm
                              ? Container(
                                  width: 150,
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    'Rajput ',
                                    style: miniBlackFontWeightStyle,
                                  ))
                              : Container(
                                  width: 220,
                                  height: 50,
                                  child: DropdownButtonFormField<String>(
                                    decoration: InputDecoration(
                                        border: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.grey))),
                                    onTap: () {
                                      FocusScope.of(context).unfocus();
                                    },
                                    value: martialStatus,
                                    style: smallGreyTextStyle,
                                    items: martialStatusDropDown,
                                    onChanged: (item) {
                                      setState(() {
                                        martialStatus = item;
                                        isMartialStatus = false;
                                      });
                                    },
                                    isExpanded: true,
                                    icon: Icon(Icons.keyboard_arrow_down),
                                  ),
                                )
                        ],
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            child: Text(
                              'Marital Status:  ',
                              style: miniBlackBoldFontWeightStyle,
                            ),
                          ),
                          basicEditForm
                              ? Container(
                                  width: 150,
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    'Single ',
                                    style: miniBlackFontWeightStyle,
                                  ))
                              : Container(
                                  width: 220,
                                  height: 50,
                                  child: DropdownButtonFormField<String>(
                                    decoration: InputDecoration(
                                        border: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.grey))),
                                    onTap: () {
                                      FocusScope.of(context).unfocus();
                                    },
                                    value: martialStatus,
                                    style: smallGreyTextStyle,
                                    items: martialStatusDropDown,
                                    onChanged: (item) {
                                      setState(() {
                                        martialStatus = item;
                                        isMartialStatus = false;
                                      });
                                    },
                                    isExpanded: true,
                                    icon: Icon(Icons.keyboard_arrow_down),
                                  ),
                                )
                        ],
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            child: Text(
                              'Country Living In: ',
                              style: miniBlackBoldFontWeightStyle,
                            ),
                          ),
                          basicEditForm
                              ? Container(
                                  width: 150,
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    'India ',
                                    style: miniBlackFontWeightStyle,
                                  ))
                              : Container(
                                  width: 220,
                                  height: 50,
                                  child: DropdownButtonFormField<String>(
                                    decoration: InputDecoration(
                                        border: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.grey))),
                                    onTap: () {
                                      FocusScope.of(context).unfocus();
                                    },
                                    value: martialStatus,
                                    style: smallGreyTextStyle,
                                    items: martialStatusDropDown,
                                    onChanged: (item) {
                                      setState(() {
                                        martialStatus = item;
                                        isMartialStatus = false;
                                      });
                                    },
                                    isExpanded: true,
                                    icon: Icon(Icons.keyboard_arrow_down),
                                  ),
                                )
                        ],
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            child: Text(
                              'State Livivg In:  ',
                              style: miniBlackBoldFontWeightStyle,
                            ),
                          ),
                          basicEditForm
                              ? Container(
                                  width: 150,
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    'Punjab ',
                                    style: miniBlackFontWeightStyle,
                                  ))
                              : Container(
                                  width: 220,
                                  height: 50,
                                  child: DropdownButtonFormField<String>(
                                    decoration: InputDecoration(
                                        border: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.grey))),
                                    onTap: () {
                                      FocusScope.of(context).unfocus();
                                    },
                                    value: martialStatus,
                                    style: smallGreyTextStyle,
                                    items: martialStatusDropDown,
                                    onChanged: (item) {
                                      setState(() {
                                        martialStatus = item;
                                        isMartialStatus = false;
                                      });
                                    },
                                    isExpanded: true,
                                    icon: Icon(Icons.keyboard_arrow_down),
                                  ),
                                )
                        ],
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            child: Text(
                              'City Living In:  ',
                              style: miniBlackBoldFontWeightStyle,
                            ),
                          ),
                          basicEditForm
                              ? Container(
                                  width: 150,
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    'Lahore ',
                                    style: miniBlackFontWeightStyle,
                                  ))
                              : Container(
                                  width: 220,
                                  height: 50,
                                  child: DropdownButtonFormField<String>(
                                    decoration: InputDecoration(
                                        border: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.grey))),
                                    onTap: () {
                                      FocusScope.of(context).unfocus();
                                    },
                                    value: martialStatus,
                                    style: smallGreyTextStyle,
                                    items: martialStatusDropDown,
                                    onChanged: (item) {
                                      setState(() {
                                        martialStatus = item;
                                        isMartialStatus = false;
                                      });
                                    },
                                    isExpanded: true,
                                    icon: Icon(Icons.keyboard_arrow_down),
                                  ),
                                )
                        ],
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            child: Text(
                              'Native Place:  ',
                              style: miniBlackBoldFontWeightStyle,
                            ),
                          ),
                          basicEditForm
                              ? Container(
                                  width: 150,
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    'Gujrat ',
                                    style: miniBlackFontWeightStyle,
                                  ))
                              : Container(
                                  width: 220,
                                  height: 50,
                                  child: DropdownButtonFormField<String>(
                                    decoration: InputDecoration(
                                        border: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.grey))),
                                    onTap: () {
                                      FocusScope.of(context).unfocus();
                                    },
                                    value: martialStatus,
                                    style: smallGreyTextStyle,
                                    items: martialStatusDropDown,
                                    onChanged: (item) {
                                      setState(() {
                                        martialStatus = item;
                                        isMartialStatus = false;
                                      });
                                    },
                                    isExpanded: true,
                                    icon: Icon(Icons.keyboard_arrow_down),
                                  ),
                                )
                        ],
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            child: Text(
                              'Visa Status:  ',
                              style: miniBlackBoldFontWeightStyle,
                            ),
                          ),
                          basicEditForm
                              ? Container(
                                  width: 150,
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    'Active ',
                                    style: miniBlackFontWeightStyle,
                                  ))
                              : Container(
                                  width: 220,
                                  height: 50,
                                  child: DropdownButtonFormField<String>(
                                    decoration: InputDecoration(
                                        border: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.grey))),
                                    onTap: () {
                                      FocusScope.of(context).unfocus();
                                    },
                                    value: martialStatus,
                                    style: smallGreyTextStyle,
                                    items: martialStatusDropDown,
                                    onChanged: (item) {
                                      setState(() {
                                        martialStatus = item;
                                        isMartialStatus = false;
                                      });
                                    },
                                    isExpanded: true,
                                    icon: Icon(Icons.keyboard_arrow_down),
                                  ),
                                )
                        ],
                      ),
                      SizedBox(
                        height: 5,
                      ),
                    ],
                  ),
                ),
                /*    Container(
                      width: screenSize.width * 0.38,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          basicEditForm
                              ? Text(
                                  'Sanjay ',
                                  style: miniBlackFontWeightStyle,
                                )
                              : TextField(
                                  decoration: new InputDecoration(
                                    border: new OutlineInputBorder(
                                        borderSide: new BorderSide(
                                            color: Colors.black)),
                                  ),
                                  controller: firstName),
                          SizedBox(
                            height: 5,
                          ),
                          Text(
                            '15 May 1996',
                            style: miniBlackFontWeightStyle,
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Text(
                            'Malayalam',
                            style: miniBlackFontWeightStyle,
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Text(
                            'Hindu',
                            style: miniBlackFontWeightStyle,
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Text(
                            'Pulayan/Pulayan',
                            style: miniBlackFontWeightStyle,
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Text(
                            'Single',
                            style: miniBlackFontWeightStyle,
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Text(
                            'India',
                            style: miniBlackFontWeightStyle,
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Text(
                            'Kerala',
                            style: miniBlackFontWeightStyle,
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Text(
                            'Trivandrum',
                            style: miniBlackFontWeightStyle,
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Text(
                            '',
                            style: miniBlackFontWeightStyle,
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Text(
                            '',
                            style: miniBlackFontWeightStyle,
                          ),
                        ],
                      ),
                    ),
               */

                SizedBox(
                  height: 20,
                ),
                Text(
                  'Your Details',
                  style: headingBlackStyle,
                ),
                SizedBox(
                  height: 20,
                ),
                Container(
                  width: screenSize.width * 0.38,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            child: Text(
                              'Your Phone No:  ',
                              style: miniBlackBoldFontWeightStyle,
                            ),
                          ),
                          basicEditForm
                              ? Container(
                                  width: 150,
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    '+917895562223 ',
                                    style: miniBlackFontWeightStyle,
                                  ))
                              : Column(
                                  children: [
                                    Container(
                                      width: 250,
                                      height: 60,
                                      child: DropdownButtonFormField<String>(
                                        decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                                borderSide: BorderSide(
                                                    color: Colors.grey))),
                                        onTap: () {
                                          FocusScope.of(context).unfocus();
                                        },
                                        value: martialStatus,
                                        hint: Text('(India)+91'),
                                        style: smallGreyTextStyle,
                                        items: martialStatusDropDown,
                                        onChanged: (item) {
                                          setState(() {
                                            martialStatus = item;
                                            isMartialStatus = false;
                                          });
                                        },
                                        isExpanded: true,
                                        icon: Icon(Icons.keyboard_arrow_down),
                                      ),
                                    ),
                                    SizedBox(
                                      height: 5,
                                    ),
                                    Container(
                                      width: 250,
                                      height: 50,
                                      child: TextField(
                                          decoration: new InputDecoration(
                                            fillColor: appColor,
                                            hintText: '87968574678',
                                            border: new OutlineInputBorder(
                                                borderSide: new BorderSide(
                                                    color: Colors.black)),
                                          ),
                                          controller: phone),
                                    )
                                  ],
                                )
                        ],
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            child: Text(
                              'Your Alternate \nPhone No:  ',
                              style: miniBlackBoldFontWeightStyle,
                            ),
                          ),
                          basicEditForm
                              ? Container(
                                  width: 150,
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    '+917895562223 ',
                                    style: miniBlackFontWeightStyle,
                                  ))
                              : Column(
                                  children: [
                                    Container(
                                      width: 250,
                                      height: 60,
                                      child: DropdownButtonFormField<String>(
                                        decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                                borderSide: BorderSide(
                                                    color: Colors.grey))),
                                        onTap: () {
                                          FocusScope.of(context).unfocus();
                                        },
                                        value: martialStatus,
                                        hint: Text('(India)+91'),
                                        style: smallGreyTextStyle,
                                        items: martialStatusDropDown,
                                        onChanged: (item) {
                                          setState(() {
                                            martialStatus = item;
                                            isMartialStatus = false;
                                          });
                                        },
                                        isExpanded: true,
                                        icon: Icon(Icons.keyboard_arrow_down),
                                      ),
                                    ),
                                    SizedBox(
                                      height: 5,
                                    ),
                                    Container(
                                      width: 250,
                                      height: 50,
                                      child: TextField(
                                          decoration: new InputDecoration(
                                            fillColor: appColor,
                                            hintText: '896785646578',
                                            border: new OutlineInputBorder(
                                                borderSide: new BorderSide(
                                                    color: Colors.black)),
                                          ),
                                          controller: phone1),
                                    )
                                  ],
                                )
                        ],
                      ),
                      basicEditForm
                          ? SizedBox(
                              height: 5,
                            )
                          : SizedBox(
                              height: 35,
                            ),
                      basicEditForm
                          ? SizedBox(
                              width: 0,
                            )
                          : GestureDetector(
                              onTap: () {
                                setState(() {
                                  basicEditForm = false;
                                });
                              },
                              child: Container(
                                margin: EdgeInsets.only(
                                    left: screenSize.width * 0.3,
                                    right: screenSize.width * 0.3),
                                width: 100,
                                height: 50,
                                decoration: BoxDecoration(
                                  color: appColor,
                                  borderRadius: BorderRadius.circular(23.0),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Text(
                                      'Save',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: white,
                                        fontSize: 16,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            )
                    ],
                  ),
                ),
              ],
            ),
          )
        ]);

    var personalDetails = custom.ExpansionTile(
        headerBackgroundColor: headerBackgroundColor,
        title: getTitleRow(1, screenSize, personalEdit),
        trailing: personalEdit
            ? Container(
                width: 60,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    GestureDetector(
                        onTap: () {
                          setState(() {
                            personalEditForm = !personalEditForm;
                          });
                        },
                        child: AssetImageWidget(
                          image: 'assets/pencil.svg',
                          width: 25,
                          height: 25,
                        )),
                    SizedBox(width: 10),
                    Icon(Icons.arrow_forward_ios),
                  ],
                ),
              )
            : Icon(Icons.arrow_forward_ios),
        onExpansionChanged: (val) {
          setState(() {
            personalEdit = val;
          });
        },
        children: [
          Container(
            padding: EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: white,
              borderRadius: BorderRadius.only(
                  bottomRight: Radius.circular(10),
                  bottomLeft: Radius.circular(10)),
            ),
            child: ListView(
              shrinkWrap: true,
              primary: false,
              children: [
                SizedBox(
                  height: 10,
                ),
                Text(
                  'About Me: ',
                  style: headingBlackStyle,
                ),
                personalEditForm
                    ? Text(
                        'bla bla bla bla bla bla bla bla bla bla bla bla bla' +
                            'bla bla bla bla bla bla bla bla bla bla bla bla bla' +
                            'bla bla bla bla bla bla bla bla bla bla bla bla bla' +
                            'bla bla bla bla bla bla bla bla bla bla bla bla bla' +
                            'bla bla bla bla bla bla bla bla bla bla bla bla bla',
                      )
                    : TextField(
                        maxLines: 5,
                        decoration: new InputDecoration(
                          fillColor: appColor,
                          border: new OutlineInputBorder(
                              borderSide: new BorderSide(color: Colors.black)),
                        ),
                      ),
                SizedBox(
                  height: 20,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      child: Text(
                        'Spoken Languages: ',
                        style: miniBlackBoldFontWeightStyle,
                      ),
                    ),
                    personalEditForm
                        ? Container(
                            width: 150,
                            alignment: Alignment.topLeft,
                            child: Text(
                              'Urdu ',
                              style: miniBlackFontWeightStyle,
                            ))
                        : Container(
                            width: 220,
                            height: 100,
                            decoration: BoxDecoration(
                                border: Border.all(color: Colors.black38)),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.all(5),
                                  padding: EdgeInsets.only(
                                      left: 10, right: 10, top: 5, bottom: 5),
                                  child: Text(
                                    'Tamil',
                                    style: miniBlackFontWeightStyle,
                                  ),
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(20),
                                    color: Colors.grey[300],
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.all(5),
                                  padding: EdgeInsets.only(
                                      left: 10, right: 10, top: 5, bottom: 5),
                                  child: Text(
                                    'Hindi',
                                    style: miniBlackFontWeightStyle,
                                  ),
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(20),
                                    color: Colors.grey[300],
                                  ),
                                ),
                              ],
                            ),
                          ),
                  ],
                ),
                SizedBox(
                  height: 5,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      child: Text(
                        'Physical Status: ',
                        style: miniBlackBoldFontWeightStyle,
                      ),
                    ),
                    personalEditForm
                        ? Container(
                            width: 150,
                            alignment: Alignment.topLeft,
                            child: Text(
                              'Normal ',
                              style: miniBlackFontWeightStyle,
                            ))
                        : Container(
                            width: 220,
                            child: Row(
                              children: [
                                Row(
                                  children: [
                                    Container(
                                      child: Radio(
                                        groupValue: 0,
                                        value: 1,
                                        onChanged: (newValue) => setState(
                                            () => groupValues = newValue),
                                      ),
                                      width: 25,
                                    ),
                                    Text(
                                      'Normal ',
                                      style: miniBlackFontWeightStyle,
                                    )
                                  ],
                                ),
                                SizedBox(
                                  width: 5,
                                ),
                                Row(
                                  children: [
                                    Container(
                                      child: Radio(
                                        groupValue: 1,
                                        value: 1,
                                        onChanged: (newValue) => setState(
                                          () => groupValues = newValue,
                                        ),
                                      ),
                                      width: 25,
                                    ),
                                    Text(
                                      'Challenged ',
                                      style: miniBlackFontWeightStyle,
                                    )
                                  ],
                                ),
                              ],
                            ),
                          )
                  ],
                ),
                SizedBox(
                  height: 5,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      child: Text(
                        'Body Type: ',
                        style: miniBlackBoldFontWeightStyle,
                      ),
                    ),
                    personalEditForm
                        ? Container(
                            width: 150,
                            alignment: Alignment.topLeft,
                            child: Text(
                              'Athletic ',
                              style: miniBlackFontWeightStyle,
                            ))
                        : Container(
                        width: 230,
                            child: Column(
                            children: [
                              Row(
                                children: [
                                  Row(
                                    children: [
                                      Radio(
                                        groupValue: 0,
                                        value: 1,
                                        onChanged: (newValue) => setState(
                                            () => groupValues = newValue),
                                      ),
                                      Text(
                                        'Athletic  ',
                                        style: miniBlackFontWeightStyle,
                                      )
                                    ],
                                  ),
                                  SizedBox(
                                    width: 5,
                                  ),
                                  Row(
                                    children: [
                                      Radio(
                                        groupValue: 1,
                                        value: 1,
                                        onChanged: (newValue) => setState(
                                          () => groupValues = newValue,
                                        ),
                                      ),
                                      Text(
                                        'Slim     ',
                                        style: miniBlackFontWeightStyle,
                                      )
                                    ],
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  Row(
                                    children: [
                                      Radio(
                                        groupValue: 0,
                                        value: 1,
                                        onChanged: (newValue) => setState(
                                            () => groupValues = newValue),
                                      ),
                                      Text(
                                        'Average ',
                                        style: miniBlackFontWeightStyle,
                                      )
                                    ],
                                  ),
                                  SizedBox(
                                    width: 5,
                                  ),
                                  Row(
                                    children: [
                                      Radio(
                                        groupValue: 1,
                                        value: 0,
                                        onChanged: (newValue) => setState(
                                          () => groupValues = newValue,
                                        ),
                                      ),
                                      Text(
                                        'Heavy ',
                                        style: miniBlackFontWeightStyle,
                                      )
                                    ],
                                  ),
                                ],
                              ),
                            ],
                          )),
                  ],
                ),
                SizedBox(
                  height: 5,
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      child: Text(
                        'Medically: ',
                        style: miniBlackBoldFontWeightStyle,
                      ),
                    ),
                    personalEditForm
                        ? Container(
                            width: 150,
                            alignment: Alignment.topLeft,
                            child: Text(
                              'No ',
                              style: miniBlackFontWeightStyle,
                            ))
                        : Container(
                            width: 225,
                            height: 50,
                            child: DropdownButtonFormField<String>(
                              decoration: InputDecoration(
                                  border: OutlineInputBorder(
                                      borderSide:
                                          BorderSide(color: Colors.grey))),
                              onTap: () {
                                FocusScope.of(context).unfocus();
                              },
                              value: martialStatus,
                              style: smallGreyTextStyle,
                              items: martialStatusDropDown,
                              onChanged: (item) {
                                setState(() {
                                  martialStatus = item;
                                  isMartialStatus = false;
                                });
                              },
                              isExpanded: true,
                              icon: Icon(Icons.keyboard_arrow_down),
                            ),
                          )
                  ],
                ),
                SizedBox(
                  height: 5,
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      child: Text(
                        'Compromised: ',
                        style: miniBlackBoldFontWeightStyle,
                      ),
                    ),
                    personalEditForm
                        ? Container(
                            width: 150,
                            alignment: Alignment.topLeft,
                            child: Text(
                              ' ',
                              style: miniBlackFontWeightStyle,
                            ))
                        : Container(
                            width: 225,
                            height: 100,
                            decoration: BoxDecoration(
                                border: Border.all(color: Colors.black38)),
                          )
                  ],
                ),
                SizedBox(
                  height: 5,
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      child: Text(
                        'Height: ',
                        style: miniBlackBoldFontWeightStyle,
                      ),
                    ),
                    personalEditForm
                        ? Container(
                            width: 150,
                            alignment: Alignment.topLeft,
                            child: Text(
                              '4 Ft 7 In ',
                              style: miniBlackFontWeightStyle,
                            ))
                        : Container(
                            child: Row(
                            children: [
                              Container(
                                width: 140,
                                height: 50,
                                child: DropdownButtonFormField<String>(
                                  decoration: InputDecoration(
                                      border: OutlineInputBorder(
                                          borderSide:
                                              BorderSide(color: Colors.grey))),
                                  onTap: () {
                                    FocusScope.of(context).unfocus();
                                  },
                                  value: martialStatus,
                                  style: smallGreyTextStyle,
                                  items: martialStatusDropDown,
                                  onChanged: (item) {
                                    setState(() {
                                      martialStatus = item;
                                      isMartialStatus = false;
                                    });
                                  },
                                  isExpanded: true,
                                  icon: Icon(Icons.keyboard_arrow_down),
                                ),
                              ),
                              SizedBox(
                                width: 5,
                              ),
                              Container(
                                width: 80,
                                height: 50,
                                child: DropdownButtonFormField<String>(
                                  decoration: InputDecoration(
                                      border: OutlineInputBorder(
                                          borderSide:
                                              BorderSide(color: Colors.grey))),
                                  onTap: () {
                                    FocusScope.of(context).unfocus();
                                  },
                                  value: martialStatus,
                                  style: smallGreyTextStyle,
                                  items: martialStatusDropDown,
                                  onChanged: (item) {
                                    setState(() {
                                      martialStatus = item;
                                      isMartialStatus = false;
                                    });
                                  },
                                  isExpanded: true,
                                  icon: Icon(Icons.keyboard_arrow_down),
                                ),
                              )
                            ],
                          ))
                  ],
                ),
                SizedBox(
                  height: 5,
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      child: Text(
                        'Weight: ',
                        style: miniBlackBoldFontWeightStyle,
                      ),
                    ),
                    personalEditForm
                        ? Container(
                            width: 150,
                            alignment: Alignment.topLeft,
                            child: Text(
                              '45.0 Kg ',
                              style: miniBlackFontWeightStyle,
                            ))
                        : Container(
                            child: Row(
                            children: [
                              Container(
                                width: 140,
                                height: 50,
                                child: DropdownButtonFormField<String>(
                                  decoration: InputDecoration(
                                      border: OutlineInputBorder(
                                          borderSide:
                                              BorderSide(color: Colors.grey))),
                                  onTap: () {
                                    FocusScope.of(context).unfocus();
                                  },
                                  value: martialStatus,
                                  style: smallGreyTextStyle,
                                  items: martialStatusDropDown,
                                  onChanged: (item) {
                                    setState(() {
                                      martialStatus = item;
                                      isMartialStatus = false;
                                    });
                                  },
                                  isExpanded: true,
                                  icon: Icon(Icons.keyboard_arrow_down),
                                ),
                              ),
                              SizedBox(
                                width: 5,
                              ),
                              Container(
                                width: 80,
                                height: 50,
                                child: DropdownButtonFormField<String>(
                                  decoration: InputDecoration(
                                      border: OutlineInputBorder(
                                          borderSide:
                                              BorderSide(color: Colors.grey))),
                                  onTap: () {
                                    FocusScope.of(context).unfocus();
                                  },
                                  value: martialStatus,
                                  style: smallGreyTextStyle,
                                  items: martialStatusDropDown,
                                  onChanged: (item) {
                                    setState(() {
                                      martialStatus = item;
                                      isMartialStatus = false;
                                    });
                                  },
                                  isExpanded: true,
                                  icon: Icon(Icons.keyboard_arrow_down),
                                ),
                              )
                            ],
                          ))
                  ],
                ),
                SizedBox(
                  height: 5,
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      child: Text(
                        'Complexion: ',
                        style: miniBlackBoldFontWeightStyle,
                      ),
                    ),
                    personalEditForm
                        ? Container(
                            width: 150,
                            alignment: Alignment.topLeft,
                            child: Text(
                              'Dark ',
                              style: miniBlackFontWeightStyle,
                            ))
                        : Container(
                        width: 230,
                            child: Column(
                            children: [
                              Row(
                                children: [
                                  Row(
                                    children: [
                                      Radio(
                                        groupValue: 0,
                                        value: 1,
                                        onChanged: (newValue) => setState(
                                            () => groupValues = newValue),
                                      ),
                                      Text(
                                        'Dark     ',
                                        style: miniBlackFontWeightStyle,
                                      )
                                    ],
                                  ),
                                  SizedBox(
                                    width: 5,
                                  ),
                                  Row(
                                    children: [
                                      Radio(
                                        groupValue: 1,
                                        value: 1,
                                        onChanged: (newValue) => setState(
                                          () => groupValues = newValue,
                                        ),
                                      ),
                                      Text(
                                        'Dusky ',
                                        style: miniBlackFontWeightStyle,
                                      )
                                    ],
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  Row(
                                    children: [
                                      Radio(
                                        groupValue: 0,
                                        value: 1,
                                        onChanged: (newValue) => setState(
                                            () => groupValues = newValue),
                                      ),
                                      Text(
                                        'Wheatish ',
                                        style: miniBlackFontWeightStyle,
                                      )
                                    ],
                                  ),
                                  SizedBox(
                                    width: 5,
                                  ),
                                  Row(
                                    children: [
                                      Radio(
                                        groupValue: 1,
                                        value: 0,
                                        onChanged: (newValue) => setState(
                                          () => groupValues = newValue,
                                        ),
                                      ),
                                      Text(
                                        'Fair ',
                                        style: miniBlackFontWeightStyle,
                                      )
                                    ],
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  Row(
                                    children: [
                                      Radio(
                                        groupValue: 0,
                                        value: 1,
                                        onChanged: (newValue) => setState(
                                            () => groupValues = newValue),
                                      ),
                                      Text(
                                        'Very Fair         ',
                                        style: miniBlackFontWeightStyle,
                                      )
                                    ],
                                  ),
                                  SizedBox(
                                    width: 5,
                                  ),
                                  Row(
                                    children: [
                                      Text(
                                        '           ',
                                        style: miniBlackFontWeightStyle,
                                      )
                                    ],
                                  ),
                                ],
                              ),
                            ],
                          )),
                  ],
                ),
                SizedBox(
                  height: 5,
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      child: Text(
                        'Eating Habits: ',
                        style: miniBlackBoldFontWeightStyle,
                      ),
                    ),
                    personalEditForm
                        ? Container(
                            width: 150,
                            alignment: Alignment.topLeft,
                            child: Text(
                              'Eggetarian ',
                              style: miniBlackFontWeightStyle,
                            ))
                        : Container(
                            width: 230,
                            child: Column(
                              children: [
                                Row(
                                  children: [
                                    Radio(
                                      groupValue: 0,
                                      value: 1,
                                      onChanged: (newValue) => setState(
                                          () => groupValues = newValue),
                                    ),
                                    Text(
                                      'Vegetarian     ',
                                      style: miniBlackFontWeightStyle,
                                    )
                                  ],
                                ),
                                Row(
                                  children: [
                                    Radio(
                                      groupValue: 0,
                                      value: 1,
                                      onChanged: (newValue) => setState(
                                          () => groupValues = newValue),
                                    ),
                                    Text(
                                      'Non Vegetarian     ',
                                      style: miniBlackFontWeightStyle,
                                    )
                                  ],
                                ),
                                Row(
                                  children: [
                                    Radio(
                                      groupValue: 0,
                                      value: 1,
                                      onChanged: (newValue) => setState(
                                          () => groupValues = newValue),
                                    ),
                                    Text(
                                      'Eggetarian     ',
                                      style: miniBlackFontWeightStyle,
                                    )
                                  ],
                                ),
                                Row(
                                  children: [
                                    Radio(
                                      groupValue: 0,
                                      value: 1,
                                      onChanged: (newValue) => setState(
                                          () => groupValues = newValue),
                                    ),
                                    Text(
                                      'Vegan     ',
                                      style: miniBlackFontWeightStyle,
                                    )
                                  ],
                                ),
                                Row(
                                  children: [
                                    Radio(
                                      groupValue: 0,
                                      value: 1,
                                      onChanged: (newValue) => setState(
                                          () => groupValues = newValue),
                                    ),
                                    Text(
                                      'Jain Vegetarian     ',
                                      style: miniBlackFontWeightStyle,
                                    )
                                  ],
                                ),
                                Row(
                                  children: [
                                    Radio(
                                      groupValue: 0,
                                      value: 1,
                                      onChanged: (newValue) => setState(
                                          () => groupValues = newValue),
                                    ),
                                    Text(
                                      'Buddhist Vegetarian     ',
                                      style: miniBlackFontWeightStyle,
                                    )
                                  ],
                                ),
                              ],
                            )),
                  ],
                ),
                SizedBox(
                  height: 5,
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      child: Text(
                        'Drinking Habits: ',
                        style: miniBlackBoldFontWeightStyle,
                      ),
                    ),
                    personalEditForm
                        ? Container(
                            width: 150,
                            alignment: Alignment.topLeft,
                            child: Text(
                              'Drink ',
                              style: miniBlackFontWeightStyle,
                            ))
                        : Container(
                            width: 230,
                            child: Column(
                              children: [
                                Row(
                                  children: [
                                    Radio(
                                      groupValue: 0,
                                      value: 1,
                                      onChanged: (newValue) => setState(
                                          () => groupValues = newValue),
                                    ),
                                    Text(
                                      'Drink     ',
                                      style: miniBlackFontWeightStyle,
                                    )
                                  ],
                                ),
                                Row(
                                  children: [
                                    Radio(
                                      groupValue: 0,
                                      value: 1,
                                      onChanged: (newValue) => setState(
                                          () => groupValues = newValue),
                                    ),
                                    Text(
                                      'Socially Drink    ',
                                      style: miniBlackFontWeightStyle,
                                    )
                                  ],
                                ),
                                Row(
                                  children: [
                                    Radio(
                                      groupValue: 0,
                                      value: 1,
                                      onChanged: (newValue) => setState(
                                          () => groupValues = newValue),
                                    ),
                                    Text(
                                      'Do not Drink      ',
                                      style: miniBlackFontWeightStyle,
                                    )
                                  ],
                                ),
                              ],
                            )),
                  ],
                ),
                SizedBox(
                  height: 5,
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      child: Text(
                        'Smoking Habits: ',
                        style: miniBlackBoldFontWeightStyle,
                      ),
                    ),
                    personalEditForm
                        ? Container(
                            width: 150,
                            alignment: Alignment.topLeft,
                            child: Text(
                              'Smoke ',
                              style: miniBlackFontWeightStyle,
                            ))
                        : Container(
                            width: 230,
                            child: Column(
                              children: [
                                Row(
                                  children: [
                                    Radio(
                                      groupValue: 0,
                                      value: 1,
                                      onChanged: (newValue) => setState(
                                          () => groupValues = newValue),
                                    ),
                                    Text(
                                      'Smoke     ',
                                      style: miniBlackFontWeightStyle,
                                    )
                                  ],
                                ),
                                Row(
                                  children: [
                                    Radio(
                                      groupValue: 0,
                                      value: 1,
                                      onChanged: (newValue) => setState(
                                          () => groupValues = newValue),
                                    ),
                                    Text(
                                      'Socially Smoke    ',
                                      style: miniBlackFontWeightStyle,
                                    )
                                  ],
                                ),
                                Row(
                                  children: [
                                    Radio(
                                      groupValue: 0,
                                      value: 1,
                                      onChanged: (newValue) => setState(
                                          () => groupValues = newValue),
                                    ),
                                    Text(
                                      'Do not Smoke      ',
                                      style: miniBlackFontWeightStyle,
                                    )
                                  ],
                                ),
                              ],
                            )),
                  ],
                ),
                SizedBox(
                  height: 5,
                ),
                personalEditForm
                    ? SizedBox(
                        height: 5,
                      )
                    : SizedBox(
                        height: 35,
                      ),
                personalEditForm
                    ? SizedBox(
                        width: 0,
                      )
                    : GestureDetector(
                        onTap: () {
                          setState(() {
                            personalEditForm = false;
                          });
                        },
                        child: Container(
                          margin: EdgeInsets.only(
                              left: screenSize.width * 0.3,
                              right: screenSize.width * 0.3),
                          width: 100,
                          height: 50,
                          decoration: BoxDecoration(
                            color: appColor,
                            borderRadius: BorderRadius.circular(23.0),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text(
                                'Save',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: white,
                                  fontSize: 16,
                                ),
                              ),
                            ],
                          ),
                        ),
                      )
              ],
            ),
          )
        ]);

    var familyDetails = custom.ExpansionTile(
        headerBackgroundColor: headerBackgroundColor,
        title: getTitleRow(2, screenSize, familyEdit),
        trailing: familyEdit
            ? Container(
                width: 60,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    GestureDetector(
                        onTap: () {
                          setState(() {
                            familyEditForm = !familyEditForm;
                          });
                        },
                        child: AssetImageWidget(
                          image: 'assets/pencil.svg',
                          width: 25,
                          height: 25,
                        )),
                    SizedBox(width: 10),
                    Icon(Icons.arrow_forward_ios),
                  ],
                ),
              )
            : Icon(Icons.arrow_forward_ios),
        onExpansionChanged: (val) {
          setState(() {
            familyEdit = val;
          });
        },
        children: [
          Container(
            padding: EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: white,
              borderRadius: BorderRadius.only(
                  bottomRight: Radius.circular(10),
                  bottomLeft: Radius.circular(10)),
            ),
            child: ListView(
              shrinkWrap: true,
              primary: false,
              children: [
                SizedBox(
                  height: 10,
                ),
                Text(
                  'About My Family: ',
                  style: headingBlackStyle,
                ),
                SizedBox(height: 5),
                familyEditForm
                    ? Text(
                        'We are lovable five.We are lovable five. We are lovable five. We are  lovable five. We are lovable five. We are  lovable five. We are lovable five.')
                    : TextField(
                        maxLines: 5,
                        decoration: new InputDecoration(
                          fillColor: appColor,
                          border: new OutlineInputBorder(
                              borderSide: new BorderSide(color: Colors.black)),
                        ),
                      ),
                SizedBox(
                  height: 20,
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          child: Text(
                            'Family Type: ',
                            style: miniBlackBoldFontWeightStyle,
                          ),
                        ),
                        familyEditForm
                            ? Container(
                                width: 150,
                                alignment: Alignment.topLeft,
                                child: Text(
                                  'Nuclear ',
                                  style: miniBlackFontWeightStyle,
                                ))
                            : Container(
                                width: 205,
                                child: Column(
                                  children: [
                                    Row(
                                      children: [
                                        Row(
                                          children: [
                                            Container(
                                              child: Radio(
                                                groupValue: 0,
                                                value: 1,
                                                onChanged: (newValue) =>
                                                    setState(() =>
                                                        groupValues = newValue),
                                              ),
                                              width: 25,
                                            ),
                                            Text(
                                              'Nuclear ',
                                              style: miniBlackFontWeightStyle,
                                            )
                                          ],
                                        ),
                                        SizedBox(
                                          width: 5,
                                        ),
                                        Row(
                                          children: [
                                            Container(
                                              child: Radio(
                                                groupValue: 1,
                                                value: 1,
                                                onChanged: (newValue) =>
                                                    setState(
                                                  () => groupValues = newValue,
                                                ),
                                              ),
                                              width: 25,
                                            ),
                                            Text(
                                              'Joint ',
                                              style: miniBlackFontWeightStyle,
                                            )
                                          ],
                                        ),
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        Row(
                                          children: [
                                            Container(
                                              child: Radio(
                                                groupValue: 0,
                                                value: 1,
                                                onChanged: (newValue) =>
                                                    setState(() =>
                                                        groupValues = newValue),
                                              ),
                                              width: 25,
                                            ),
                                            Text(
                                              'Extended ',
                                              style: miniBlackFontWeightStyle,
                                            )
                                          ],
                                        ),
                                        SizedBox(
                                          width: 5,
                                        ),
                                        Row(
                                          children: [
                                            Text(
                                              ' ',
                                              style: miniBlackFontWeightStyle,
                                            )
                                          ],
                                        ),
                                      ],
                                    ),
                                  ],
                                ))
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          child: Text(
                            'Family Values: ',
                            style: miniBlackBoldFontWeightStyle,
                          ),
                        ),
                        familyEditForm
                            ? Container(
                                width: 150,
                                alignment: Alignment.topLeft,
                                child: Text(
                                  'Above Middle ',
                                  style: miniBlackFontWeightStyle,
                                ))
                            : Container(
                                width: 205,
                                child: Column(
                                  children: [
                                    Row(
                                      children: [
                                        Container(
                                          child: Radio(
                                            groupValue: 0,
                                            value: 1,
                                            onChanged: (newValue) => setState(
                                                () => groupValues = newValue),
                                          ),
                                          width: 25,
                                        ),
                                        Text(
                                          'Conservative ',
                                          style: miniBlackFontWeightStyle,
                                        )
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        Container(
                                          child: Radio(
                                            groupValue: 0,
                                            value: 1,
                                            onChanged: (newValue) => setState(
                                                () => groupValues = newValue),
                                          ),
                                          width: 25,
                                        ),
                                        Text(
                                          'Liberal ',
                                          style: miniBlackFontWeightStyle,
                                        )
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        Container(
                                          child: Radio(
                                            groupValue: 0,
                                            value: 1,
                                            onChanged: (newValue) => setState(
                                                () => groupValues = newValue),
                                          ),
                                          width: 25,
                                        ),
                                        Text(
                                          'Moderate ',
                                          style: miniBlackFontWeightStyle,
                                        )
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        Container(
                                          child: Radio(
                                            groupValue: 0,
                                            value: 1,
                                            onChanged: (newValue) => setState(
                                                () => groupValues = newValue),
                                          ),
                                          width: 25,
                                        ),
                                        Text(
                                          'Traditional ',
                                          style: miniBlackFontWeightStyle,
                                        )
                                      ],
                                    ),
                                  ],
                                ))
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          child: Text(
                            'Family Status: ',
                            style: miniBlackBoldFontWeightStyle,
                          ),
                        ),
                        familyEditForm
                            ? Container(
                                width: 150,
                                alignment: Alignment.topLeft,
                                child: Text(
                                  'Above Middle ',
                                  style: miniBlackFontWeightStyle,
                                ))
                            : Container(
                                width: 205,
                                child: Column(
                                  children: [
                                    Row(
                                      children: [
                                        Container(
                                          child: Radio(
                                            groupValue: 0,
                                            value: 1,
                                            onChanged: (newValue) => setState(
                                                () => groupValues = newValue),
                                          ),
                                          width: 25,
                                        ),
                                        Text(
                                          'Below middle ',
                                          style: miniBlackFontWeightStyle,
                                        )
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        Container(
                                          child: Radio(
                                            groupValue: 0,
                                            value: 1,
                                            onChanged: (newValue) => setState(
                                                () => groupValues = newValue),
                                          ),
                                          width: 25,
                                        ),
                                        Text(
                                          'Above Middle ',
                                          style: miniBlackFontWeightStyle,
                                        )
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        Container(
                                          child: Radio(
                                            groupValue: 0,
                                            value: 1,
                                            onChanged: (newValue) => setState(
                                                () => groupValues = newValue),
                                          ),
                                          width: 25,
                                        ),
                                        Text(
                                          'Middle class ',
                                          style: miniBlackFontWeightStyle,
                                        )
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        Container(
                                          child: Radio(
                                            groupValue: 0,
                                            value: 1,
                                            onChanged: (newValue) => setState(
                                                () => groupValues = newValue),
                                          ),
                                          width: 25,
                                        ),
                                        Text(
                                          'Rich ',
                                          style: miniBlackFontWeightStyle,
                                        )
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        Container(
                                          child: Radio(
                                            groupValue: 0,
                                            value: 1,
                                            onChanged: (newValue) => setState(
                                                () => groupValues = newValue),
                                          ),
                                          width: 25,
                                        ),
                                        Text(
                                          'Ultra Rich ',
                                          style: miniBlackFontWeightStyle,
                                        )
                                      ],
                                    ),
                                  ],
                                ))
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Container(
                          child: Text(
                            'Father Occupation:',
                            style: miniBlackBoldFontWeightStyle,
                          ),
                        ),
                        familyEditForm
                            ? Container(
                                width: 150,
                                alignment: Alignment.topLeft,
                                child: Text(
                                  'Sanjay ',
                                  style: miniBlackFontWeightStyle,
                                ))
                            : Container(
                                width: 200,
                                height: 50,
                                child: TextField(
                                    decoration: new InputDecoration(
                                      fillColor: appColor,
                                      border: new OutlineInputBorder(
                                          borderSide: new BorderSide(
                                              color: Colors.black)),
                                    ),
                                    controller: lastName),
                              )
                      ],
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Container(
                          child: Text(
                            'Mothers Occupation:',
                            style: miniBlackBoldFontWeightStyle,
                          ),
                        ),
                        familyEditForm
                            ? Container(
                                width: 150,
                                alignment: Alignment.topLeft,
                                child: Text(
                                  ' ',
                                  style: miniBlackFontWeightStyle,
                                ))
                            : Container(
                                width: 200,
                                height: 50,
                                child: TextField(
                                    decoration: new InputDecoration(
                                      fillColor: appColor,
                                      border: new OutlineInputBorder(
                                          borderSide: new BorderSide(
                                              color: Colors.black)),
                                    ),
                                    controller: lastName),
                              )
                      ],
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Container(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'Siblings:',
                        style: miniBlackBoldFontWeightStyle,
                      ),
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Container(
                          child: Text(
                            'Brothers:',
                            style: miniBlackBoldFontWeightStyle,
                          ),
                        ),
                        familyEditForm
                            ? Container(
                                width: 150,
                                alignment: Alignment.topLeft,
                                child: Text(
                                  ' ',
                                  style: miniBlackFontWeightStyle,
                                ))
                            : Row(
                                children: [
                                  Container(
                                    width: 60,
                                    height: 50,
                                    child: TextField(
                                        decoration: new InputDecoration(
                                          fillColor: appColor,
                                          border: new OutlineInputBorder(
                                              borderSide: new BorderSide(
                                                  color: Colors.black)),
                                        ),
                                        controller: lastName),
                                  ),
                                  Container(
                                    padding: EdgeInsets.only(left: 5, right: 5),
                                    child: Text(
                                      'of',
                                    ),
                                  ),
                                  Container(
                                    width: 60,
                                    height: 50,
                                    child: TextField(
                                        decoration: new InputDecoration(
                                          fillColor: appColor,
                                          border: new OutlineInputBorder(
                                              borderSide: new BorderSide(
                                                  color: Colors.black)),
                                        ),
                                        controller: lastName),
                                  ),
                                  Container(
                                    padding: EdgeInsets.only(
                                      left: 5,
                                    ),
                                    child: Text(
                                      'Married',
                                    ),
                                  ),
                                ],
                              )
                      ],
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Container(
                          child: Text(
                            'Sisters:',
                            style: miniBlackBoldFontWeightStyle,
                          ),
                        ),
                        familyEditForm
                            ? Container(
                                width: 150,
                                alignment: Alignment.topLeft,
                                child: Text(
                                  ' ',
                                  style: miniBlackFontWeightStyle,
                                ))
                            : Row(
                                children: [
                                  Container(
                                    width: 60,
                                    height: 50,
                                    child: TextField(
                                        decoration: new InputDecoration(
                                          fillColor: appColor,
                                          border: new OutlineInputBorder(
                                              borderSide: new BorderSide(
                                                  color: Colors.black)),
                                        ),
                                        controller: lastName),
                                  ),
                                  Container(
                                    padding: EdgeInsets.only(left: 5, right: 5),
                                    child: Text(
                                      'of',
                                    ),
                                  ),
                                  Container(
                                    width: 60,
                                    height: 50,
                                    child: TextField(
                                        decoration: new InputDecoration(
                                          fillColor: appColor,
                                          border: new OutlineInputBorder(
                                              borderSide: new BorderSide(
                                                  color: Colors.black)),
                                        ),
                                        controller: lastName),
                                  ),
                                  Container(
                                    padding: EdgeInsets.only(
                                      left: 5,
                                    ),
                                    child: Text(
                                      'Married',
                                    ),
                                  ),
                                ],
                              )
                      ],
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    familyEditForm
                        ? SizedBox(
                            height: 5,
                          )
                        : SizedBox(
                            height: 35,
                          ),
                    familyEditForm
                        ? SizedBox(
                            width: 0,
                          )
                        : GestureDetector(
                            onTap: () {
                              setState(() {
                                familyEditForm = false;
                              });
                            },
                            child: Container(
                              margin: EdgeInsets.only(
                                  left: screenSize.width * 0.3,
                                  right: screenSize.width * 0.3),
                              width: 100,
                              height: 50,
                              decoration: BoxDecoration(
                                color: appColor,
                                borderRadius: BorderRadius.circular(23.0),
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Text(
                                    'Save',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: white,
                                      fontSize: 16,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          )
                  ],
                ),
              ],
            ),
          )
        ]);

    var favourites = custom.ExpansionTile(
        headerBackgroundColor: headerBackgroundColor,
        title: getTitleRow(3, screenSize, favEdit),
        trailing: favEdit
            ? Container(
                width: 60,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    GestureDetector(
                        onTap: () {
                          setState(() {
                            favEditForm = !favEditForm;
                          });
                        },
                        child: AssetImageWidget(
                          image: 'assets/pencil.svg',
                          width: 25,
                          height: 25,
                        )),
                    SizedBox(width: 10),
                    Icon(Icons.arrow_forward_ios),
                  ],
                ),
              )
            : Icon(Icons.arrow_forward_ios),
        onExpansionChanged: (val) {
          setState(() {
            favEdit = val;
          });
        },
        children: [
          Container(
            padding: EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: white,
              borderRadius: BorderRadius.only(
                  bottomRight: Radius.circular(10),
                  bottomLeft: Radius.circular(10)),
            ),
            child: ListView(
              shrinkWrap: true,
              primary: false,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    //Music
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          child: Text(
                            'Music: ',
                            style: miniBlackBoldFontWeightStyle,
                          ),
                        ),
                        favEditForm
                            ? Container(
                                width: 150,
                                alignment: Alignment.topLeft,
                                child: Text(
                                  'Melody ',
                                  style: miniBlackFontWeightStyle,
                                ))
                            : Container(
                                width: 280,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    // [Monday] checkbox
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Container(
                                          width: 120,
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              Container(
                                                width: 30,
                                                child: Checkbox(
                                                  value: valMonday,
                                                  onChanged: (bool value) {
                                                    setState(() {
                                                      valMonday = value;
                                                      valTuesday = false;
                                                      valWednesday = false;
                                                    });
                                                  },
                                                ),
                                              ),
                                              Text("Moledy"),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          width: 120,
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              Container(
                                                width: 30,
                                                child: Checkbox(
                                                  value: valMonday,
                                                  onChanged: (bool value) {
                                                    setState(() {
                                                      valMonday = value;
                                                      valTuesday = false;
                                                      valWednesday = false;
                                                    });
                                                  },
                                                ),
                                              ),
                                              Text("Pop"),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),

                                    // [Tuesday] checkbox
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Container(
                                          width: 120,
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              Container(
                                                width: 30,
                                                child: Checkbox(
                                                  value: valMonday,
                                                  onChanged: (bool value) {
                                                    setState(() {
                                                      valMonday = value;
                                                      valTuesday = false;
                                                      valWednesday = false;
                                                    });
                                                  },
                                                ),
                                              ),
                                              Text("Rock"),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          width: 120,
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              Container(
                                                width: 30,
                                                child: Checkbox(
                                                  value: valMonday,
                                                  onChanged: (bool value) {
                                                    setState(() {
                                                      valMonday = value;
                                                      valTuesday = false;
                                                      valWednesday = false;
                                                    });
                                                  },
                                                ),
                                              ),
                                              Text("Classical"),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
//3
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Container(
                                          width: 120,
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              Container(
                                                width: 30,
                                                child: Checkbox(
                                                  value: valMonday,
                                                  onChanged: (bool value) {
                                                    setState(() {
                                                      valMonday = value;
                                                      valTuesday = false;
                                                      valWednesday = false;
                                                    });
                                                  },
                                                ),
                                              ),
                                              Text("R&B"),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          width: 120,
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              Container(
                                                width: 30,
                                                child: Checkbox(
                                                  value: valMonday,
                                                  onChanged: (bool value) {
                                                    setState(() {
                                                      valMonday = value;
                                                      valTuesday = false;
                                                      valWednesday = false;
                                                    });
                                                  },
                                                ),
                                              ),
                                              Text("Folk"),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
//
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Container(
                                          width: 120,
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              Container(
                                                width: 30,
                                                child: Checkbox(
                                                  value: valMonday,
                                                  onChanged: (bool value) {
                                                    setState(() {
                                                      valMonday = value;
                                                      valTuesday = false;
                                                      valWednesday = false;
                                                    });
                                                  },
                                                ),
                                              ),
                                              Text("Electronic"),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          width: 120,
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              Container(
                                                width: 30,
                                                child: Checkbox(
                                                  value: valMonday,
                                                  onChanged: (bool value) {
                                                    setState(() {
                                                      valMonday = value;
                                                      valTuesday = false;
                                                      valWednesday = false;
                                                    });
                                                  },
                                                ),
                                              ),
                                              Text("Rap"),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
//5
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Container(
                                          width: 120,
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              Container(
                                                width: 30,
                                                child: Checkbox(
                                                  value: valMonday,
                                                  onChanged: (bool value) {
                                                    setState(() {
                                                      valMonday = value;
                                                      valTuesday = false;
                                                      valWednesday = false;
                                                    });
                                                  },
                                                ),
                                              ),
                                              Text("Blue"),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          width: 120,
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              Container(
                                                width: 30,
                                              ),
                                              Text(""),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ))
                      ],
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    //Sports
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          child: Text(
                            'Sports: ',
                            style: miniBlackBoldFontWeightStyle,
                          ),
                        ),
                        favEditForm
                            ? Container(
                                width: 150,
                                alignment: Alignment.topLeft,
                                child: Text(
                                  'Cricket ',
                                  style: miniBlackFontWeightStyle,
                                ))
                            : Container(
                                width: 280,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    // [Monday] checkbox
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Container(
                                          width: 120,
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              Container(
                                                width: 30,
                                                child: Checkbox(
                                                  value: valMonday,
                                                  onChanged: (bool value) {
                                                    setState(() {
                                                      valMonday = value;
                                                      valTuesday = false;
                                                      valWednesday = false;
                                                    });
                                                  },
                                                ),
                                              ),
                                              Text("Cricket"),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          width: 120,
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              Container(
                                                width: 30,
                                                child: Checkbox(
                                                  value: valMonday,
                                                  onChanged: (bool value) {
                                                    setState(() {
                                                      valMonday = value;
                                                      valTuesday = false;
                                                      valWednesday = false;
                                                    });
                                                  },
                                                ),
                                              ),
                                              Text("Football"),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                    // [Tuesday] checkbox
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Container(
                                          width: 120,
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              Container(
                                                width: 30,
                                                child: Checkbox(
                                                  value: valMonday,
                                                  onChanged: (bool value) {
                                                    setState(() {
                                                      valMonday = value;
                                                      valTuesday = false;
                                                      valWednesday = false;
                                                    });
                                                  },
                                                ),
                                              ),
                                              Text("Tennis"),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          width: 120,
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              Container(
                                                width: 30,
                                                child: Checkbox(
                                                  value: valMonday,
                                                  onChanged: (bool value) {
                                                    setState(() {
                                                      valMonday = value;
                                                      valTuesday = false;
                                                      valWednesday = false;
                                                    });
                                                  },
                                                ),
                                              ),
                                              Text("Badminton"),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
//3
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Container(
                                          width: 250,
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              Text("Others"),
                                              SizedBox(
                                                width: 15,
                                              ),
                                              Container(
                                                width: 170,
                                                height: 50,
                                                child: TextField(
                                                    decoration:
                                                        new InputDecoration(
                                                      fillColor: appColor,
                                                      border: new OutlineInputBorder(
                                                          borderSide:
                                                              new BorderSide(
                                                                  color: Colors
                                                                      .black)),
                                                    ),
                                                    controller: firstName),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ))
                      ],
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          child: Text(
                            'Sports: ',
                            style: miniBlackBoldFontWeightStyle,
                          ),
                        ),
                        favEditForm
                            ? Container(
                                width: 150,
                                alignment: Alignment.topLeft,
                                child: Text(
                                  'Cricket ',
                                  style: miniBlackFontWeightStyle,
                                ))                              : Container(
                                width: 280,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    // [Monday] checkbox
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        Container(
                                          width: 30,
                                          child: Checkbox(
                                            value: valMonday,
                                            onChanged: (bool value) {
                                              setState(() {
                                                valMonday = value;
                                                valTuesday = false;
                                                valWednesday = false;
                                              });
                                            },
                                          ),
                                        ),
                                        Text("Spend time with Family"),
                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        Container(
                                          width: 30,
                                          child: Checkbox(
                                            value: valMonday,
                                            onChanged: (bool value) {
                                              setState(() {
                                                valMonday = value;
                                                valTuesday = false;
                                                valWednesday = false;
                                              });
                                            },
                                          ),
                                        ),
                                        Text("Hangout with Family"),
                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        Container(
                                          width: 30,
                                          child: Checkbox(
                                            value: valMonday,
                                            onChanged: (bool value) {
                                              setState(() {
                                                valMonday = value;
                                                valTuesday = false;
                                                valWednesday = false;
                                              });
                                            },
                                          ),
                                        ),
                                        Text("Watch movies"),
                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        Container(
                                          width: 30,
                                          child: Checkbox(
                                            value: valMonday,
                                            onChanged: (bool value) {
                                              setState(() {
                                                valMonday = value;
                                                valTuesday = false;
                                                valWednesday = false;
                                              });
                                            },
                                          ),
                                        ),
                                        Text("Travelling"),
                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        Container(
                                          width: 30,
                                          child: Checkbox(
                                            value: valMonday,
                                            onChanged: (bool value) {
                                              setState(() {
                                                valMonday = value;
                                                valTuesday = false;
                                                valWednesday = false;
                                              });
                                            },
                                          ),
                                        ),
                                        Text("Reading Books"),
                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        Container(
                                          width: 30,
                                          child: Checkbox(
                                            value: valMonday,
                                            onChanged: (bool value) {
                                              setState(() {
                                                valMonday = value;
                                                valTuesday = false;
                                                valWednesday = false;
                                              });
                                            },
                                          ),
                                        ),
                                        Text("Social networking"),
                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        Container(
                                          width: 30,
                                          child: Checkbox(
                                            value: valMonday,
                                            onChanged: (bool value) {
                                              setState(() {
                                                valMonday = value;
                                                valTuesday = false;
                                                valWednesday = false;
                                              });
                                            },
                                          ),
                                        ),
                                        Text("Sleeping"),
                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        Container(
                                          width: 30,
                                          child: Checkbox(
                                            value: valMonday,
                                            onChanged: (bool value) {
                                              setState(() {
                                                valMonday = value;
                                                valTuesday = false;
                                                valWednesday = false;
                                              });
                                            },
                                          ),
                                        ),
                                        Text("Shopping"),
                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        Container(
                                          width: 30,
                                          child: Checkbox(
                                            value: valMonday,
                                            onChanged: (bool value) {
                                              setState(() {
                                                valMonday = value;
                                                valTuesday = false;
                                                valWednesday = false;
                                              });
                                            },
                                          ),
                                        ),
                                        Text("Play Sports"),
                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Container(
                                          width: 250,
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              Text("Others"),
                                              SizedBox(
                                                width: 15,
                                              ),
                                              Container(
                                                width: 170,
                                                height: 50,
                                                child: TextField(
                                                    decoration:
                                                        new InputDecoration(
                                                      fillColor: appColor,
                                                      border: new OutlineInputBorder(
                                                          borderSide:
                                                              new BorderSide(
                                                                  color: Colors
                                                                      .black)),
                                                    ),
                                                    controller: firstName),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ))
                      ],
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          child: Text(
                            'Movies: ',
                            style: miniBlackBoldFontWeightStyle,
                          ),
                        ),
                        favEditForm
                            ? Container(
                                width: 150,
                                alignment: Alignment.topLeft,
                                child: Text(
                                  'Comedy ',
                                  style: miniBlackFontWeightStyle,
                                ))
                            : Container(
                                width: 280,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    // [Monday] checkbox
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Container(
                                          width: 120,
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              Container(
                                                width: 30,
                                                child: Checkbox(
                                                  value: valMonday,
                                                  onChanged: (bool value) {
                                                    setState(() {
                                                      valMonday = value;
                                                      valTuesday = false;
                                                      valWednesday = false;
                                                    });
                                                  },
                                                ),
                                              ),
                                              Text("Comedy"),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          width: 120,
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              Container(
                                                width: 30,
                                                child: Checkbox(
                                                  value: valMonday,
                                                  onChanged: (bool value) {
                                                    setState(() {
                                                      valMonday = value;
                                                      valTuesday = false;
                                                      valWednesday = false;
                                                    });
                                                  },
                                                ),
                                              ),
                                              Text("Action"),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),

                                    // [Tuesday] checkbox
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Container(
                                          width: 120,
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              Container(
                                                width: 30,
                                                child: Checkbox(
                                                  value: valMonday,
                                                  onChanged: (bool value) {
                                                    setState(() {
                                                      valMonday = value;
                                                      valTuesday = false;
                                                      valWednesday = false;
                                                    });
                                                  },
                                                ),
                                              ),
                                              Text("Horror"),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          width: 120,
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              Container(
                                                width: 30,
                                                child: Checkbox(
                                                  value: valMonday,
                                                  onChanged: (bool value) {
                                                    setState(() {
                                                      valMonday = value;
                                                      valTuesday = false;
                                                      valWednesday = false;
                                                    });
                                                  },
                                                ),
                                              ),
                                              Text("Romantic"),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
//3
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Container(
                                          width: 140,
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              Container(
                                                width: 30,
                                                child: Checkbox(
                                                  value: valMonday,
                                                  onChanged: (bool value) {
                                                    setState(() {
                                                      valMonday = value;
                                                      valTuesday = false;
                                                      valWednesday = false;
                                                    });
                                                  },
                                                ),
                                              ),
                                              Text("Science Fiction"),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
//3
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Container(
                                          width: 250,
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              Text("Others"),
                                              SizedBox(
                                                width: 15,
                                              ),
                                              Container(
                                                width: 170,
                                                height: 50,
                                                child: TextField(
                                                    decoration:
                                                        new InputDecoration(
                                                      fillColor: appColor,
                                                      border: new OutlineInputBorder(
                                                          borderSide:
                                                              new BorderSide(
                                                                  color: Colors
                                                                      .black)),
                                                    ),
                                                    controller: firstName),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ))
                      ],
                    ),
//TimePAss
                    SizedBox(
                      height: 5,
                    ),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          child: Text(
                            'Movies: ',
                            style: miniBlackBoldFontWeightStyle,
                          ),
                        ),
                        favEditForm
                            ? Container(
                                width: 150,
                                alignment: Alignment.topLeft,
                                child: Text(
                                  'Comedy ',
                                  style: miniBlackFontWeightStyle,
                                ))
                            : Container(
                                width: 280,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    // [Monday] checkbox
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        Container(
                                          width: 30,
                                          child: Checkbox(
                                            value: valMonday,
                                            onChanged: (bool value) {
                                              setState(() {
                                                valMonday = value;
                                                valTuesday = false;
                                                valWednesday = false;
                                              });
                                            },
                                          ),
                                        ),
                                        Text("Jeans and Shirt"),
                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        Container(
                                          width: 30,
                                          child: Checkbox(
                                            value: valMonday,
                                            onChanged: (bool value) {
                                              setState(() {
                                                valMonday = value;
                                                valTuesday = false;
                                                valWednesday = false;
                                              });
                                            },
                                          ),
                                        ),
                                        Text("Formal wear"),
                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        Container(
                                          width: 30,
                                          child: Checkbox(
                                            value: valMonday,
                                            onChanged: (bool value) {
                                              setState(() {
                                                valMonday = value;
                                                valTuesday = false;
                                                valWednesday = false;
                                              });
                                            },
                                          ),
                                        ),
                                        Text("Kurta"),
                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Container(
                                          width: 250,
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              Text("Others"),
                                              SizedBox(
                                                width: 15,
                                              ),
                                              Container(
                                                width: 170,
                                                height: 50,
                                                child: TextField(
                                                    decoration:
                                                        new InputDecoration(
                                                      fillColor: appColor,
                                                      border: new OutlineInputBorder(
                                                          borderSide:
                                                              new BorderSide(
                                                                  color: Colors
                                                                      .black)),
                                                    ),
                                                    controller: firstName),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ))
                      ],
                    ),
//TimePAss
                    favEditForm
                        ? SizedBox(
                            height: 5,
                          )
                        : SizedBox(
                            height: 35,
                          ),
                    favEditForm
                        ? SizedBox(
                            width: 0,
                          )
                        : GestureDetector(
                            onTap: () {
                              setState(() {
                                favEditForm = false;
                              });
                            },
                            child: Container(
                              margin: EdgeInsets.only(
                                  left: screenSize.width * 0.3,
                                  right: screenSize.width * 0.3),
                              width: 100,
                              height: 50,
                              decoration: BoxDecoration(
                                color: appColor,
                                borderRadius: BorderRadius.circular(23.0),
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Text(
                                    'Save',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: white,
                                      fontSize: 16,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          )
                  ],
                ),
              ],
            ),
          )
        ]);

    var education = custom.ExpansionTile(
        headerBackgroundColor: headerBackgroundColor,
        title: getTitleRow(4, screenSize, eduEdit),
        trailing: eduEdit
            ? Container(
                width: 60,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    GestureDetector(
                        onTap: () {
                          setState(() {
                            eduEditForm = !eduEditForm;
                          });
                        },
                        child: AssetImageWidget(
                          image: 'assets/pencil.svg',
                          width: 25,
                          height: 25,
                        )),
                    SizedBox(width: 10),
                    Icon(Icons.arrow_forward_ios),
                  ],
                ),
              )
            : Icon(Icons.arrow_forward_ios),
        onExpansionChanged: (val) {
          setState(() {
            eduEdit = val;
          });
        },
        children: [
          Container(
            padding: EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: white,
              borderRadius: BorderRadius.only(
                  bottomRight: Radius.circular(10),
                  bottomLeft: Radius.circular(10)),
            ),
            child: ListView(
              shrinkWrap: true,
              primary: false,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(

                        ///  crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            child: Text(
                              'Highest Degree: ',
                              style: miniBlackBoldFontWeightStyle,
                            ),
                          ),
                          eduEditForm
                              ? Container(
                                  width: 150,
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    'M.D ',
                                    style: miniBlackFontWeightStyle,
                                  ))
                              : Container(
                                  width: 200,
                                  height: 50,
                                  child: TextField(
                                      decoration: new InputDecoration(
                                        fillColor: appColor,
                                        hintText: '',
                                        border: new OutlineInputBorder(
                                            borderSide: new BorderSide(
                                                color: Colors.black)),
                                      ),
                                      controller: firstName),
                                ),
                        ]),
                    SizedBox(
                      height: 5,
                    ),
                    Row(
                        //  crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            child: Text(
                              'Any Other Degree: ',
                              style: miniBlackBoldFontWeightStyle,
                            ),
                          ),
                          eduEditForm
                              ? Container(
                                  width: 150,
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    'Other',
                                    style: miniBlackFontWeightStyle,
                                  ))
                              : Container(
                                  width: 200,
                                  height: 50,
                                  child: DropdownButtonFormField<String>(
                                    decoration: InputDecoration(
                                        border: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.grey))),
                                    onTap: () {
                                      FocusScope.of(context).unfocus();
                                    },
                                    value: martialStatus,
                                    //  hint: Text('(India)+91'),
                                    style: smallGreyTextStyle,
                                    items: martialStatusDropDown,
                                    onChanged: (item) {
                                      setState(() {
                                        martialStatus = item;
                                        isMartialStatus = false;
                                      });
                                    },
                                    isExpanded: true,
                                    icon: Icon(Icons.keyboard_arrow_down),
                                  ),
                                ),
                        ]),
                    SizedBox(
                      height: 5,
                    ),
                    //Empl
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          child: Text(
                            'Employed In: ',
                            style: miniBlackBoldFontWeightStyle,
                          ),
                        ),
                        eduEditForm
                            ? Container(
                                width: 150,
                                alignment: Alignment.topLeft,
                                child: Text(
                                  'Government job ',
                                  style: miniBlackFontWeightStyle,
                                ))
                            : Container(
                                width: 200,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    // [Monday] checkbox
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        Container(
                                          width: 30,
                                          child: Radio(
                                            value: valMonday,
                                            groupValue: 1,
                                            onChanged: (value) {
                                              setState(() {
                                                valMonday = true;
                                                valTuesday = false;
                                                valWednesday = false;
                                              });
                                            },
                                          ),
                                        ),
                                        Text("Government job"),
                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        Container(
                                          width: 30,
                                          child: Radio(
                                            value: valMonday,
                                            groupValue: 1,
                                            onChanged: (value) {
                                              setState(() {
                                                valMonday = true;
                                                valTuesday = false;
                                                valWednesday = false;
                                              });
                                            },
                                          ),
                                        ),
                                        Text("Private job"),
                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        Container(
                                          width: 30,
                                          child: Radio(
                                            value: valMonday,
                                            groupValue: 1,
                                            onChanged: (value) {
                                              setState(() {
                                                valMonday = true;
                                                valTuesday = false;
                                                valWednesday = false;
                                              });
                                            },
                                          ),
                                        ),
                                        Text("Own bussiness"),
                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        Container(
                                          width: 30,
                                          child: Radio(
                                            value: valMonday,
                                            groupValue: 1,
                                            onChanged: (value) {
                                              setState(() {
                                                valMonday = true;
                                                valTuesday = false;
                                                valWednesday = false;
                                              });
                                            },
                                          ),
                                        ),
                                        Text("Not working"),
                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        Container(
                                          width: 30,
                                          child: Radio(
                                            value: valMonday,
                                            groupValue: 1,
                                            onChanged: (value) {
                                              setState(() {
                                                valMonday = true;
                                                valTuesday = false;
                                                valWednesday = false;
                                              });
                                            },
                                          ),
                                        ),
                                        Text("Job trials"),
                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        Container(
                                          width: 30,
                                          child: Radio(
                                            value: valMonday,
                                            groupValue: 1,
                                            onChanged: (value) {
                                              setState(() {
                                                valMonday = true;
                                                valTuesday = false;
                                                valWednesday = false;
                                              });
                                            },
                                          ),
                                        ),
                                        Text("Sports Person"),
                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        Container(
                                          width: 30,
                                          child: Radio(
                                            value: valMonday,
                                            groupValue: 1,
                                            onChanged: (value) {
                                              setState(() {
                                                valMonday = true;
                                                valTuesday = false;
                                                valWednesday = false;
                                              });
                                            },
                                          ),
                                        ),
                                        Text("Other"),
                                      ],
                                    ),
                                  ],
                                ))
                      ],
                    ),
//TimePAss
                    SizedBox(
                      height: 5,
                    ),

                    Row(
                        //  crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            child: Text(
                              'Profession: ',
                              style: miniBlackBoldFontWeightStyle,
                            ),
                          ),
                          eduEditForm
                              ? Container(
                                  width: 150,
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    'Developer',
                                    style: miniBlackFontWeightStyle,
                                  ))
                              : Container(
                                  width: 200,
                                  height: 50,
                                  child: DropdownButtonFormField<String>(
                                    decoration: InputDecoration(
                                        border: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.grey))),
                                    onTap: () {
                                      FocusScope.of(context).unfocus();
                                    },
                                    value: martialStatus,
                                    //  hint: Text('(India)+91'),
                                    style: smallGreyTextStyle,
                                    items: martialStatusDropDown,
                                    onChanged: (item) {
                                      setState(() {
                                        martialStatus = item;
                                        isMartialStatus = false;
                                      });
                                    },
                                    isExpanded: true,
                                    icon: Icon(Icons.keyboard_arrow_down),
                                  ),
                                ),
                        ]),
                    SizedBox(
                      height: 5,
                    ),
                    Row(

                        ///  crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            child: Text(
                              'Other Occupation: ',
                              style: miniBlackBoldFontWeightStyle,
                            ),
                          ),
                          eduEditForm
                              ? Container(
                                  width: 150,
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    '',
                                    style: miniBlackFontWeightStyle,
                                  ))
                              : Container(
                                  width: 200,
                                  height: 50,
                                  child: TextField(
                                      decoration: new InputDecoration(
                                        fillColor: appColor,
                                        hintText: '',
                                        border: new OutlineInputBorder(
                                            borderSide: new BorderSide(
                                                color: Colors.black)),
                                      ),
                                      controller: firstName),
                                ),
                        ]),
                    SizedBox(
                      height: 5,
                    ),
                    Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            child: Text(
                              'Salary: ',
                              style: miniBlackBoldFontWeightStyle,
                            ),
                          ),
                          eduEditForm
                              ? Container(
                                  width: 150,
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    '400 usd',
                                    style: miniBlackFontWeightStyle,
                                  ))
                              : Column(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Container(
                                      width: 200,
                                      height: 50,
                                      child: TextField(
                                          decoration: new InputDecoration(
                                            fillColor: appColor,
                                            hintText: '',
                                            border: new OutlineInputBorder(
                                                borderSide: new BorderSide(
                                                    color: Colors.black)),
                                          ),
                                          controller: firstName),
                                    ),
                                    SizedBox(
                                      height: 5,
                                    ),
                                    Container(
                                      width: 200,
                                      height: 50,
                                      child: DropdownButtonFormField<String>(
                                        decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                                borderSide: BorderSide(
                                                    color: Colors.grey))),
                                        onTap: () {
                                          FocusScope.of(context).unfocus();
                                        },
                                        value: martialStatus,
                                        //  hint: Text('(India)+91'),
                                        style: smallGreyTextStyle,
                                        items: martialStatusDropDown,
                                        onChanged: (item) {
                                          setState(() {
                                            martialStatus = item;
                                            isMartialStatus = false;
                                          });
                                        },
                                        isExpanded: true,
                                        icon: Icon(Icons.keyboard_arrow_down),
                                      ),
                                    ),
                                    SizedBox(
                                      height: 5,
                                    ),
                                    Container(
                                      width: 200,
                                      height: 50,
                                      child: DropdownButtonFormField<String>(
                                        decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                                borderSide: BorderSide(
                                                    color: Colors.grey))),
                                        onTap: () {
                                          FocusScope.of(context).unfocus();
                                        },
                                        value: martialStatus,
                                        //  hint: Text('(India)+91'),
                                        style: smallGreyTextStyle,
                                        items: martialStatusDropDown,
                                        onChanged: (item) {
                                          setState(() {
                                            martialStatus = item;
                                            isMartialStatus = false;
                                          });
                                        },
                                        isExpanded: true,
                                        icon: Icon(Icons.keyboard_arrow_down),
                                      ),
                                    ),
                                  ],
                                )
                        ]),
                    SizedBox(
                      height: 5,
                    ),
                    eduEditForm
                        ? SizedBox(
                            height: 5,
                          )
                        : SizedBox(
                            height: 35,
                          ),
                    eduEditForm
                        ? SizedBox(
                            width: 0,
                          )
                        : GestureDetector(
                            onTap: () {
                              setState(() {
                                favEditForm = false;
                              });
                            },
                            child: Container(
                              margin: EdgeInsets.only(
                                  left: screenSize.width * 0.3,
                                  right: screenSize.width * 0.3),
                              width: 100,
                              height: 50,
                              decoration: BoxDecoration(
                                color: appColor,
                                borderRadius: BorderRadius.circular(23.0),
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Text(
                                    'Save',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: white,
                                      fontSize: 16,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          )
                  ],
                ),
              ],
            ),
          )
        ]);

    var astrological = custom.ExpansionTile(
        headerBackgroundColor: headerBackgroundColor,
        title: getTitleRow(5, screenSize, astrologicalEdit),
        trailing: astrologicalEdit
            ? Container(
                width: 60,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    GestureDetector(
                        onTap: () {
                          setState(() {
                            astrologicalEditForm = !astrologicalEditForm;
                          });
                        },
                        child: AssetImageWidget(
                          image: 'assets/pencil.svg',
                          width: 25,
                          height: 25,
                        )
                    ),
                    SizedBox(width: 10),
                    Icon(Icons.arrow_forward_ios),
                  ],
                ),
              )
            : Icon(Icons.arrow_forward_ios),
        onExpansionChanged: (val) {
          setState(() {
            astrologicalEdit = val;
          });
        },
        children: [
          Container(
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: white,
                borderRadius: BorderRadius.only(
                    bottomRight: Radius.circular(10),
                    bottomLeft: Radius.circular(10)),
              ),
              child: ListView(
                shrinkWrap: true,
                primary: false,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                          //   crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              child: Text(
                                'Raasi: ',
                                style: miniBlackBoldFontWeightStyle,
                              ),
                            ),
                            astrologicalEditForm
                                ? Container(
                                    width: 150,
                                    alignment: Alignment.topLeft,
                                    child: Text(
                                      'Karkataka ',
                                      style: miniBlackFontWeightStyle,
                                    ))
                                : Container(
                                    width: 250,
                                    height: 50,
                                    child: DropdownButtonFormField<String>(
                                      decoration: InputDecoration(
                                          border: OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: Colors.grey))),
                                      onTap: () {
                                        FocusScope.of(context).unfocus();
                                      },
                                      value: martialStatus,
                                      hint: Text(''),
                                      style: smallGreyTextStyle,
                                      items: martialStatusDropDown,
                                      onChanged: (item) {
                                        setState(() {
                                          martialStatus = item;
                                          isMartialStatus = false;
                                        });
                                      },
                                      isExpanded: true,
                                      icon: Icon(Icons.keyboard_arrow_down),
                                    ),
                                  ),
                          ]),
                      Row(
                          //   crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              child: Text(
                                'Star: ',
                                style: miniBlackBoldFontWeightStyle,
                              ),
                            ),
                            astrologicalEditForm
                                ? Container(
                                    width: 150,
                                    alignment: Alignment.topLeft,
                                    child: Text(
                                      ' ',
                                      style: miniBlackFontWeightStyle,
                                    ))
                                : Container(
                                    width: 250,
                                    height: 50,
                                  ),
                          ]),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            child: Text(
                              'Kuja Dosha: ',
                              style: miniBlackBoldFontWeightStyle,
                            ),
                          ),
                          astrologicalEditForm
                              ? Container(
                                  width: 150,
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    'No ',
                                    style: miniBlackFontWeightStyle,
                                  ))
                              : Container(
                                  width: 250,
                                  height: 50,
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Expanded(
                                        child: _myRadioButton(
                                          title: "Yes",
                                          value: 0,
                                          onChanged: (newValue) => setState(
                                              () => kujaDushaValue = newValue),
                                        ),
                                      ),
                                      Expanded(
                                        child: _myRadioButton(
                                          title: "No",
                                          value: 1,
                                          onChanged: (newValue) => setState(
                                              () => kujaDushaValue = newValue),
                                        ),
                                      ),
                                    ],
                                  )),
                        ],
                      ),
                      astrologicalEditForm
                          ? SizedBox(
                              height: 5,
                            )
                          : SizedBox(
                              height: 35,
                            ),
                      astrologicalEditForm
                          ? SizedBox(
                              width: 0,
                            )
                          : GestureDetector(
                              onTap: () {
                                setState(() {
                                  favEditForm = false;
                                });
                              },
                              child: Container(
                                margin: EdgeInsets.only(
                                    left: screenSize.width * 0.3,
                                    right: screenSize.width * 0.3),
                                width: 100,
                                height: 50,
                                decoration: BoxDecoration(
                                  color: appColor,
                                  borderRadius: BorderRadius.circular(23.0),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Text(
                                      'Save',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: white,
                                        fontSize: 16,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            )
                    ],
                  ),
                ],
              ))
        ]);

    Widget screenUI() {
      return ListView(
        shrinkWrap: true,
        padding: EdgeInsets.symmetric(
          horizontal: 30,
          vertical: 15,
        ),
        physics: ScrollPhysics(),
        // padding: EdgeInsets.only(left: 10.0, right: 10.0),
        children: <Widget>[
          SizedBox(height: 10.0),
          basicDetails,
          SizedBox(height: 20.0),
          personalDetails,
          SizedBox(height: 20.0),
          familyDetails,
          SizedBox(height: 20.0),
          favourites,
          SizedBox(height: 20.0),
          education,
          SizedBox(height: 20.0),
          astrological,
          SizedBox(height: 20.0),
        ],
      );
    }

    return Scaffold(
      appBar: AppBarWidget(
        heading: 'Edit Profile',
        showIcon: true,
      ),
      body: screenUI(),
    );
  }

  Widget getTitleRow(index, screenSize, isEditMode) {
    return Container(
      padding: EdgeInsets.all(10),
      child: Row(
        children: <Widget>[
          AssetImageWidget(
            image: menus[index]['icon'],
            color: appColor,
          ),
          SizedBox(
            width: 20,
          ),
          Container(
              height: 40,
              child: VerticalDivider(
                  color: Colors.grey, thickness: 0.8, width: 5)),
          SizedBox(
            width: 10,
          ),
          Container(
            width:
                isEditMode ? screenSize.width * 0.45 : screenSize.width * 0.54,
            child: Text(
              menus[index]['title'],
              overflow: TextOverflow.ellipsis,
              style: headingBlackStyle,
            ),
          ),
        ],
      ),
    );
  }
}
