import 'package:flutter/material.dart';
import 'package:matchfinder/const/const.dart';
import 'package:matchfinder/core/mailbox/chat_list.dart';
import 'package:matchfinder/core/payment/paymentConfirmation.dart';
import 'package:matchfinder/core/payment/upgradePayment.dart';
import 'package:matchfinder/core/settings/help.dart';
import 'package:matchfinder/widgets/image_widget.dart';

import 'home.dart';
import 'matches.dart';

class BottomBar extends StatefulWidget {
  var index;
  BottomBar({this.index});

  @override
  _BottomBarState createState() => _BottomBarState();
}

class _BottomBarState extends State<BottomBar> {

  int _selectedIndex = 0;
  static List<Widget> _widgetOptions = <Widget>[
    Home(),
    Matches(),
    ChatList(),
    UpgradePayment(),
    Help()
  ];

  @override
  void initState() {
    if(widget.index != null){
      _selectedIndex = widget.index;
    }
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: _widgetOptions.elementAt(_selectedIndex),
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: white,
          showSelectedLabels: true,
          showUnselectedLabels: true,
          onTap: (index) {
            setState(() {
              _selectedIndex = index;
            });
          },
          selectedFontSize: 10,
          unselectedFontSize: 10,
          selectedItemColor: appColor,
          type: BottomNavigationBarType.fixed,
          currentIndex: _selectedIndex,
          items: [
            BottomNavigationBarItem(
              icon: Container(
                // margin: EdgeInsets.all(10),
                padding: EdgeInsets.all(15),
                decoration: BoxDecoration(
                    color: _selectedIndex == 0 ? appColor : white,
                    shape: BoxShape.circle
                ),
                child: Column(
                  children: [
                    AssetImageWidget(image: 'assets/home.svg', color: _selectedIndex == 0 ? white : black),
                    new Text(
                      'Home',
                      style: TextStyle(
                        color: _selectedIndex == 0 ? white : black,
                        fontWeight: FontWeight.w600,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              label: '',
            ),
            BottomNavigationBarItem(
              icon: Container(
                // margin: EdgeInsets.all(10),
                padding: EdgeInsets.all(15),
                decoration: BoxDecoration(
                    color: _selectedIndex == 1 ? appColor : white,
                    shape: BoxShape.circle
                ),
                child: Column(
                  children: [
                    AssetImageWidget(image: 'assets/users.svg', color: _selectedIndex == 1 ? white : black),
                    new Text(
                      'Matches',
                      style: TextStyle(
                        color: _selectedIndex == 1 ? white : black,
                        fontWeight: FontWeight.w600,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              label: '',
            ),
            BottomNavigationBarItem(
              icon: Container(
                // margin: EdgeInsets.all(10),
                padding: EdgeInsets.all(15),
                decoration: BoxDecoration(
                    color: _selectedIndex == 2 ? appColor : white,
                    shape: BoxShape.circle
                ),
                child: Column(
                  children: [
                    AssetImageWidget(image: 'assets/email.svg', color: _selectedIndex == 2 ? white : black),
                    new Text(
                      'Mailbox',
                      style: TextStyle(
                        color: _selectedIndex == 2 ? white : black,
                        fontWeight: FontWeight.w600,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              label: '',
            ),
            BottomNavigationBarItem(
              icon: Container(
                // margin: EdgeInsets.all(10),
                padding: EdgeInsets.all(15),
                decoration: BoxDecoration(
                    color: _selectedIndex == 3 ? appColor : white,
                    shape: BoxShape.circle
                ),
                child: Column(
                  children: [
                    AssetImageWidget(image: 'assets/credit_card_verified.svg',
                        color: _selectedIndex == 3 ? white : black),
                    new Text(
                      'Payments',
                      style: TextStyle(
                        color: _selectedIndex == 3 ? white : black,
                        fontWeight: FontWeight.w600,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              label: '',
            ),
            BottomNavigationBarItem(
              icon: Container(
                // margin: EdgeInsets.all(10),
                padding: EdgeInsets.all(15),
                decoration: BoxDecoration(
                    color: _selectedIndex == 4 ? appColor : white,
                    shape: BoxShape.circle
                ),
                child: Column(
                  children: [
                    AssetImageWidget(image: 'assets/information.svg', 
                        color: _selectedIndex == 4 ? white : black),
                    new Text(
                      'Help',
                      style: TextStyle(
                        color: _selectedIndex == 4 ? white : black,
                        fontWeight: FontWeight.w600,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              label: '',
            ),
          ]),
    );
  }
}
