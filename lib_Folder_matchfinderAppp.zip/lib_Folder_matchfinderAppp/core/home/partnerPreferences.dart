import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:matchfinder/const/const.dart';
import 'package:matchfinder/const/general_methods.dart';
import 'package:matchfinder/utils/function.dart';
import 'package:matchfinder/utils/style.dart';
import 'package:matchfinder/utils/appBar.dart';
import 'package:matchfinder/widgets/customDrop.dart';
import 'package:matchfinder/widgets/drawer.dart';
import 'package:matchfinder/widgets/select_multiple.dart';
import 'package:matchfinder/widgets/text_field.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../utils/url.dart';

class PartnerPreferences extends StatefulWidget {
  @override
  _PartnerPreferencesState createState() => _PartnerPreferencesState();
}

class _PartnerPreferencesState extends State<PartnerPreferences> {
  final _formKey = GlobalKey<FormState>();
  final _key = GlobalKey<ScaffoldState>();

  TextEditingController describePartner = TextEditingController();
  TextEditingController ageText = TextEditingController();
  TextEditingController ageFrom = TextEditingController();
  TextEditingController ageTo = TextEditingController();
  TextEditingController heightText = TextEditingController();
  TextEditingController salaryMin = TextEditingController();
  TextEditingController salaryText = TextEditingController();
  TextEditingController preferredCaste = TextEditingController();

  String groupValue;
  String selectedDrawer = '';

  bool _autoValidate = false;
  bool isLoading = true;

  bool isMotherTongue = false;
  bool isMartialStatus = false;
  bool isHeight = false;
  bool isDisplay = false;
  bool isCast = false;
  bool isReligion = true;
  bool isEducation = false;
  bool isVisa = false;
  bool isProfession = false;
  bool isSmoking = false;
  bool isComplexion = false;
  bool isSalary = false;
  bool isJobType = false;
  bool isRaasi = false;
  bool isStar = false;
  bool isBodyType = false;
  bool isEating = false;
  bool isDrinking = false;
  bool isCountry = false;
  bool isCity = false;
  bool isPhysicalStatus = false;
  bool isStateLivingIn = false;

  String profileCastes;
  String profileCastesIds;
  String motherTongue;
  String maritalStatus;
  String education;
  String profession;
  String heightTo;
  String heightFrom;
  String complexion;
  String complexionIds;
  String salaryCurrency;
  String salaryCurrencyIds;
  String jobType;
  String jobTypeIds;
  String raasi;
  String raasiIds;
  String star;
  String starIds;
  String eating;
  String eatingIds;
  String drinking;
  String drinkingIds;
  String country;
  String countryIds;
  String city;
  String cityIds;
  String bodyType;
  String bodyTypeIds;
  String stateLivingIn;
  String visa;
  String visaIds;
  String smoking;
  String smokingIds;
  String physicalStatus;
  String physicalStatusIds;
  String cast;
  String castIds;
  String religion;
  List<String> castString = <String>[];

  // List<dynamic> caste_list = [];
  List<dynamic> defaultCasteValue = [];

  List<DropdownMenuItem<String>> heightDropDown = <DropdownMenuItem<String>>[];
  List<DropdownMenuItem<String>> currencyDropDown =
      <DropdownMenuItem<String>>[];
  List<DropdownMenuItem<String>> religionDropDown =
      <DropdownMenuItem<String>>[];

  List selectedIDsMaritalStatus = List<String>();
  List selectedTextMaritalStatus = List<String>();
  bool selectAllMaritalStatus = false;

  List selectedIDsMotherTongue = List<String>();
  List selectedTextMotherTongue = List<String>();
  bool selectAllMotherTongue = false;

  List selectedIDsReligion = List<String>();
  List selectedTextReligion = List<String>();
  bool selectAllReligion = false;

  List selectedIDsEducation = List<String>();
  List selectedTextEducation = List<String>();
  bool selectAllEducation = false;

  List selectedIDsProfession = List<String>();
  List selectedTextProfession = List<String>();
  bool selectAllProfession = false;

  List selectedIDsStateLiving = List<String>();
  List selectedTextStateLiving = List<String>();
  bool selectAllStateLiving = false;

  List selectedIDsJob = List<String>();
  List selectedTextJob = List<String>();
  bool selectAllJob = false;

  List selectedIDsCast = List<String>();
  List selectedTextCast = List<String>();
  bool selectAllCast = false;

  List selectedIDsRaasi = List<String>();
  List selectedTextRaasi = List<String>();
  bool selectAllRaasi = false;

  List selectedIDsDrinking = List<String>();
  List selectedTextDrinking = List<String>();
  bool selectAllDrinking = false;

  List selectedIDsEating = List<String>();
  List selectedTextEating = List<String>();
  bool selectAllEating = false;

  List selectedIDsSmoking = List<String>();
  List selectedTextSmoking = List<String>();
  bool selectAllSmoking = false;

  List selectedIDsPhysicalStatus = List<String>();
  List selectedTextPhysicalStatus = List<String>();
  bool selectAllPhysicalStatus = false;

  List selectedIDsCity = List<String>();
  List selectedTextCity = List<String>();
  bool selectAllCity = false;

  List selectedIDsCountry = List<String>();
  List selectedTextCountry = List<String>();
  bool selectAllCountry = false;

  List selectedIDsBodyType = List<String>();
  List selectedTextBodyType = List<String>();
  bool selectAllBodyType = false;

  List selectedIDsComplexion = List<String>();
  List selectedTextComplexion = List<String>();
  bool selectAllComplexion = false;

  List selectedIDsVisa = List<String>();
  List selectedTextVisa = List<String>();
  bool selectAllVisa = false;

  List selectedIDsStar = List<String>();
  List selectedTextStar = List<String>();
  bool selectAllStar = false;

  @override
  void initState() {
    super.initState();
    getData();
    getPartnerPreferencesData();
  }

  getPartnerPreferencesData() async {
    try {
      var value = getSession();
      final prefs = await SharedPreferences.getInstance();
      print(value);
      if (value != null) {
        Response response = await getPartnerPreferences();
        if (await response.data != null) {
          // print(response.data);
          var data = response.data['proPartPrefMob'];
          describePartner.text = data['comments']??'';
          ageFrom.text = data['minAge'] != null ? data['minAge'].toString() : 'min';
          ageTo.text = data['maxAge'] != null ? data['maxAge'].toString() : 'max';
          ageText.text = ageFrom.text + ' Yrs - ' + ageTo.text + ' Yrs';
          heightFrom = data['minHeight'] != null ? data['minHeight'].toString() : '';
          heightTo = data['maxHeight'] != null ? data['maxHeight'].toString() : '';
          heightText.text = heightFrom + ' - ' + heightTo;
          isHeight = heightText.text.trim().isEmpty;
          maritalStatus = data['maritalStatus']??'';
          isMartialStatus = maritalStatus.isEmpty;
          selectedTextMaritalStatus = isMartialStatus ? [] : maritalStatus.split(',');
          selectedIDsMaritalStatus = selectIds(selectedIDsMaritalStatus, selectedTextMaritalStatus, maritalStatusList);
          motherTongue = data['motherTongue']??'';
          isMotherTongue = motherTongue.isEmpty;
          selectedTextMotherTongue = isMotherTongue ? [] : motherTongue.split(',');
          selectedIDsMotherTongue = selectIds(selectedIDsMotherTongue, selectedTextMotherTongue, motherTongueList);
          religion = data['religion']??'';
          isReligion = religion.isEmpty;
          selectedTextReligion = isReligion ? [] : religion.split(',');
          selectedIDsReligion = selectIds(selectedIDsReligion, selectedTextReligion, religions);
          cast = data['caste']??'';
          isCast = cast.isEmpty;
          // selectedTextCast = cast.split(',');
          // selectedIDsCast = selectIds(selectedIDsCast, selectedTextCast, casteList);
          raasi = data['raasi']??'';
          isRaasi = raasi.isEmpty;
          star = data['star']??'';
          isStar = star.isEmpty;
          eating = data['eating']??'';
          isEating = eating.isEmpty;
          drinking = data['drinking']??'';
          isDrinking = drinking.isEmpty;
          smoking = data['smoking']??'';
          isSmoking = smoking.isEmpty;
          physicalStatus = data['physicalStatus']??'';
          isPhysicalStatus = physicalStatus.isEmpty;
          bodyType = data['bodyType']??'';
          isBodyType = bodyType.isEmpty;
          complexion = data['complexion']??'';
          isComplexion = complexion.isEmpty;
          // selectedTextComplexion = complexion.split(',');
          // selectedIDsComplexion = selectIds(selectedIDsComplexion, selectedTextComplexion, complexionTypesList);
          country = data['countryLivingIn']??'';
          isCountry = country.isEmpty;
          stateLivingIn = data['stateLivingIn']??'';
          isStateLivingIn = stateLivingIn.isEmpty;
          selectedTextStateLiving = isStateLivingIn ? [] : stateLivingIn.split(',');
          selectedIDsStateLiving = selectIds(selectedIDsStateLiving, selectedTextStateLiving, stateTypesList);
          visa = data['visaCitizen']??'';
          isVisa = visa.isEmpty;
          selectedTextVisa = isVisa ? [] : visa.split(',');
          // selectedIDsVisa = selectIds(selectedIDsVisa, selectedTextVisa, visaTypesList);
          education = data['education']??'';
          isEducation = education.isEmpty;
          selectedTextEducation = isEducation ? [] : education.split(',');
          selectedIDsEducation = selectIds(selectedIDsEducation, selectedTextEducation, educationTypesList);
          profession = data['occupation']??'';
          isProfession = profession.isEmpty;
          selectedTextProfession = isProfession ? [] : profession.split(',');
          selectedIDsProfession = selectIds(selectedIDsProfession, selectedTextProfession, professionTypesList);
          jobType = data['employedIn']??'';
          isJobType = jobType.isEmpty;
          city = data['city']??'';
          isCity = city.isEmpty;
          salaryCurrency = data['incomeCurrency']??'';
          salaryMin.text = data['minAnnualIncome'] != null ? data['minAnnualIncome'].toString() : '';
          salaryText.text = '${salaryMin.text} $salaryCurrency';
          isSalary = salaryText.text.trim().isEmpty;
          // data['employedIn']??'';
          isLoading = false;
          setState(() {});
        }
      } else {
        print('No cache value');
        Navigator.pop(context);
      }
    } catch (e) {
      print(e);
    }
  }

  selectIds(List assignIds, List selectedList, List originalList){
    for(var i=0;i<selectedList.length;i++){
      var val = originalList.firstWhere((element) => selectedList[i] == element[1], orElse: () => null);
      if(val != null){
        assignIds.add(val[0]);
      }
    }
    return assignIds;
  }

  getHeightDropDown() async {
    if (heightList.isNotEmpty) {
      List<dynamic> value = heightList.reversed.toList();
      List<DropdownMenuItem<String>> items = new List();
      for (int i = 0; i < value.length; i++) {
        if(value[i][0] != 0){
          setState(() {
            items.insert(
              0,
              DropdownMenuItem(
                child: Text(
                  value[i][1],
                ),
                value: value[i][0].toString(),
              ),
            );
          });
        }
      }
      return items;
    } else {
      return null;
    }
  }

  // getCountryDropDown() async {
  //   if (countries.isNotEmpty) {
  //     List<dynamic> value = countries.reversed.toList();
  //     List<DropdownMenuItem<String>> items = new List();
  //     for (int i = 0; i < value.length; i++) {
  //       if(value[i][0] != "0") {
  //         setState(() {
  //           items.insert(
  //             0,
  //             DropdownMenuItem(
  //               child: Text(
  //                 value[i][1],
  //               ),
  //               value: value[i][0],
  //             ),
  //           );
  //         });
  //       }
  //     }
  //     return items;
  //   } else {
  //     return null;
  //   }
  // }

  getCurrencyDropDown() async {
    if (countries.isNotEmpty) {
      List<dynamic> value = countries.reversed.toList();
      List<DropdownMenuItem<String>> items = new List();
      for (int i = 0; i < value.length; i++) {
        if(value[i][0] != "0") {
          setState(() {
            items.insert(
              0,
              DropdownMenuItem(
                child: Text(
                  value[i][1],
                ),
                value: value[i][0],
              ),
            );
          });
        }
      }
      return items;
    } else {
      return null;
    }
  }

  getReligionDropDown() async {
    //  List<dynamic> res = await getReligion();
    if (religions.isNotEmpty) {
      List<dynamic> value = religions.reversed.toList();
      List<DropdownMenuItem<String>> items = new List();
      for (int i = 0; i < value.length; i++) {
        if(value[i][0] != "0") {
          setState(() {
            items.insert(
              0,
              DropdownMenuItem(
                child: Text(
                  value[i][1],
                ),
                value: value[i][0],
              ),
            );
          });
        }
      }
      return items;
    } else {
      return null;
    }
  }

  getData() async {
    religionDropDown = await getReligionDropDown();
    heightDropDown = await getHeightDropDown();
    currencyDropDown = await getCurrencyDropDown();
  }

  @override
  void dispose() {
    heightText.dispose();
    ageFrom.dispose();
    ageTo.dispose();
    ageText.dispose();
    salaryMin.dispose();
    salaryText.dispose();
    preferredCaste.dispose();
    if (religionDropDown.isNotEmpty) religionDropDown.clear();
    if (heightDropDown.isNotEmpty) heightDropDown.clear();
    if (currencyDropDown.isNotEmpty) currencyDropDown.clear();
    super.dispose();
  }

  getAgeDrawer() {
    return ListView(
      children: [
        Text(
          'From',
          textAlign: TextAlign.start,
          style: miniGreyFontWeightStyle,
        ),
        SizedBox(
          height: 5,
        ),
        TextFieldCustom(
          controller: ageFrom,
          style: miniGreyTextStyle,
          // labelText: 'From',
          inputType: TextInputType.number,
          maxLength: 2,
          inputFormatter: [
            FilteringTextInputFormatter.allow(RegExp("[0-9]")),
            FilteringTextInputFormatter.deny(RegExp("[abFeG]")),
          ],
          validator: (value) {
            if (value.isEmpty) {
              return '*Required';
            }
            return null;
          },
        ),
        SizedBox(
          height: 10,
        ),
        Text(
          'To',
          textAlign: TextAlign.start,
          style: miniGreyFontWeightStyle,
        ),
        SizedBox(
          height: 5,
        ),
        TextFieldCustom(
          controller: ageTo,
          style: miniGreyTextStyle,
          // labelText: 'To',
          maxLength: 2,
          inputFormatter: [
            FilteringTextInputFormatter.allow(RegExp("[0-9]")),
            FilteringTextInputFormatter.deny(RegExp("[abFeG]")),
          ],
          inputType: TextInputType.number,
          validator: (value) {
            if (value.isEmpty) {
              return '*Required';
            }
            return null;
          },
        ),
      ],
    );
  }

  getHeightDrawer() {
    return ListView(
      children: [
        Text(
          'From',
          textAlign: TextAlign.start,
          style: miniGreyFontWeightStyle,
        ),
        SizedBox(
          height: 5,
        ),
        CustomDropDown(
          hint: 'From',
          value: heightFrom,
          items: heightDropDown,
          validator: (value) {
            if (value == null && value != "0") {
              return '*Required';
            }
            return null;
          },
          onChanged: (value) {
            if (value != "0") {
              setState(() {
                isHeight = false;
                heightFrom = value;
              });
            }
            print('changed to $value');
          },
        ),
        SizedBox(
          height: 10,
        ),
        Text(
          'To',
          textAlign: TextAlign.start,
          style: miniGreyFontWeightStyle,
        ),
        SizedBox(
          height: 5,
        ),
        CustomDropDown(
          hint: 'To',
          value: heightTo,
          items: heightDropDown,
          validator: (value) {
            if (value == null && value != "0") {
              return '*Required';
            }
            return null;
          },
          onChanged: (value) {
            if (value != "0") {
              setState(() {
                isHeight = false;
                heightTo = value;
              });
            }
            print('changed to $value');
          },
        ),
      ],
    );
  }

  getSalaryDrawer() {
    return ListView(
      children: [
        Text(
          'Minimum Salary',
          textAlign: TextAlign.start,
          style: miniGreyFontWeightStyle,
        ),
        SizedBox(
          height: 5,
        ),
        TextFieldCustom(
          controller: salaryMin,
          style: miniGreyTextStyle,
          labelText: '',
          inputType: TextInputType.number,
          maxLength: 6,
          inputFormatter: [
            FilteringTextInputFormatter.allow(RegExp("[0-9]")),
            FilteringTextInputFormatter.deny(RegExp("[abFeG]")),
          ],
          validator: (value) {
            if (value.isEmpty) {
              return '*Required';
            }
            return null;
          },
        ),
        SizedBox(
          height: 10,
        ),
        Text(
          'Currency',
          textAlign: TextAlign.start,
          style: miniGreyFontWeightStyle,
        ),
        SizedBox(
          height: 5,
        ),
        CustomDropDown(
          hint: '',
          value: salaryCurrency,
          items: currencyDropDown,
          validator: (value) {
            if (value == null && value != "0") {
              return '*Required';
            }
            return null;
          },
          onChanged: (value) {
            if (value != "0") {
              setState(() {
                isSalary = false;
                salaryCurrency = value;
              });
            }
            print('changed to $value');
          },
        ),
      ],
    );
  }

  getDrawer(
      List<dynamic> list, List selectedIds, List selectedText, bool selectAll) {
    return ListView(
      shrinkWrap: true,
      padding: const EdgeInsets.only(left: 10, right: 10),
      children: [
        Row(
          children: <Widget>[
            Checkbox(
              materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
              value: selectAll,
              onChanged: (val) {
                setState(() {
                  onAllSelected(selectedIds, selectedText, selectAll, val);
                });
              },
            ),
            SizedBox(
              width: 15,
            ),
            Text(
              "Select All",
              style: TextStyle(fontSize: 14),
            ),
          ],
        ),
        Divider(
          color: greyColor,
        ),
        ListView.separated(
            shrinkWrap: true,
            itemCount: list.length,
            primary: false,
            separatorBuilder: (context, index) {
              return Divider(
                color: greyColor,
              );
            },
            itemBuilder: (context, index) {
              return CheckboxListTile(
                controlAffinity: ListTileControlAffinity.leading,
                contentPadding: EdgeInsets.all(0),
                selected: false,
                value: selectedIds.contains(list[index][0]),
                onChanged: (bool selected) {
                  onItemSelected(selectedIds, selectedText, selected,
                      list[index][0], list[index][1]);
                },
                title: Text(list[index][1]),
              );
            }),
        Divider(
          color: greyColor,
        ),
      ],
    );
  }

  getDrawerS(
      List<dynamic> list, List selectedIds, List selectedText, bool selectAll) {
    return ListView(
      shrinkWrap: true,
      padding: const EdgeInsets.only(left: 10, right: 10),
      children: [
        Row(
          children: <Widget>[
            Checkbox(
              materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
              value: selectAll,
              onChanged: (val) {
                setState(() {
                  onAllSelectedS(selectedIds, selectedText, selectAll, val);
                });
              },
            ),
            SizedBox(
              width: 15,
            ),
            Text(
              "Select All",
              style: TextStyle(fontSize: 14),
            ),
          ],
        ),
        Divider(
          color: greyColor,
        ),
        ListView.separated(
            shrinkWrap: true,
            itemCount: list.length,
            primary: false,
            separatorBuilder: (context, index) {
              return Divider(
                color: greyColor,
              );
            },
            itemBuilder: (context, index) {
              return CheckboxListTile(
                controlAffinity: ListTileControlAffinity.leading,
                contentPadding: EdgeInsets.all(0),
                selected: false,
                value: selectedIds.contains(list[index][0]),
                onChanged: (bool selected) {
                  onItemSelected(selectedIds, selectedText, selected,
                      list[index][0], list[index][1]);
                },
                title: Text(list[index][1]),
              );
            }),
        Divider(
          color: greyColor,
        ),
      ],
    );
  }

  getDrawerE(
      List<dynamic> list, List selectedIds, List selectedText, bool selectAll) {
    return ListView(
      shrinkWrap: true,
      padding: const EdgeInsets.only(left: 10, right: 10),
      children: [
        Row(
          children: <Widget>[
            Checkbox(
              materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
              value: selectAll,
              onChanged: (val) {
                setState(() {
                  onAllSelectedE(selectedIds, selectedText, selectAll, val);
                });
              },
            ),
            SizedBox(
              width: 15,
            ),
            Text(
              "Select All",
              style: TextStyle(fontSize: 14),
            ),
          ],
        ),
        Divider(
          color: greyColor,
        ),
        ListView.separated(
            shrinkWrap: true,
            itemCount: list.length,
            primary: false,
            separatorBuilder: (context, index) {
              return Divider(
                color: greyColor,
              );
            },
            itemBuilder: (context, index) {
              return CheckboxListTile(
                controlAffinity: ListTileControlAffinity.leading,
                contentPadding: EdgeInsets.all(0),
                selected: false,
                value: selectedIds.contains(list[index][0]),
                onChanged: (bool selected) {
                  onItemSelected(selectedIds, selectedText, selected,
                      list[index][0], list[index][1]);
                },
                title: Text(list[index][1]),
              );
            }),
        Divider(
          color: greyColor,
        ),
      ],
    );
  }

  getDrawerP(
      List<dynamic> list, List selectedIds, List selectedText, bool selectAll) {
    return ListView(
      shrinkWrap: true,
      padding: const EdgeInsets.only(left: 10, right: 10),
      children: [
        Row(
          children: <Widget>[
            Checkbox(
              materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
              value: selectAll,
              onChanged: (val) {
                setState(() {
                  onAllSelectedP(selectedIds, selectedText, selectAll, val);
                });
              },
            ),
            SizedBox(
              width: 15,
            ),
            Text(
              "Select All",
              style: TextStyle(fontSize: 14),
            ),
          ],
        ),
        Divider(
          color: greyColor,
        ),
        ListView.separated(
            shrinkWrap: true,
            itemCount: list.length,
            primary: false,
            separatorBuilder: (context, index) {
              return Divider(
                color: greyColor,
              );
            },
            itemBuilder: (context, index) {
              return CheckboxListTile(
                controlAffinity: ListTileControlAffinity.leading,
                contentPadding: EdgeInsets.all(0),
                selected: false,
                value: selectedIds.contains(list[index][0]),
                onChanged: (bool selected) {
                  onItemSelected(selectedIds, selectedText, selected,
                      list[index][0], list[index][1]);
                },
                title: Text(list[index][1]),
              );
            }),
        Divider(
          color: greyColor,
        ),
      ],
    );
  }

  getDrawerM(
      List<dynamic> list, List selectedIds, List selectedText, bool selectAll) {
    return ListView(
      shrinkWrap: true,
      padding: const EdgeInsets.only(left: 10, right: 10),
      children: [
        Row(
          children: <Widget>[
            Checkbox(
              materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
              value: selectAll,
              onChanged: (val) {
                setState(() {
                  onAllSelectedMarital(
                      selectedIds, selectedText, selectAll, val);
                });
              },
            ),
            SizedBox(
              width: 15,
            ),
            Text(
              "Select All",
              style: TextStyle(fontSize: 14),
            ),
          ],
        ),
        Divider(
          color: greyColor,
        ),
        ListView.separated(
            shrinkWrap: true,
            itemCount: list.length,
            primary: false,
            separatorBuilder: (context, index) {
              return Divider(
                color: greyColor,
              );
            },
            itemBuilder: (context, index) {
              return CheckboxListTile(
                controlAffinity: ListTileControlAffinity.leading,
                contentPadding: EdgeInsets.all(0),
                selected: false,
                value: selectedIds.contains(list[index][0]),
                onChanged: (bool selected) {
                  onItemSelected(selectedIds, selectedText, selected,
                      list[index][0], list[index][1]);
                },
                title: Text(list[index][1]),
              );
            }),
        Divider(
          color: greyColor,
        ),
      ],
    );
  }

  getDrawerR(
      List<dynamic> list, List selectedIds, List selectedText, bool selectAll) {
    return ListView(
      shrinkWrap: true,
      padding: const EdgeInsets.only(left: 10, right: 10),
      children: [
        Row(
          children: <Widget>[
            Checkbox(
              materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
              value: selectAll,
              onChanged: (val) {
                setState(() {
                  onAllSelectedR(selectedIds, selectedText, selectAll, val);
                });
              },
            ),
            SizedBox(
              width: 15,
            ),
            Text(
              "Select All",
              style: TextStyle(fontSize: 14),
            ),
          ],
        ),
        Divider(
          color: greyColor,
        ),
        ListView.separated(
            shrinkWrap: true,
            itemCount: list.length,
            primary: false,
            separatorBuilder: (context, index) {
              return Divider(
                color: greyColor,
              );
            },
            itemBuilder: (context, index) {
              return CheckboxListTile(
                controlAffinity: ListTileControlAffinity.leading,
                contentPadding: EdgeInsets.all(0),
                selected: false,
                value: selectedIds.contains(list[index][0]),
                onChanged: (bool selected) {
                  onItemSelected(selectedIds, selectedText, selected,
                      list[index][0], list[index][1]);
                },
                title: Text(list[index][1]),
              );
            }),
        Divider(
          color: greyColor,
        ),
      ],
    );
  }

  void onAllSelectedP(
      List selectedIds, List selectedText, bool selectAll, bool newValue) {
    setState(() {
      selectAll = newValue;
      if (selectAll) {
        professionTypesList.forEach((element) {
          selectedIds.add(element[0]);
          selectedText.add(element[1]);
        });
      } else {
        selectedIds.clear();
        selectedText.clear();
      }
    });
  }

  void onAllSelectedS(
      List selectedIds, List selectedText, bool selectAll, bool newValue) {
    setState(() {
      selectAll = newValue;
      if (selectAll) {
        stateTypesList.forEach((element) {
          selectedIds.add(element[0]);
          selectedText.add(element[1]);
        });
      } else {
        selectedIds.clear();
        selectedText.clear();
      }
    });
  }

  void onAllSelectedE(
      List selectedIds, List selectedText, bool selectAll, bool newValue) {
    setState(() {
      selectAll = newValue;
      if (selectAll) {
        educationTypesList.forEach((element) {
          selectedIds.add(element[0]);
          selectedText.add(element[1]);
        });
      } else {
        selectedIds.clear();
        selectedText.clear();
      }
    });
  }

  void onAllSelectedMarital(
      List selectedIds, List selectedText, bool selectAll, bool newValue) {
    setState(() {
      selectAll = newValue;
      if (selectAll) {
        maritalStatusList.forEach((element) {
          selectedIds.add(element[0]);
          selectedText.add(element[1]);
        });
      } else {
        selectedIds.clear();
        selectedText.clear();
      }
    });
  }

  void onAllSelectedR(
      List selectedIds, List selectedText, bool selectAll, bool newValue) {
    setState(() {
      selectAll = newValue;
      if (selectAll) {
        religions.forEach((element) {
          selectedIds.add(element[0]);
          selectedText.add(element[1]);
        });
      } else {
        selectedIds.clear();
        selectedText.clear();
      }
    });
  }

  void onAllSelected(
      List selectedIds, List selectedText, bool selectAll, bool newValue) {
    setState(() {
      selectAll = newValue;
      if (selectAll) {
        motherTongueList.forEach((element) {
          selectedIds.add(element[0]);
          selectedText.add(element[1]);
        });
      } else {
        selectedIds.clear();
        selectedText.clear();
      }
    });
  }

  void onItemSelected(
      List selectedIds, List selectedText, bool selected, id, text) {
    if (selected) {
      selectedIds.add(id);
      selectedText.add(text);
    } else {
      selectedIds.remove(id);
      selectedText.remove(text);
    }
    setState(() {});
  }

  getDrawerMethod() {
    if (selectedDrawer == 'Age') {
      return getAgeDrawer();
    } else if (selectedDrawer == 'Height') {
      return getHeightDrawer();
    } else if (selectedDrawer == 'Salary') {
      return getSalaryDrawer();
    } else if (selectedDrawer == 'Marital Status') {
      return getDrawerM(maritalStatusList, selectedIDsMaritalStatus,
          selectedTextMaritalStatus, selectAllMaritalStatus);
    } else if (selectedDrawer == 'Mother Tongue') {
      return getDrawer(motherTongueList.sublist(1, motherTongueList.length), selectedIDsMotherTongue,
          selectedTextMotherTongue, selectAllMotherTongue);
    } else if (selectedDrawer == 'Religion') {
      return getDrawerR(religions.sublist(1, religions.length), selectedIDsReligion, selectedTextReligion,
          selectAllReligion);
    } else if (selectedDrawer == 'Education') {
      return getDrawerE(educationTypesList, selectedIDsEducation,
          selectedTextEducation, selectAllEducation);
    } else if (selectedDrawer == 'Profession') {
      return getDrawerP(professionTypesList, selectedIDsProfession,
          selectedTextProfession, selectAllProfession);
    } else if (selectedDrawer == 'State Living In') {
      return getDrawerS(stateTypesList, selectedIDsStateLiving,
          selectedTextStateLiving, selectAllStateLiving);
    }
    // else if (selectedDrawer == 'Visa') {
    //   return getDrawer(visaTypesList, selectedIDsVisa,
    //       selectedTextVisa, selectAllVisa);
    // } else if (selectedDrawer == 'Complexion') {
    //   return getDrawer(complexionTypesList, selectedIDsComplexion,
    //       selectedTextComplexion, selectAllComplexion);
    // } else if (selectedDrawer == 'Job Type') {
    //   return getDrawer(jobTypesList, selectedIDsJob,
    //       selectedTextJob, selectAllJob);
    // } else if (selectedDrawer == 'Caste') {
    //   return getDrawer(casteList, selectedIDsCast,
    //       selectedTextCast, selectAllCast);
    // } else if (selectedDrawer == 'Raasi') {
    //   return getDrawer(raasiTypesList, selectedIDsRaasi,
    //       selectedTextRaasi, selectAllRaasi);
    // } else if (selectedDrawer == 'Star') {
    //   return getDrawer(starTypesList, selectedIDsStar,
    //       selectedTextStar, selectAllStar);
    // } else if (selectedDrawer == 'Physical Status') {
    //   return getDrawer(physicalStatusList, selectedIDsPhysicalStatus,
    //       selectedTextPhysicalStatus, selectAllPhysicalStatus);
    // } else if (selectedDrawer == 'Body Type') {
    //   return getDrawer(bodyTypesList, selectedIDsBodyType,
    //       selectedTextBodyType, selectAllBodyType);
    // } else if (selectedDrawer == 'Eating') {
    //   return getDrawer(eatingTypesList, selectedIDsEating,
    //       selectedTextEating, selectAllEating);
    // } else if (selectedDrawer == 'Drinking') {
    //   return getDrawer(drinkingTypesList, selectedIDsDrinking,
    //       selectedTextDrinking, selectAllDrinking);
    // } else if (selectedDrawer == 'Smoking') {
    //   return getDrawer(smokingTypesList, selectedIDsSmoking,
    //       selectedTextSmoking, selectAllSmoking);
    // } else if (selectedDrawer == 'Country') {
    //   return getDrawer(countries, selectedIDsCountry,
    //       selectedTextCountry, selectAllCountry);
    // } else if (selectedDrawer == 'City') {
    //   return getDrawer(citiesList, selectedIDsCity,
    //       selectedTextCity, selectAllCity);
    // }
  }

  @override
  Widget build(BuildContext context) {
    var screenSize = MediaQuery.of(context).size;

    return Scaffold(
      key: _key,
      appBar: AppBarWidget(
        heading: 'Partner Preferences',
        showIcon: true,
      ),
      endDrawer: AppDrawer(
        context: context,
        heading: selectedDrawer,
        list: getDrawerMethod(),
        onSave: () {
          Navigator.pop(context);
        },
      ),
      onEndDrawerChanged: (isOpen) {
        print('end drawer callback isOpen = $isOpen');
        if (!isOpen) {
          if (selectedDrawer == 'Age' &&
              ageFrom.text.isNotEmpty &&
              ageTo.text.isNotEmpty) {
            ageText.text = ageFrom.text + ' Yrs - ' + ageTo.text + ' Yrs';
          } else if (selectedDrawer == 'Height') {
            heightText.text = heightFrom + ' - ' + heightTo;
            isHeight = heightFrom.isEmpty || heightTo.isEmpty;
          } else if (selectedDrawer == 'Salary') {
            salaryText.text = '${salaryMin.text} $salaryCurrency';
          } else if (selectedDrawer == 'Marital Status') {
            maritalStatus = selectedTextMaritalStatus.join(',');
            isMartialStatus = maritalStatus.isEmpty;
          } else if (selectedDrawer == 'Mother Tongue') {
            motherTongue = selectedTextMotherTongue.join(',');
            isMotherTongue = motherTongue.isEmpty;
          } else if (selectedDrawer == 'Religion') {
            religion = selectedTextReligion.join(',');
            isReligion = religion.isEmpty;
          } else if (selectedDrawer == 'Education') {
            education = selectedTextEducation.join(',');
            isEducation = education.isEmpty;
          } else if (selectedDrawer == 'Profession') {
            profession = selectedTextProfession.join(',');
            isProfession = profession.isEmpty;
          } else if (selectedDrawer == 'State Living In') {
            stateLivingIn = selectedTextStateLiving.join(',');
            isStateLivingIn = stateLivingIn.isEmpty;
          }
          // else if (selectedDrawer == 'Visa') {
          //   visa = selectedTextVisa.join(',');
          // } else if (selectedDrawer == 'Complexion') {
          //   complexion = selectedTextComplexion.join(',');
          // } else if (selectedDrawer == 'Job Type') {
          //   jobType = selectedTextJob.join(',');
          // } else if (selectedDrawer == 'Caste') {
          //   cast = selectedTextCast.join(',');
          // } else if (selectedDrawer == 'Raasi') {
          //   raasi = selectedTextRaasi.join(',');
          // } else if (selectedDrawer == 'Star') {
          //   star = selectedTextStar.join(',');
          // } else if (selectedDrawer == 'Physical Status') {
          //   physicalStatus = selectedTextPhysicalStatus.join(',');
          // } else if (selectedDrawer == 'Body Type') {
          //   bodyType = selectedTextBodyType.join(',');
          // } else if (selectedDrawer == 'Eating') {
          //   eating = selectedTextEating.join(',');
          // } else if (selectedDrawer == 'Drinking') {
          //   drinking = selectedTextDrinking.join(',');
          // } else if (selectedDrawer == 'Smoking') {
          //   smoking = selectedTextSmoking.join(',');
          // } else if (selectedDrawer == 'Country') {
          //   country = selectedTextCountry.join(',');
          // } else if (selectedDrawer == 'City') {
          //   city = selectedTextCity.join(',');
          // }
          setState(() {});
        }
      },
      body: Center(
        child: isLoading
            ? CircularProgressIndicator()
            : Container(
                color: backGroundColor,
                padding: EdgeInsets.symmetric(
                  horizontal: 30,
                  vertical: 15,
                ),
                child: Form(
                  key: _formKey,
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  child: ListView(
                    children: [
                      SizedBox(
                        height: 10,
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // SizedBox(
                          //   width: 20,
                          // ),
                          // Expanded(
                          //   child: Text(
                          //     '"We will show matches based on your inputs in the below fields"',
                          //     style: TextStyle(
                          //       fontFamily: 'Arial',
                          //       fontSize: 14,
                          //       color: const Color(0xff707070),
                          //       letterSpacing: 0.098,
                          //     ),
                          //     textAlign: TextAlign.left,
                          //   ),
                          // ),
                          Text(
                            'Where are partner preferences used?',
                            style: TextStyle(
                              fontFamily: 'Arial',
                              fontSize: 16,
                              color: const Color(0xff707070),
                              fontWeight: FontWeight.bold,
                              letterSpacing: 0.098,
                            ),
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Text(
                            '1. Show Preferences to your Profile visitors',
                            style: TextStyle(
                              fontFamily: 'Arial',
                              fontSize: 14,
                              color: const Color(0xff707070),
                              letterSpacing: 0.098,
                            ),
                          ),
                          Text(
                            '2. Criteria for Daily matches/Weekly matches',
                            style: TextStyle(
                              fontFamily: 'Arial',
                              fontSize: 14,
                              color: const Color(0xff707070),
                              letterSpacing: 0.098,
                            ),
                          ),
                          Text(
                            '3. Default search criteria in "Find Matches"',
                            style: TextStyle(
                              fontFamily: 'Arial',
                              fontSize: 14,
                              color: const Color(0xff707070),
                              letterSpacing: 0.098,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      Text(
                        'Describe your partner',
                        style: TextStyle(
                          fontFamily: 'Arial',
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: const Color(0xff707070),
                          letterSpacing: 0.098,
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      TextFieldCustom(
                        controller: describePartner,
                        style: miniGreyFontWeightStyle,
                        maxLines: 4,
                        inputType: TextInputType.text,
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Text(
                        'Current Preferences',
                        textAlign: TextAlign.start,
                        style: headingAppColorTextStyle,
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      Text(
                        'Age',
                        textAlign: TextAlign.start,
                        style: miniGreyFontWeightStyle,
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      TextFieldCustom(
                        controller: ageText,
                        style: miniGreyFontWeightStyle,
                        labelText: 'Age',
                        onTap: () {
                          setState(() {
                            selectedDrawer = 'Age';
                          });
                          _key.currentState.openEndDrawer();
                          FocusScope.of(context).requestFocus(new FocusNode());
                        },
                        validator: (value) {
                          if (value.isEmpty) {
                            return '*Required';
                          }
                          return null;
                        },
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      containerTile(
                          heading: 'Marital Status',
                          value: maritalStatus,
                          val: isMartialStatus,
                          isDrawer: true),
                      SizedBox(
                        height: 20,
                      ),
                      containerTile(
                          heading: 'Mother Tongue',
                          value: motherTongue,
                          val: isMotherTongue,
                          isDrawer: true),
                      SizedBox(
                        height: 20,
                      ),
                      containerTile(
                          heading: 'Religion',
                          value: religion,
                          val: isReligion,
                          isDrawer: true),
                      SizedBox(
                        height: 10,
                      ),
                      containerTile(
                          heading: 'Education',
                          value: education,
                          val: isEducation,
                          isDrawer: true),
                      SizedBox(
                        height: 20,
                      ),
                      containerTile(
                          heading: 'Profession',
                          value: profession,
                          val: isProfession,
                          isDrawer: true),
                      SizedBox(
                        height: 20,
                      ),
                      containerTile(
                          heading: 'State Living In',
                          value: stateLivingIn,
                          val: isStateLivingIn,
                          isDrawer: true),
                      SizedBox(
                        height: 15,
                      ),
                      containerTile(
                          heading: 'Visa',
                          value: visa,
                          val: isVisa),
                      SizedBox(
                        height: 20,
                      ),
                      Text(
                        'Add More Preferences',
                        textAlign: TextAlign.start,
                        style: headingAppColorTextStyle,
                      ),
                      SizedBox(
                        height: 15,
                      ),
                      Text(
                        'Height',
                        textAlign: TextAlign.start,
                        style: miniGreyFontWeightStyle,
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      TextFieldCustom(
                        controller: heightText,
                        style: miniGreyFontWeightStyle,
                        labelText: 'Height',
                        onTap: () {
                          setState(() {
                            selectedDrawer = 'Height';
                          });
                          _key.currentState.openEndDrawer();
                          FocusScope.of(context).requestFocus(new FocusNode());
                        },
                        validator: (value) {
                          if (value.isEmpty) {
                            return '*Required';
                          }
                          return null;
                        },
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      containerTile(
                          heading: 'Complexion',
                          value: complexion,
                          val: isComplexion),
                      SizedBox(
                        height: 20,
                      ),
                      Text(
                        'Salary',
                        textAlign: TextAlign.start,
                        style: miniGreyFontWeightStyle,
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      TextFieldCustom(
                        controller: salaryText,
                        style: miniGreyFontWeightStyle,
                        labelText: 'Salary',
                        onTap: () {
                          setState(() {
                            selectedDrawer = 'Salary';
                          });
                          _key.currentState.openEndDrawer();
                          FocusScope.of(context).requestFocus(new FocusNode());
                        },
                        validator: (value) {
                          if (value.isEmpty) {
                            return '*Required';
                          }
                          return null;
                        },
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      containerTile(
                          heading: 'Job Type',
                          value: jobType,
                          val: isJobType),
                      SizedBox(
                        height: 20,
                      ),
                      containerTile(
                          heading: 'Caste',
                          value: cast,
                          val: isCast),
                      SizedBox(
                        height: 20,
                      ),
                      containerTile(
                          heading: 'Raasi',
                          value: raasi,
                          val: isRaasi),
                      SizedBox(
                        height: 20,
                      ),
                      containerTile(
                          heading: 'Star',
                          value: star,
                          val: isStar),
                      SizedBox(
                        height: 20,
                      ),
                      containerTile(
                          heading: 'Physical Status',
                          value: physicalStatus,
                          val: isPhysicalStatus),
                      SizedBox(
                        height: 20,
                      ),
                      containerTile(
                          heading: 'Body Type',
                          value: bodyType,
                          val: isBodyType),
                      SizedBox(
                        height: 20,
                      ),
                      containerTile(
                          heading: 'Eating',
                          value: eating,
                          val: isEating),
                      SizedBox(
                        height: 20,
                      ),
                      containerTile(
                          heading: 'Drinking',
                          value: drinking,
                          val: isDrinking),
                      SizedBox(
                        height: 20,
                      ),
                      containerTile(
                          heading: 'Smoking',
                          value: smoking,
                          val: isSmoking),
                      SizedBox(
                        height: 20,
                      ),
                      containerTile(
                          heading: 'Country Living In',
                          value: country,
                          val: isCountry),
                      SizedBox(
                        height: 20,
                      ),
                      containerTile(
                          heading: 'City',
                          value: city,
                          val: isCity),
                      SizedBox(
                        height: 25,
                      ),
                      MaterialButton(
                        height: 60,
                        onPressed: () {
                          // print(ageFrom.text);
                          // print(
                          //   gender,
                          // );
                          // print(
                          //   'To: $heightTo, From: $heightFrom',
                          // );
                          // print(
                          //   motherTongue,
                          // );
                          // print(
                          //   cast,
                          // );
                          submitForm();
                        },
                        color: appColor,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Text(
                              'Submit',
                              style: miniWhiteTextStyle,
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      isDisplay
                          ? Column(
                              children: [
                                isMotherTongue
                                    ? displayError('Please select Mother Tongue')
                                    : Container(),
                                isCast
                                    ? displayError('Please select Caste')
                                    : Container(),
                                isRaasi
                                    ? displayError('Please select Raasi')
                                    : Container(),
                                isVisa
                                    ? displayError('Please select Visa')
                                    : Container(),
                                isPhysicalStatus
                                    ? displayError('Please select Physical Status')
                                    : Container(),
                                isProfession
                                    ? displayError('Please select Profession')
                                    : Container(),
                                isSalary
                                    ? displayError('Please select Salary')
                                    : Container(),
                                isJobType
                                    ? displayError('Please select JobType')
                                    : Container(),
                                isHeight
                                    ? displayError('Please select Height')
                                    : Container(),
                                isComplexion
                                    ? displayError('Please select Complexion')
                                    : Container(),
                                isMartialStatus
                                    ? displayError('Please select Martial Status')
                                    : Container(),
                                isReligion
                                    ? displayError('Please select Religion')
                                    : Container(),
                                isEducation
                                    ? displayError('Please select Education')
                                    : Container(),
                                isSmoking
                                    ? displayError('Please select Smoking')
                                    : Container(),
                                isStateLivingIn
                                    ? displayError('Please select State LivingIn')
                                    : Container(),
                                isStar
                                    ? displayError('Please select Star')
                                    : Container(),
                                isBodyType
                                    ? displayError('Please select Body Type')
                                    : Container(),
                                isEating
                                    ? displayError('Please select Eating')
                                    : Container(),
                                isDrinking
                                    ? displayError('Please select Drinking')
                                    : Container(),
                                isCountry
                                    ? displayError('Please select Country')
                                    : Container(),
                                isCity
                                    ? displayError('Please select City')
                                    : Container(),
                              ],
                            )
                          : Container(),
                      SizedBox(
                        height: 10,
                      ),
                    ],
                  ),
                ),
              ),
      ),
    );
  }

  Widget containerTile({String heading, String value, bool val, bool isDrawer = false}) {
    List<String> values = value != null && value != '' ? value.split(',') : [];
    // if(values.length > 0 && values[0] == ''){
    //   values = [];
    // }
    return InkWell(
      onTap: () {
        if(isDrawer){
          setState(() {
            selectedDrawer = heading;
          });
          _key.currentState.openEndDrawer();
        } else {
          if (heading == 'Visa') {
            _navigateAndSelectVisa(context);
          } else if (heading == 'Complexion') {
            _navigateAndSelectComplexion(context);
          } else if (heading == 'Job Type') {
            _navigateAndSelectJobType(context);
          } else if (heading == 'Caste') {
            _navigateAndSelectCast(context);
          } else if (heading == 'Raasi') {
            _navigateAndSelectRaasi(context);
          } else if (heading == 'Star') {
            _navigateAndSelectStar(context);
          } else if (heading == 'Physical Status') {
            _navigateAndSelectPhysicalStatus(context);
          } else if (heading == 'Body Type') {
            _navigateAndSelectBodyType(context);
          } else if (heading == 'Eating') {
            _navigateAndSelectEating(context);
          } else if (heading == 'Drinking') {
            _navigateAndSelectDrinking(context);
          } else if (heading == 'Smoking') {
            _navigateAndSelectSmoking(context);
          } else if (heading == 'Country Living In') {
            _navigateAndSelectCountry(context);
          } else if (heading == 'City') {
            _navigateAndSelectCity(context);
          }
        }
      },
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            heading,
            style: miniGreyFontWeightStyle,
          ),
          SizedBox(
            height: 5,
          ),
          Container(
            padding: EdgeInsets.symmetric(
              vertical: 15,
              horizontal: 15,
            ),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(5),
              border: Border.all(
                color: borderColorField,
                width: 1,
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                // Flexible(
                //   child: Text(
                //     value != null
                //         ? value
                //         : 'Select $heading',
                //     maxLines: null,
                //     textAlign: TextAlign.justify,
                //     style: TextStyle(
                //       fontSize: 14,
                //       color: value != null
                //           ? Colors.black
                //           : greyTextField,
                //     ),
                //   ),
                // ),
                values.length > 0
                    ? Container(
                        height: 40,
                        padding: EdgeInsets.only(left: 5, right: 5),
                        width: MediaQuery.of(context).size.width * 0.75,
                        child: ListView.separated(
                            itemCount: values.length,
                            scrollDirection: Axis.horizontal,
                            shrinkWrap: true,
                            separatorBuilder: (context, index) {
                              return Container(
                                width: 10,
                              );
                            },
                            itemBuilder: (context, index) {
                              return Container(
                                padding: EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color: borderColorField,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(30.0)),
                                ),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Text(
                                      values[index],
                                      style: TextStyle(fontSize: 12),
                                    ),
                                  ],
                                ),
                              );
                            }),
                      )
                    : Flexible(
                        child: Text(
                          'Select $heading',
                          maxLines: null,
                          textAlign: TextAlign.justify,
                          style: TextStyle(
                            fontSize: 14,
                            color: greyTextField,
                          ),
                        ),
                      ),
                Icon(
                  Icons.arrow_forward_ios,
                  color: grey,
                )
              ],
            ),
          ),
          (isDisplay && val)
              ? displayError('Please select $heading')
              : Container(),
        ],
      ),
    );
  }

  submitForm() async {
    if (_formKey.currentState.validate() &&
        !isCast && !isDrinking && !isCity &&
        // !isSalary &&
        // !isReligion &&
        !isMotherTongue && !isMartialStatus && !isVisa && !isCountry &&
        !isPhysicalStatus && !isBodyType && !isComplexion && !isSmoking &&
        !isEducation && !isRaasi && !isStar && !isJobType && !isEating &&
        !isProfession) {
      setState(() {
        isLoading = true;
        isDisplay = false;
      });
      gender = gender == "male" ? "M" : "F";
      // await submitData(UrlLinks.submitCaste, {'profilefunction': 'partnerpreference','fieldName': 'height','heightmin': heightFrom, 'heightmax': heightTo});
      await submitData(UrlLinks.submitCaste, {'profilefunction': 'partnerpreference','fieldname': 'age','agemin': ageFrom.text, 'agemax': ageTo.text});
      await submitData(UrlLinks.submitCaste, {'profilefunction': 'partnerpreference','fieldname': 'height','heightmin': 12, 'heightmax': 12});
      await submitData(UrlLinks.submitCaste, {'profilefunction': 'partnerpreference','fieldname': 'descpartner','fieldvalue': describePartner.text.trim()});
      // await submitData(UrlLinks.submitCaste, {'profilefunction': 'partnerpreference','fieldName': 'salarypd','currencypd': salaryCurrency});
      await submitData(UrlLinks.submitCaste, {'profilefunction': 'partnerpreference','fieldname': 'marstatus','fieldvalue': selectedIDsMaritalStatus.join(',')});
      await submitData(UrlLinks.submitCaste, {'profilefunction': 'partnerpreference','fieldname': 'mothertongue','fieldvalue': selectedIDsMotherTongue.join(',')});
      await submitData(UrlLinks.submitCaste, {'profilefunction': 'partnerpreference','fieldname': 'religion','fieldvalue': selectedIDsReligion.join(',')});
      await submitData(UrlLinks.submitCaste, {'profilefunction': 'partnerpreference','fieldname': 'education','fieldvalue': selectedIDsEducation.join(',')});
      await submitData(UrlLinks.submitCaste, {'profilefunction': 'partnerpreference','fieldname': 'profession','fieldvalue': selectedIDsProfession.join(',')});
      await submitData(UrlLinks.submitCaste, {'profilefunction': 'partnerpreference','fieldname': 'statelivingin','fieldvalue': selectedIDsStateLiving.join(',')});
      await submitData(UrlLinks.submitCaste, {'profilefunction': 'partnerpreference','fieldname': 'visabd','fieldvalue': visaIds});
      await submitData(UrlLinks.submitCaste, {'profilefunction': 'partnerpreference','fieldname': 'complexion','fieldvalue': complexionIds});
      await submitData(UrlLinks.submitCaste, {'profilefunction': 'partnerpreference','fieldname': 'salarypd','currencypd': 'B'});
      await submitData(UrlLinks.submitCaste, {'profilefunction': 'partnerpreference','fieldname': 'emplinpd','fieldvalue': jobTypeIds});
      await submitData(UrlLinks.submitCaste, {'profilefunction': 'partnerpreference','fieldname': 'caste','fieldvalue': castIds});
      await submitData(UrlLinks.submitCaste, {'profilefunction': 'partnerpreference','fieldname': 'raasi','fieldvalue': raasiIds});
      await submitData(UrlLinks.submitCaste, {'profilefunction': 'partnerpreference','fieldname': 'star','fieldvalue': starIds});
      await submitData(UrlLinks.submitCaste, {'profilefunction': 'partnerpreference','fieldname': 'phystatus','fieldvalue': physicalStatusIds});
      await submitData(UrlLinks.submitCaste, {'profilefunction': 'partnerpreference','fieldname': 'bodytype','fieldvalue': bodyTypeIds});
      await submitData(UrlLinks.submitCaste, {'profilefunction': 'partnerpreference','fieldname': 'eating','fieldvalue': eatingIds});
      await submitData(UrlLinks.submitCaste, {'profilefunction': 'partnerpreference','fieldname': 'drinking','fieldvalue': drinkingIds});
      await submitData(UrlLinks.submitCaste, {'profilefunction': 'partnerpreference','fieldname': 'smoking','fieldvalue': smokingIds});
      await submitData(UrlLinks.submitCaste, {'profilefunction': 'partnerpreference','fieldname': 'countrybd','fieldvalue': countryIds});
      await submitData(UrlLinks.submitCaste, {'profilefunction': 'partnerpreference','fieldname': 'city','fieldvalue': cityIds});
      getPartnerPreferencesData();
      // setState(() {
      //   isLoading = false;
      // });
      _key.currentState
        .showSnackBar(
          snackBar(
            'Partner Preferences Updated',
            Colors.green,
            Icons.verified_user,
          ),
        );
    } else {
      setState(() {
        isDisplay = true;
      });
      _key.currentState.showSnackBar(
        snackBar(
          'Missing required fields',
          Colors.red,
          Icons.verified_user,
        ),
      );
    }
  }

  _navigateAndSelectCast(BuildContext context) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => SelectMultiple(casteList.sublist(1, casteList.length), cast != null && cast.length > 0 ? cast+', ' : '')),
    ).then((result) {
      if (result != null) {
        setState(() {
          cast = result[0];
          castIds = result[1];
          isCast = result[0].toString().isEmpty;
        });
      }
    });
  }

  // _navigateAndSelectMotherTongue(BuildContext context) async {
  //   await Navigator.push(
  //     context,
  //     MaterialPageRoute(
  //         builder: (context) =>
  //             SelectMultiple(motherTongueList, motherTongue??'')),
  //   ).then((result) {
  //     if (result != null) {
  //       setState(() {
  //         motherTongue = result;
  //         result.toString().isEmpty
  //             ? isMotherTongue = true
  //             : isMotherTongue = false;
  //       });
  //     }
  //   });
  // }

  // _navigateAndSelectEducation(BuildContext context) async {
  //   await Navigator.push(
  //     context,
  //     MaterialPageRoute(
  //         builder: (context) =>
  //             SelectMultiple(educationTypesList, education ?? '')),
  //   ).then((result) {
  //     if (result != null) {
  //       setState(() {
  //         education = result;
  //         result.toString().isEmpty ? isEducation = true : isEducation = false;
  //       });
  //     }
  //   });
  // }

  // _navigateAndSelectMaritalStatus(BuildContext context) async {
  //   await Navigator.push(
  //     context,
  //     MaterialPageRoute(
  //         builder: (context) =>
  //             SelectMultiple(maritalStatusList, maritalStatus??'')),
  //   ).then((result) {
  //     if (result != null) {
  //       setState(() {
  //         maritalStatus = result;
  //         result.toString().isEmpty
  //             ? isMartialStatus = true
  //             : isMartialStatus = false;
  //       });
  //     }
  //   });
  // }

  // _navigateAndSelectProfession(BuildContext context) async {
  //   await Navigator.push(
  //     context,
  //     MaterialPageRoute(
  //         builder: (context) =>
  //             SelectMultiple(professionTypesList, profession ?? '')),
  //   ).then((result) {
  //     if (result != null) {
  //       setState(() {
  //         profession = result;
  //         result.toString().isEmpty
  //             ? isProfession = true
  //             : isProfession = false;
  //       });
  //     }
  //   });
  // }

  // _navigateAndSelectStateLivingIn(BuildContext context) async {
  //   await Navigator.push(
  //     context,
  //     MaterialPageRoute(
  //         builder: (context) =>
  //             SelectMultiple(stateTypesList, stateLivingIn ?? '')),
  //   ).then((result) {
  //     if (result != null) {
  //       setState(() {
  //         stateLivingIn = result;
  //         result.toString().isEmpty
  //             ? isStateLivingIn = true
  //             : isStateLivingIn = false;
  //       });
  //     }
  //   });
  // }

  _navigateAndSelectVisa(BuildContext context) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => SelectMultiple(visaTypesList, visa != null && visa.length > 0 ? visa+', ' : '')),
    ).then((result) {
      if (result != null) {
        setState(() {
          visa = result[0];
          visaIds = result[1];
          isVisa = result[0].toString().isEmpty;
        });
      }
    });
  }

  _navigateAndSelectSmoking(BuildContext context) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) =>
              SelectMultiple(smokingTypesList, smoking != null && smoking.length > 0 ? smoking+', ' : '')),
    ).then((result) {
      if (result != null) {
        setState(() {
          smoking = result[0];
          smokingIds = result[1];
          isSmoking = result[0].toString().isEmpty;
        });
      }
    });
  }

  _navigateAndSelectPhysicalStatus(BuildContext context) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) =>
              SelectMultiple(physicalStatusList, physicalStatus != null && physicalStatus.length > 0 ? physicalStatus+', ' : '')),
    ).then((result) {
      if (result != null) {
        setState(() {
          physicalStatus = result[0];
          physicalStatusIds = result[1];
          isPhysicalStatus = result[0].toString().isEmpty;
        });
      }
    });
  }

  _navigateAndSelectComplexion(BuildContext context) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) =>
              SelectMultiple(complexionTypesList, complexion != null && complexion.length > 0 ? complexion+', ' : '')),
    ).then((result) {
      if (result != null) {
        setState(() {
          complexion = result[0];
          complexionIds = result[1];
          isComplexion = result[0].toString().isEmpty;
        });
      }
    });
  }

  _navigateAndSelectJobType(BuildContext context) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => SelectMultiple(jobTypesList, jobType != null && jobType.length > 0 ? jobType+', ' : '')),
    ).then((result) {
      if (result != null) {
        setState(() {
          jobType = result[0];
          jobTypeIds = result[1];
          isJobType = result[0].toString().isEmpty;
        });
      }
    });
  }

  _navigateAndSelectRaasi(BuildContext context) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => SelectMultiple(raasiTypesList, raasi != null && raasi.length > 0 ? raasi+', ' : '')),
    ).then((result) {
      if (result != null) {
        setState(() {
          raasi = result[0];
          raasiIds = result[1];
          isRaasi = result[0].toString().isEmpty;
        });
      }
    });
  }

  _navigateAndSelectStar(BuildContext context) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => SelectMultiple(starTypesList, star != null && star.length > 0 ? star+', ' : '')),
    ).then((result) {
      if (result != null) {
        setState(() {
          star = result[0];
          starIds = result[1];
          isStar = result[0].toString().isEmpty;
        });
      }
    });
  }

  _navigateAndSelectBodyType(BuildContext context) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => SelectMultiple(bodyTypesList, bodyType != null && bodyType.length > 0 ? bodyType+', ' : '')),
    ).then((result) {
      if (result != null) {
        setState(() {
          bodyType = result[0];
          bodyTypeIds = result[1];
          isBodyType = result[0].toString().isEmpty;
        });
      }
    });
  }

  _navigateAndSelectEating(BuildContext context) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => SelectMultiple(eatingTypesList, eating != null && eating.length > 0 ? eating+', ' : '')),
    ).then((result) {
      if (result != null) {
        setState(() {
          eating = result[0];
          eatingIds = result[1];
          isEating = result[0].toString().isEmpty;
        });
      }
    });
  }

  _navigateAndSelectDrinking(BuildContext context) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) =>
              SelectMultiple(drinkingTypesList, drinking != null && drinking.length > 0 ? drinking+', ' : '')),
    ).then((result) {
      if (result != null) {
        setState(() {
          drinking = result[0];
          drinkingIds = result[1];
          isDrinking = result[0].toString().isEmpty;
        });
      }
    });
  }

  _navigateAndSelectCountry(BuildContext context) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => SelectMultiple(countries.sublist(1, countries.length), country != null && country.length > 0 ? country+', ' : '')),
    ).then((result) {
      if (result != null) {
        setState(() {
          country = result[0];
          countryIds = result[1];
          isCountry = result.toString().isEmpty;
        });
      }
    });
  }

  _navigateAndSelectCity(BuildContext context) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => SelectMultiple(citiesList, country != null && country.length > 0 ? country+', ' : '')),
    ).then((result) {
      if (result != null) {
        setState(() {
          city = result[0];
          cityIds = result[1];
          isCity = result[0].toString().isEmpty;
        });
      }
    });
  }
}
