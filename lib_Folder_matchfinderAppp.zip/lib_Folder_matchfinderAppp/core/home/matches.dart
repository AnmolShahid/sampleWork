import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_swiper/flutter_swiper.dart';
import 'package:matchfinder/const/const.dart';
import 'package:matchfinder/const/general_methods.dart';
import 'package:matchfinder/core/home/match_profile.dart';
import 'package:matchfinder/model/profile_list.dart';
import 'package:matchfinder/utils/style.dart';
import 'package:matchfinder/widgets/imageWidget.dart';
import 'package:matchfinder/widgets/image_widget.dart';
import 'package:matchfinder/widgets/show_dialog.dart';
import 'package:matchfinder/widgets/toast.dart';

class Matches extends StatefulWidget {
  @override
  _MatchesState createState() => _MatchesState();
}

class _MatchesState extends State<Matches> {
  TextEditingController searchController = new TextEditingController();
  List<dynamic> _profiles = new List<dynamic>();
  var _menus = List<Map<String, dynamic>>();
  var _options = List<Map<String, dynamic>>();
  var selectedIndex = 0;
  bool isLoading = true;
  var _index = 0;

  @override
  void initState() {
    _menus.add({
      'title': 'All Matches',
      'filter': 'all',
    });
    _menus.add({
      'title': 'Daily Matches',
      'filter': 'daily',
    });
    _menus.add({
      'title': 'Weekly Matches',
      'filter': 'weekly',
    });
    _menus.add({
      'title': 'Blocked',
      'filter': 'blocked',
    });
    _menus.add({
      'title': 'Shortlisted',
      'filter': 'shortlisted',
    });
    _menus.add({
      'title': 'Ignored',
      'filter': 'ignored',
    });

    _options.add({
      'title': 'Chat',
      'icon': 'assets/chat_msgs.svg',
    });
    _options.add({'title': 'Horoscope', 'icon': 'assets/horoscope.svg'});
    _options.add({
      'title': 'Call',
      'icon': 'assets/call.svg',
    });
    _options.add({
      'title': 'Block',
      'icon': 'assets/remove_user.svg',
    });
    _options.add({
      'title': 'Request Photo',
      'icon': 'assets/request_photo.svg',
    });
    _options.add({
      'title': 'Photo Password',
      'icon': 'assets/photo_password.svg',
    });
    _options.add({
      'title': 'Request Horoscope',
      'icon': 'assets/request_horoscope.svg',
    });
    getMatches('all');
    super.initState();
  }

  getMatches(filter) {
    _profiles.clear();
    _profiles.add({
      'id': 'T5869321',
      'name': 'Sri Lallitha',
      'lock': false,
      'photoUrl_220': "assets/220220_1.jpg",
      'photoUrl_275': "assets/275205_1.jpg",
      'photoUrl_500': "assets/500500_1.jpg",
      'Age': '26 Yrs, 5\'2"',
      'Religion': 'Hindu, Brahmin',
      'Star': 'Moola',
      'Location': 'Hyderabad Tala, India',
      'Education': 'BSc IT / Computer science',
      'Profession': 'Banking Professional',
    });
    _profiles.add({
      'id': 'T5869321',
      'name': 'Sri Lallitha',
      'lock': true,
      'photoUrl_220': "assets/220220_2.jpg",
      'photoUrl_275': "assets/275205_2.jpg",
      'photoUrl_500': "assets/500500_2.jpg",
      'Age': '26 Yrs, 5\'2"',
      'Religion': 'Hindu, Brahmin',
      'Star': 'Moola',
      'Location': 'Hyderabad Tala, India',
      'Education': 'BSc IT / Computer science',
      'Profession': 'Banking Professional',
    });
    // _profiles.add({
    //   'id': 'T5869321',
    //   'name': 'Sri Lallitha',
    //   'photoUrl': "assets/1_3.jpg",
    //   'innerPhotoUrl': "assets/1_3.jpg",
    //   'Age': '26 Yrs, 5\'2"',
    //   'Religion': 'Hindu, Brahmin',
    //   'Star': 'Moola',
    //   'Location': 'Hyderabad Tala, India',
    //   'Education': 'BSc IT / Computer science',
    //   'Profession': 'Banking Professional',
    // });
  }

  @override
  Widget build(BuildContext context) {
    var screenSize = MediaQuery.of(context).size;

    return Scaffold(
        body: SafeArea(
      child: Container(
        color: appColor,
        child: Column(
          children: [
            Container(
              height: screenSize.height * 0.1,
              padding: EdgeInsets.all(10),
              alignment: Alignment.center,
              child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: _menus.length,
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (context, index) {
                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          selectedIndex = index;
                          getMatches(_menus[index]['filter']);
                        });
                      },
                      child: Center(
                        child: Container(
                          decoration: BoxDecoration(
                            color: white,
                            borderRadius:
                                BorderRadius.all(Radius.circular(20.0)),
                          ),
                          margin: EdgeInsets.all(5),
                          padding: EdgeInsets.all(10),
                          child: new Text(
                            _menus[index]['title'],
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontFamily: "Quicksand",
                              fontWeight: FontWeight.w500,
                              fontSize: 16,
                              color: black,
                              decoration: selectedIndex == index
                                  ? TextDecoration.underline
                                  : TextDecoration.none,
                            ),
                          ),
                        ),
                      ),
                    );
                  }),
            ),
            Expanded(
              child: Container(
                  padding: EdgeInsets.all(15),
                  decoration: BoxDecoration(
                      color: white,
                      borderRadius: new BorderRadius.only(
                        topLeft: Radius.circular(20.0),
                        topRight: Radius.circular(20.0),
                      )),
                  child: ListView(
                    shrinkWrap: true,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            height: 50,
                            margin: EdgeInsets.all(5),
                            width: screenSize.width * 0.84,
                            decoration: BoxDecoration(
                              color: white,
                              border: Border.all(
                                width: 1.00,
                                color: black,
                              ),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(15.0)),
                            ),
                            child: new TextFormField(
                              controller: searchController,
                              keyboardType: TextInputType.text,
                              autofocus: false,
                              onChanged: (val) {},
                              decoration: InputDecoration(
                                border: InputBorder.none,
                                labelText:
                                    'Search for brides for e.g, Brahmin delhi',
                                contentPadding: const EdgeInsets.all(10.0),
                                labelStyle: TextStyle(
                                  color: Colors.grey,
                                ),
                              ),
                            ),
                          ),
                          Image.asset(
                            'assets/filter_icon.png',
                            width: 25,
                            height: 25,
                          ),
                          // Icon(
                          //   Icons.filter_list,
                          //   size: screenSize.width * 0.06,
                          //   color: black,
                          // )
                        ],
                      ),
                      Divider(
                        color: grey,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              // Image.asset('assets/ribbon.png', width: 50, height: 40,),
                              AssetImageWidget(
                                image: 'assets/ribbon.svg',
                                width: 50,
                                height: 40,
                                color: orange,
                              ),
                              SizedBox(
                                width: 10,
                              ),
                              Text(
                                'Premium Accounts',
                                style: TextStyle(
                                  fontFamily: 'Arial',
                                  fontWeight: FontWeight.w600,
                                  fontSize: 18,
                                  color: const Color(0xffc51010),
                                  letterSpacing: 0.44,
                                  height: 1.4545454545454546,
                                ),
                              ),
                            ],
                          ),
                          InkWell(
                            onTap: () {
                              switcher = switcher == 0 ? 1 : 0;
                              print(switcher);
                              setState(() {});
                            },
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Text('Switch View'),
                                SizedBox(
                                  width: 10,
                                ),
                                Column(
                                  children: [
                                    AssetImageWidget(
                                      image: 'assets/left_arrow.svg',
                                      height: 15,
                                      width: 25,
                                      color: black,
                                    ),
                                    AssetImageWidget(
                                      image: 'assets/right_arrow.svg',
                                      height: 15,
                                      width: 25,
                                      color: black,
                                    ),
                                    // Image.asset('assets/right-arrow.png', width: 25, height: 25,),
                                  ],
                                )
                              ],
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 10),
                      Container(
                        height: 140,
                        child: ListView.builder(
                            shrinkWrap: true,
                            primary: false,
                            scrollDirection: Axis.horizontal,
                            itemCount: _profiles.length,
                            itemBuilder: (context, index) {
                              return GestureDetector(
                                onTap: () {
                                  changeScreen(
                                      context,
                                      MatchProfile(
                                        profile: _profiles[index],
                                      ));
                                },
                                child: Container(
                                  padding: EdgeInsets.all(5),
                                  margin: EdgeInsets.only(right: 5),
                                  decoration: BoxDecoration(
                                    border: Border.all(width: 1, color: grey),
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(5)),
                                  ),
                                  child: Row(
                                    children: [
                                      ImageWidget(
                                        image: _profiles[index]['photoUrl_220'],
                                        radius: 0,
                                        height: 130,
                                        width: 130,
                                      ),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(_profiles[index]['name']),
                                          Text(_profiles[index]['Age']),
                                          Text(_profiles[index]['Religion']),
                                        ],
                                      )
                                    ],
                                  ),
                                ),
                              );
                            }),
                      ),
                      SizedBox(height: 20),
                      switcher == 0
                          ? Container(
                              height: screenSize.height * 0.82,
                              // padding: EdgeInsets.all(20),
                              child: Column(
                                children: [
                                  Expanded(
                                    child: Swiper(
                                      loop: true,
                                      // physics: NeverScrollableScrollPhysics(),
                                      control: SwiperControl(
                                          color: grey,
                                          padding: EdgeInsets.only(
                                              bottom: screenSize.height * 0.3,
                                              left: 10,
                                              right: 10),
                                          size: 40),
                                      scrollDirection: Axis.horizontal,
                                      itemCount: _profiles.length,
                                      itemBuilder:
                                          (BuildContext context, int index) {
                                        return GestureDetector(
                                          onTap: () {
                                            changeScreen(
                                                context,
                                                MatchProfile(
                                                  profile: _profiles[index],
                                                ));
                                          },
                                          child: ListView(
                                            // shrinkWrap: true,
                                            primary: false,
                                            physics:
                                                NeverScrollableScrollPhysics(),
                                            children: [
                                              Container(
                                                  padding: EdgeInsets.all(20),
                                                  width: screenSize.width,
                                                  decoration: BoxDecoration(
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: Colors.grey
                                                            .withOpacity(0.1),
                                                        spreadRadius: 2,
                                                        blurRadius: 3,
                                                        offset: Offset(0,
                                                            0), // changes position of shadow
                                                      ),
                                                    ],
                                                    color: backGroundColor,
                                                    border: Border.all(
                                                      width: 2.00,
                                                      color: backGroundColor,
                                                    ),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            30.00),
                                                  ),
                                                  child: Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      Text(
                                                        _profiles[index]
                                                            ['name'],
                                                        style:
                                                            headingSmallBlackStyle,
                                                      ),
                                                      SizedBox(height: 10),
                                                      Text(
                                                        _profiles[index]['id'],
                                                        style: TextStyle(
                                                          fontFamily: 'Arial',
                                                          fontSize: 14,
                                                          color: const Color(
                                                              0xff040404),
                                                          fontWeight:
                                                              FontWeight.w700,
                                                          height:
                                                              0.9285714285714286,
                                                        ),
                                                      ),
                                                      SizedBox(height: 20),
                                                      Container(
                                                        alignment:
                                                            Alignment.center,
                                                        child: ImageWidget(
                                                            width: 220 * 1.3,
                                                            height: 220 * 1.3,
                                                            image: _profiles[
                                                                    index][
                                                                'photoUrl_220']),
                                                      ),
                                                      SizedBox(height: 20),
                                                      Row(
                                                        children: [
                                                          Container(
                                                            width: screenSize
                                                                    .width *
                                                                0.35,
                                                            child: Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              children: [
                                                                Text(
                                                                  'Age',
                                                                  style: TextStyle(
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .bold),
                                                                ),
                                                                Text(
                                                                  'Religion/Caste',
                                                                  style: TextStyle(
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .bold),
                                                                ),
                                                                Text(
                                                                  'Star',
                                                                  style: TextStyle(
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .bold),
                                                                ),
                                                                Text(
                                                                  'Location',
                                                                  style: TextStyle(
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .bold),
                                                                ),
                                                                Text(
                                                                  'Education',
                                                                  style: TextStyle(
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .bold),
                                                                ),
                                                                Text(
                                                                  'Profession',
                                                                  style: TextStyle(
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .bold),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Container(
                                                            width: screenSize
                                                                    .width *
                                                                0.45,
                                                            child: Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              children: [
                                                                Text(
                                                                  ': ' +
                                                                      _profiles[
                                                                              index]
                                                                          [
                                                                          'Age'],
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                ),
                                                                Text(
                                                                  ': ' +
                                                                      _profiles[
                                                                              index]
                                                                          [
                                                                          'Religion'],
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                ),
                                                                Text(
                                                                  ': ' +
                                                                      _profiles[
                                                                              index]
                                                                          [
                                                                          'Star'],
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                ),
                                                                Text(
                                                                  ': ' +
                                                                      _profiles[
                                                                              index]
                                                                          [
                                                                          'Location'],
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                ),
                                                                Text(
                                                                  ': ' +
                                                                      _profiles[
                                                                              index]
                                                                          [
                                                                          'Education'],
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                ),
                                                                Text(
                                                                  ': ' +
                                                                      _profiles[
                                                                              index]
                                                                          [
                                                                          'Profession'],
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ],
                                                  )),
                                              SizedBox(height: 10),
                                              Container(
                                                height: screenSize.height * 0.1,
                                                padding: EdgeInsets.all(10),
                                                alignment: Alignment.center,
                                                child: ListView.builder(
                                                    shrinkWrap: true,
                                                    primary: false,
                                                    itemCount: _options.length,
                                                    scrollDirection:
                                                        Axis.horizontal,
                                                    itemBuilder:
                                                        (context, index) {
                                                      return GestureDetector(
                                                          onTap: () {
                                                            setState(() {});
                                                          },
                                                          child: Container(
                                                            padding:
                                                                EdgeInsets.all(
                                                                    5),
                                                            child: Column(
                                                              children: [
                                                                AssetImageWidget(
                                                                  image: _options[
                                                                          index]
                                                                      ['icon'],
                                                                  color: black,
                                                                ),
                                                                SizedBox(
                                                                  height: 5,
                                                                ),
                                                                Text(
                                                                  _options[
                                                                          index]
                                                                      ['title'],
                                                                  style:
                                                                      TextStyle(
                                                                    color:
                                                                        black,
                                                                    fontSize: 9,
                                                                  ),
                                                                )
                                                              ],
                                                            ),
                                                          ));
                                                    }),
                                              ),
                                              Container(
                                                  child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceEvenly,
                                                children: [
                                                  Container(
                                                    padding: EdgeInsets.all(10),
                                                    decoration: BoxDecoration(
                                                      color: white,
                                                      boxShadow: [
                                                        BoxShadow(
                                                          color: Colors.grey
                                                              .withOpacity(0.3),
                                                          spreadRadius: 2,
                                                          blurRadius: 3,
                                                          offset: Offset(0,
                                                              0), // changes position of shadow
                                                        ),
                                                      ],
                                                      borderRadius:
                                                          BorderRadius.all(
                                                              Radius.circular(
                                                                  25.0)),
                                                    ),
                                                    child: GestureDetector(
                                                      onTap: () {
                                                        showExpressInterestDialog(
                                                            context,
                                                            screenSize,
                                                            searchController,
                                                            'Send',
                                                            400.0,
                                                            btnText2:
                                                                'Upgrade Plan',
                                                            onSave: () {
                                                          ToastUtil.showToastCenter(
                                                              context,
                                                              'Interest Sent Successfully');
                                                          Navigator.pop(
                                                              context);
                                                        });
                                                      },
                                                      child: new Text(
                                                        'Send Interest',
                                                        style:
                                                            miniBlackTextStyle,
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    padding: EdgeInsets.all(10),
                                                    decoration: BoxDecoration(
                                                      color: white,
                                                      boxShadow: [
                                                        BoxShadow(
                                                          color: Colors.grey
                                                              .withOpacity(0.3),
                                                          spreadRadius: 2,
                                                          blurRadius: 3,
                                                          offset: Offset(0,
                                                              0), // changes position of shadow
                                                        ),
                                                      ],
                                                      borderRadius:
                                                          BorderRadius.all(
                                                              Radius.circular(
                                                                  25.0)),
                                                    ),
                                                    child: new Text(
                                                      'Shortlist',
                                                      style: miniBlackTextStyle,
                                                    ),
                                                  ),
                                                  Container(
                                                    padding: EdgeInsets.all(10),
                                                    decoration: BoxDecoration(
                                                      color: white,
                                                      boxShadow: [
                                                        BoxShadow(
                                                          color: Colors.grey
                                                              .withOpacity(0.3),
                                                          spreadRadius: 2,
                                                          blurRadius: 3,
                                                          offset: Offset(0,
                                                              0), // changes position of shadow
                                                        ),
                                                      ],
                                                      borderRadius:
                                                          BorderRadius.all(
                                                              Radius.circular(
                                                                  25.0)),
                                                    ),
                                                    child: new Text(
                                                      'Ignore',
                                                      style: miniBlackTextStyle,
                                                    ),
                                                  )
                                                ],
                                              ))
                                            ],
                                          ),
                                        );
                                      },
                                      viewportFraction: 1,
                                      scale: 0.6,
                                      index: _index,
                                      onIndexChanged: (index) {
                                        setState(() {
                                          _index = index;
                                        });
                                      },
                                      pagination: new SwiperPagination(
                                        margin: new EdgeInsets.only(top: 100.0),
                                        alignment: Alignment.bottomCenter,
                                        builder: new DotSwiperPaginationBuilder(
                                            color: grey, activeColor: appColor),
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: 5),
                                  Text('13 matches found')
                                ],
                              ),
                            )
                          : Column(
                              children: [
                                ListView.separated(
                                    shrinkWrap: true,
                                    primary: false,
                                    itemCount: _profiles.length,
                                    separatorBuilder: (context, index) {
                                      return SizedBox(
                                        height: 20,
                                      );
                                    },
                                    itemBuilder: (context, index) {
                                      return GestureDetector(
                                        onTap: () {
                                          changeScreen(
                                              context,
                                              MatchProfile(
                                                profile: _profiles[index],
                                              ));
                                        },
                                        child: Container(
                                          decoration: BoxDecoration(
                                            boxShadow: [
                                              BoxShadow(
                                                color: Colors.grey
                                                    .withOpacity(0.1),
                                                spreadRadius: 2,
                                                blurRadius: 3,
                                                offset: Offset(0,
                                                    0), // changes position of shadow
                                              ),
                                            ],
                                            color: backGroundColor,
                                            border: Border.all(
                                              width: 2.00,
                                              color: backGroundColor,
                                            ),
                                            borderRadius:
                                                BorderRadius.circular(30.00),
                                          ),
                                          child: ListView(
                                            shrinkWrap: true,
                                            primary: false,
                                            children: [
                                              Container(
                                                  //  padding: EdgeInsets.all(20),
                                                  width: screenSize.width,
                                                  decoration: BoxDecoration(
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: Colors.grey
                                                            .withOpacity(0.1),
                                                        spreadRadius: 2,
                                                        blurRadius: 3,
                                                        offset: Offset(0,
                                                            0), // changes position of shadow
                                                      ),
                                                    ],
                                                    color: backGroundColor,
                                                    border: Border.all(
                                                      width: 2.00,
                                                      color: backGroundColor,
                                                    ),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            20.00),
                                                  ),
                                                  child: Column(
                                                    children: [
                                                      _profiles[index]['lock']
                                                          ? Container(
                                                              height: 40,
                                                              width: screenSize
                                                                  .width,
                                                              color: orange,
                                                              child: Column(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .center,
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .center,
                                                                children: [
                                                                  Text(
                                                                    'Premium Member',
                                                                    style: TextStyle(
                                                                        color:
                                                                            white,
                                                                        fontSize:
                                                                            20),
                                                                  ),
                                                                ],
                                                              ),
                                                            )
                                                          : Container(),
                                                      Stack(
                                                        children: [
                                                          Container(
                                                              height: 205 * 1.6,
                                                              width: 275 * 1.6,
                                                              alignment:
                                                                  Alignment
                                                                      .center,
                                                              decoration: BoxDecoration(
                                                                  borderRadius:
                                                                      BorderRadius.circular(
                                                                          10.0),
                                                                  image: DecorationImage(
                                                                      image: AssetImage(
                                                                          _profiles[index]
                                                                              [
                                                                              'photoUrl_275']),
                                                                      fit: BoxFit
                                                                          .contain)),
                                                              child: _profiles[
                                                                          index]
                                                                      ['lock']
                                                                  ? ClipRect(
                                                                      child:
                                                                          BackdropFilter(
                                                                        filter: ImageFilter.blur(
                                                                            sigmaX:
                                                                                20.0,
                                                                            sigmaY:
                                                                                20.0),
                                                                        child:
                                                                            Container(
                                                                          color: Colors
                                                                              .black
                                                                              .withOpacity(0.1),
                                                                        ),
                                                                      ),
                                                                    )
                                                                  : Container()),
                                                          _profiles[index]
                                                                  ['lock']
                                                              ? Positioned(
                                                                  right: 0,
                                                                  bottom: 0,
                                                                  child:
                                                                      GestureDetector(
                                                                    onTap: () {
                                                                      showPhotoAlertDialog(
                                                                          context,
                                                                          screenSize,
                                                                          'Unlock',
                                                                          dialogUI(
                                                                              'Unlock Photo',
                                                                              ''),
                                                                          170.0,
                                                                          onSave:
                                                                              () {
                                                                        setState(
                                                                            () {
                                                                          _profiles[index]['lock'] =
                                                                              false;
                                                                        });
                                                                        Navigator.pop(
                                                                            context);
                                                                      });
                                                                    },
                                                                    child: Container(
                                                                        margin: EdgeInsets.all(10),
                                                                        width: 40,
                                                                        height: 40,
                                                                        decoration: BoxDecoration(
                                                                          color:
                                                                              white,
                                                                          borderRadius:
                                                                              BorderRadius.circular(20.00),
                                                                        ),
                                                                        child: Icon(Icons.lock, color: orangeLinear)),
                                                                  ))
                                                              : Container(),
                                                        ],
                                                      ),
                                                    ],
                                                  )),
                                              SizedBox(height: 5),
                                              Container(
                                                // margin: EdgeInsets.only(left: 5),
                                                height:
                                                    screenSize.height * 0.09,
                                                padding: EdgeInsets.all(10),
                                                alignment: Alignment.center,
                                                child: ListView.builder(
                                                    shrinkWrap: true,
                                                    primary: false,
                                                    itemCount: _options.length,
                                                    scrollDirection:
                                                        Axis.horizontal,
                                                    itemBuilder:
                                                        (context, index) {
                                                      return GestureDetector(
                                                          onTap: () {
                                                            setState(() {});
                                                          },
                                                          child: Container(
                                                            padding:
                                                                EdgeInsets.all(
                                                                    5),
                                                            child: Column(
                                                              children: [
                                                                AssetImageWidget(
                                                                  image: _options[
                                                                          index]
                                                                      ['icon'],
                                                                  color:
                                                                      greenBtn,
                                                                ),
                                                                SizedBox(
                                                                  height: 5,
                                                                ),
                                                                Text(
                                                                  _options[
                                                                          index]
                                                                      ['title'],
                                                                  style:
                                                                      TextStyle(
                                                                    color:
                                                                        black,
                                                                    fontSize: 9,
                                                                  ),
                                                                )
                                                              ],
                                                            ),
                                                          ));
                                                    }),
                                              ),
                                              Container(
                                                  child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceEvenly,
                                                children: [
                                                  Container(
                                                    padding: EdgeInsets.all(10),
                                                    decoration: BoxDecoration(
                                                      border: Border.all(
                                                          color: greenBtn),
                                                      color: white,
                                                      boxShadow: [
                                                        BoxShadow(
                                                          color: Colors.grey
                                                              .withOpacity(0.3),
                                                          spreadRadius: 2,
                                                          blurRadius: 3,
                                                          offset: Offset(0,
                                                              0), // changes position of shadow
                                                        ),
                                                      ],
                                                      borderRadius:
                                                          BorderRadius.all(
                                                              Radius.circular(
                                                                  25.0)),
                                                    ),
                                                    child: GestureDetector(
                                                      onTap: () {
                                                        showExpressInterestDialog(
                                                            context,
                                                            screenSize,
                                                            searchController,
                                                            'Send',
                                                            400.0,
                                                            btnText2:
                                                                'Upgrade Plan',
                                                            onSave: () {
                                                          ToastUtil.showToastCenter(
                                                              context,
                                                              'Interest Sent Successfully');
                                                          Navigator.pop(
                                                              context);
                                                        });
                                                      },
                                                      child: new Text(
                                                        'Send Interest',
                                                        style:
                                                            miniBlackTextStyle,
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    padding: EdgeInsets.all(10),
                                                    decoration: BoxDecoration(
                                                      color: white,
                                                      border: Border.all(
                                                          color: orangeLinear),
                                                      boxShadow: [
                                                        BoxShadow(
                                                          color: Colors.grey
                                                              .withOpacity(0.3),
                                                          spreadRadius: 2,
                                                          blurRadius: 3,
                                                          offset: Offset(0,
                                                              0), // changes position of shadow
                                                        ),
                                                      ],
                                                      borderRadius:
                                                          BorderRadius.all(
                                                              Radius.circular(
                                                                  25.0)),
                                                    ),
                                                    child: new Text(
                                                      'Shortlist',
                                                      style: miniBlackTextStyle,
                                                    ),
                                                  ),
                                                  Container(
                                                    padding: EdgeInsets.all(10),
                                                    decoration: BoxDecoration(
                                                      border: Border.all(
                                                          color: redBtn),
                                                      color: white,
                                                      boxShadow: [
                                                        BoxShadow(
                                                          color: Colors.grey
                                                              .withOpacity(0.3),
                                                          spreadRadius: 2,
                                                          blurRadius: 3,
                                                          offset: Offset(0,
                                                              0), // changes position of shadow
                                                        ),
                                                      ],
                                                      borderRadius:
                                                          BorderRadius.all(
                                                              Radius.circular(
                                                                  25.0)),
                                                    ),
                                                    child: new Text(
                                                      'Ignore',
                                                      style: miniBlackTextStyle,
                                                    ),
                                                  )
                                                ],
                                              )),
                                              SizedBox(height: 10),
                                              Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  SizedBox(width: 20),
                                                  Text(
                                                    _profiles[index]['name'],
                                                    style: headingBBlackStyle,
                                                  ),
                                                  SizedBox(width: 20),
                                                  SizedBox(
                                                    child: Text(
                                                      _profiles[index]['Age'] +
                                                          ' , ' +
                                                          _profiles[index]
                                                              ['Religion'] +
                                                          ' , ' +
                                                          _profiles[index]
                                                              ['Star'] +
                                                          ' , \n' +
                                                          _profiles[index]
                                                              ['Location'] +
                                                          ' , \n' +
                                                          _profiles[index]
                                                              ['Education'] +
                                                          ' , \n' +
                                                          _profiles[index]
                                                              ['Profession'],
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                    ),
                                                  ),
                                                  SizedBox(height: 20),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                      );
                                    }),
                                SizedBox(height: 5),
                                Text(
                                  '13 matches found',
                                  textAlign: TextAlign.center,
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Text(
                                      'Swipe to load more',
                                      textAlign: TextAlign.center,
                                    ),
                                    SizedBox(width: 5),
                                    Icon(
                                      Icons.arrow_circle_up,
                                      color: appColor,
                                      size: 16,
                                    )
                                  ],
                                )
                              ],
                            )
                      // Container(
                      //         height: screenSize.height * 0.77,
                      //         // padding: EdgeInsets.all(20),
                      //         child: Swiper(
                      //           loop: true,
                      //           /*   control: SwiperControl(
                      //               color: grey,
                      //               padding: EdgeInsets.only(
                      //                   bottom: screenSize.height * 0.3,
                      //                   left: 10,
                      //                   right: 10),
                      //               size: 40),*/
                      //           itemCount: _profiles.length,
                      //           scrollDirection: Axis.vertical,
                      //           itemBuilder: (BuildContext context, int index) {
                      //             // return Column(
                      //             //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      //             //   children: [
                      //             //     GestureDetector(
                      //             //       onTap: () {
                      //             //         if (sw == 1) {
                      //             //           changeScreen(
                      //             //               context,
                      //             //               MatchProfile(
                      //             //                 profile: _profiles[index],
                      //             //               ));
                      //             //         } else {
                      //             //           showPhotoAlertDialog(
                      //             //               context,
                      //             //               screenSize,
                      //             //               'Unlock',
                      //             //               dialogUI('Unlock Photo', ''),
                      //             //               170.0, onSave: () {
                      //             //             setState(() {
                      //             //               sw = 1;
                      //             //             });
                      //             //             Navigator.pop(context);
                      //             //           });
                      //             //         }
                      //             //       },
                      //             //       child: ListView(
                      //             //         shrinkWrap: true,
                      //             //         primary: false,
                      //             //         children: [
                      //             //           Container(
                      //             //               //  padding: EdgeInsets.all(20),
                      //             //               width: screenSize.width,
                      //             //               decoration: BoxDecoration(
                      //             //                 boxShadow: [
                      //             //                   BoxShadow(
                      //             //                     color: Colors.grey
                      //             //                         .withOpacity(0.1),
                      //             //                     spreadRadius: 2,
                      //             //                     blurRadius: 3,
                      //             //                     offset: Offset(0,
                      //             //                         0), // changes position of shadow
                      //             //                   ),
                      //             //                 ],
                      //             //                 color: backGroundColor,
                      //             //                 border: Border.all(
                      //             //                   width: 2.00,
                      //             //                   color: backGroundColor,
                      //             //                 ),
                      //             //                 borderRadius:
                      //             //                     BorderRadius.circular(
                      //             //                         20.00),
                      //             //               ),
                      //             //               child: Stack(
                      //             //                 children: [
                      //             //                   //   SizedBox(height: 10),
                      //             //                   sw == 1
                      //             //                       ? Container(
                      //             //                           alignment: Alignment
                      //             //                               .center,
                      //             //                           //
                      //             //                           child: ImageWidget(
                      //             //                               width:
                      //             //                                   screenSize
                      //             //                                       .width,
                      //             //                               height: screenSize
                      //             //                                       .height *
                      //             //                                   0.25,
                      //             //                               image: _profiles[
                      //             //                                       index][
                      //             //                                   'photoUrl']),
                      //             //                         )
                      //             //                       : Container(
                      //             //                           alignment: Alignment
                      //             //                               .center,
                      //             //                           decoration:
                      //             //                               new BoxDecoration(
                      //             //                             image:
                      //             //                                 new DecorationImage(
                      //             //                               image: AssetImage(
                      //             //                                   _profiles[
                      //             //                                           index]
                      //             //                                       [
                      //             //                                       'photoUrl']),
                      //             //                               fit: BoxFit
                      //             //                                   .cover,
                      //             //                             ),
                      //             //                           ),
                      //             //                           child:
                      //             //                               new BackdropFilter(
                      //             //                             filter:
                      //             //                                 new ImageFilter
                      //             //                                         .blur(
                      //             //                                     sigmaX:
                      //             //                                         10.0,
                      //             //                                     sigmaY:
                      //             //                                         10.0),
                      //             //                             child:
                      //             //                                 new Container(
                      //             //                               width:
                      //             //                                   screenSize
                      //             //                                       .width,
                      //             //                               height: screenSize
                      //             //                                       .height *
                      //             //                                   0.25,
                      //             //                               decoration: new BoxDecoration(
                      //             //                                   color: Colors
                      //             //                                       .white
                      //             //                                       .withOpacity(
                      //             //                                           0.0)),
                      //             //                             ),
                      //             //                           ),
                      //             //                         ),
                      //             //                   Positioned(
                      //             //                       right: 0,
                      //             //                       bottom: 0,
                      //             //                       child: GestureDetector(
                      //             //                         onTap: () {
                      //             //                           showPhotoAlertDialog(
                      //             //                               context,
                      //             //                               screenSize,
                      //             //                               'Unlock',
                      //             //                               dialogUI(
                      //             //                                   'Unlock Photo',
                      //             //                                   ''),
                      //             //                               170.0,
                      //             //                               onSave: () {
                      //             //                             setState(() {
                      //             //                               sw = 1;
                      //             //                             });
                      //             //                             Navigator.pop(
                      //             //                                 context);
                      //             //                           });
                      //             //                         },
                      //             //                         child: Container(
                      //             //                             margin: EdgeInsets
                      //             //                                 .all(10),
                      //             //                             width: 40,
                      //             //                             height: 40,
                      //             //                             decoration:
                      //             //                                 BoxDecoration(
                      //             //                               color: white,
                      //             //                               borderRadius:
                      //             //                                   BorderRadius
                      //             //                                       .circular(
                      //             //                                           20.00),
                      //             //                             ),
                      //             //                             child: Icon(
                      //             //                                 Icons.lock,
                      //             //                                 color:
                      //             //                                     orangeLinear)),
                      //             //                       )),
                      //             //                 ],
                      //             //               )
                      //             //           ),
                      //             //           SizedBox(height: 5),
                      //             //           Container(
                      //             //             height: screenSize.height * 0.08,
                      //             //             padding: EdgeInsets.all(10),
                      //             //             alignment: Alignment.center,
                      //             //             child: ListView.builder(
                      //             //                 shrinkWrap: true,
                      //             //                 primary: false,
                      //             //                 itemCount: _options.length,
                      //             //                 scrollDirection:
                      //             //                     Axis.horizontal,
                      //             //                 itemBuilder:
                      //             //                     (context, index) {
                      //             //                   return GestureDetector(
                      //             //                       onTap: () {
                      //             //                         setState(() {});
                      //             //                       },
                      //             //                       child: Container(
                      //             //                         padding:
                      //             //                             EdgeInsets.all(5),
                      //             //                         child: Column(
                      //             //                           children: [
                      //             //                             AssetImageWidget(
                      //             //                               image: _options[
                      //             //                                       index]
                      //             //                                   ['icon'],
                      //             //                               color: greenBtn,
                      //             //                             ),
                      //             //                             SizedBox(
                      //             //                               height: 5,
                      //             //                             ),
                      //             //                             Text(
                      //             //                               _options[index]
                      //             //                                   ['title'],
                      //             //                               style:
                      //             //                                   TextStyle(
                      //             //                                 color: black,
                      //             //                                 fontSize: 9,
                      //             //                               ),
                      //             //                             )
                      //             //                           ],
                      //             //                         ),
                      //             //                       ));
                      //             //                 }),
                      //             //           ),
                      //             //           Container(
                      //             //               child: Row(
                      //             //             mainAxisAlignment:
                      //             //                 MainAxisAlignment.spaceEvenly,
                      //             //             children: [
                      //             //               Container(
                      //             //                 padding: EdgeInsets.all(10),
                      //             //                 decoration: BoxDecoration(
                      //             //                   border: Border.all(
                      //             //                       color: greenBtn),
                      //             //                   color: white,
                      //             //                   boxShadow: [
                      //             //                     BoxShadow(
                      //             //                       color: Colors.grey
                      //             //                           .withOpacity(0.3),
                      //             //                       spreadRadius: 2,
                      //             //                       blurRadius: 3,
                      //             //                       offset: Offset(0,
                      //             //                           0), // changes position of shadow
                      //             //                     ),
                      //             //                   ],
                      //             //                   borderRadius:
                      //             //                       BorderRadius.all(
                      //             //                           Radius.circular(
                      //             //                               25.0)),
                      //             //                 ),
                      //             //                 child: new Text(
                      //             //                   'Send Interest',
                      //             //                   style: miniBlackTextStyle,
                      //             //                 ),
                      //             //               ),
                      //             //               Container(
                      //             //                 padding: EdgeInsets.all(10),
                      //             //                 decoration: BoxDecoration(
                      //             //                   color: white,
                      //             //                   border: Border.all(
                      //             //                       color: orangeLinear),
                      //             //                   boxShadow: [
                      //             //                     BoxShadow(
                      //             //                       color: Colors.grey
                      //             //                           .withOpacity(0.3),
                      //             //                       spreadRadius: 2,
                      //             //                       blurRadius: 3,
                      //             //                       offset: Offset(0,
                      //             //                           0), // changes position of shadow
                      //             //                     ),
                      //             //                   ],
                      //             //                   borderRadius:
                      //             //                       BorderRadius.all(
                      //             //                           Radius.circular(
                      //             //                               25.0)),
                      //             //                 ),
                      //             //                 child: new Text(
                      //             //                   'Shortlist',
                      //             //                   style: miniBlackTextStyle,
                      //             //                 ),
                      //             //               ),
                      //             //               Container(
                      //             //                 padding: EdgeInsets.all(10),
                      //             //                 decoration: BoxDecoration(
                      //             //                   border: Border.all(
                      //             //                       color: redBtn),
                      //             //                   color: white,
                      //             //                   boxShadow: [
                      //             //                     BoxShadow(
                      //             //                       color: Colors.grey
                      //             //                           .withOpacity(0.3),
                      //             //                       spreadRadius: 2,
                      //             //                       blurRadius: 3,
                      //             //                       offset: Offset(0,
                      //             //                           0), // changes position of shadow
                      //             //                     ),
                      //             //                   ],
                      //             //                   borderRadius:
                      //             //                       BorderRadius.all(
                      //             //                           Radius.circular(
                      //             //                               25.0)),
                      //             //                 ),
                      //             //                 child: new Text(
                      //             //                   'Ignore',
                      //             //                   style: miniBlackTextStyle,
                      //             //                 ),
                      //             //               )
                      //             //             ],
                      //             //           )),
                      //             //           SizedBox(height: 10),
                      //             //           Row(
                      //             //             mainAxisAlignment:
                      //             //                 MainAxisAlignment.start,
                      //             //             crossAxisAlignment:
                      //             //                 CrossAxisAlignment.start,
                      //             //             children: [
                      //             //               SizedBox(height: 20),
                      //             //               Text(
                      //             //                 _profiles[index]['name'],
                      //             //                 style: headingBBlackStyle,
                      //             //               ),
                      //             //               SizedBox(width: 20),
                      //             //               SizedBox(
                      //             //                 child: Text(
                      //             //                   _profiles[index]['Age'] +
                      //             //                       ' , ' +
                      //             //                       _profiles[index]
                      //             //                           ['Religion'] +
                      //             //                       ' , ' +
                      //             //                       _profiles[index]
                      //             //                           ['Star'] +
                      //             //                       ' , \n' +
                      //             //                       _profiles[index]
                      //             //                           ['Location'] +
                      //             //                       ' , \n' +
                      //             //                       _profiles[index]
                      //             //                           ['Education'] +
                      //             //                       ' , \n' +
                      //             //                       _profiles[index]
                      //             //                           ['Profession'],
                      //             //                   overflow:
                      //             //                       TextOverflow.ellipsis,
                      //             //                 ),
                      //             //               ),
                      //             //               SizedBox(height: 20),
                      //             //             ],
                      //             //           )
                      //             //         ],
                      //             //       ),
                      //             //     ),
                      //                 // GestureDetector(
                      //                 //   onTap: () {
                      //                 //     changeScreen(
                      //                 //         context,
                      //                 //         MatchProfile(
                      //                 //           profile: _profiles[index],
                      //                 //         ));
                      //                 //   },
                      //                 //   child: ListView(
                      //                 //     shrinkWrap: true,
                      //                 //     primary: false,
                      //                 //     children: [
                      //                 //       Container(
                      //                 //           //  padding: EdgeInsets.all(20),
                      //                 //           width: screenSize.width,
                      //                 //           decoration: BoxDecoration(
                      //                 //             boxShadow: [
                      //                 //               BoxShadow(
                      //                 //                 color: Colors.grey
                      //                 //                     .withOpacity(0.1),
                      //                 //                 spreadRadius: 2,
                      //                 //                 blurRadius: 3,
                      //                 //                 offset: Offset(0,
                      //                 //                     0), // changes position of shadow
                      //                 //               ),
                      //                 //             ],
                      //                 //             color: backGroundColor,
                      //                 //             border: Border.all(
                      //                 //               width: 2.00,
                      //                 //               color: backGroundColor,
                      //                 //             ),
                      //                 //             borderRadius:
                      //                 //                 BorderRadius.circular(
                      //                 //                     20.00),
                      //                 //           ),
                      //                 //           child: Stack(
                      //                 //             children: [
                      //                 //               //   SizedBox(height: 10),
                      //                 //               Container(
                      //                 //                 alignment:
                      //                 //                     Alignment.center,
                      //                 //                 //
                      //                 //                 child: ImageWidget(
                      //                 //                     width:
                      //                 //                         screenSize.width,
                      //                 //                     height: screenSize
                      //                 //                             .height *
                      //                 //                         0.15,
                      //                 //                     image:
                      //                 //                         _profiles[index]
                      //                 //                             ['photoUrl']),
                      //                 //               ),
                      //                 //             ],
                      //                 //           )),
                      //                 //       SizedBox(height: 5),
                      //                 //       Container(
                      //                 //         height: screenSize.height * 0.08,
                      //                 //         padding: EdgeInsets.all(10),
                      //                 //         alignment: Alignment.center,
                      //                 //         child: ListView.builder(
                      //                 //             shrinkWrap: true,
                      //                 //             primary: false,
                      //                 //             itemCount: _options.length,
                      //                 //             scrollDirection:
                      //                 //                 Axis.horizontal,
                      //                 //             itemBuilder:
                      //                 //                 (context, index) {
                      //                 //               return GestureDetector(
                      //                 //                   onTap: () {
                      //                 //                     setState(() {});
                      //                 //                   },
                      //                 //                   child: Container(
                      //                 //                     padding:
                      //                 //                         EdgeInsets.all(5),
                      //                 //                     child: Column(
                      //                 //                       children: [
                      //                 //                         AssetImageWidget(
                      //                 //                           image: _options[
                      //                 //                                   index]
                      //                 //                               ['icon'],
                      //                 //                           color: greenBtn,
                      //                 //                         ),
                      //                 //                         SizedBox(
                      //                 //                           height: 5,
                      //                 //                         ),
                      //                 //                         Text(
                      //                 //                           _options[index]
                      //                 //                               ['title'],
                      //                 //                           style:
                      //                 //                               TextStyle(
                      //                 //                             color: black,
                      //                 //                             fontSize: 9,
                      //                 //                           ),
                      //                 //                         )
                      //                 //                       ],
                      //                 //                     ),
                      //                 //                   ));
                      //                 //             }),
                      //                 //       ),
                      //                 //       Container(
                      //                 //           child: Row(
                      //                 //         mainAxisAlignment:
                      //                 //             MainAxisAlignment.spaceEvenly,
                      //                 //         children: [
                      //                 //           Container(
                      //                 //             padding: EdgeInsets.all(10),
                      //                 //             decoration: BoxDecoration(
                      //                 //               border: Border.all(
                      //                 //                   color: greenBtn),
                      //                 //               color: white,
                      //                 //               boxShadow: [
                      //                 //                 BoxShadow(
                      //                 //                   color: Colors.grey
                      //                 //                       .withOpacity(0.3),
                      //                 //                   spreadRadius: 2,
                      //                 //                   blurRadius: 3,
                      //                 //                   offset: Offset(0,
                      //                 //                       0), // changes position of shadow
                      //                 //                 ),
                      //                 //               ],
                      //                 //               borderRadius:
                      //                 //                   BorderRadius.all(
                      //                 //                       Radius.circular(
                      //                 //                           25.0)),
                      //                 //             ),
                      //                 //             child: new Text(
                      //                 //               'Send Interest',
                      //                 //               style: miniBlackTextStyle,
                      //                 //             ),
                      //                 //           ),
                      //                 //           Container(
                      //                 //             padding: EdgeInsets.all(10),
                      //                 //             decoration: BoxDecoration(
                      //                 //               color: white,
                      //                 //               border: Border.all(
                      //                 //                   color: orangeLinear),
                      //                 //               boxShadow: [
                      //                 //                 BoxShadow(
                      //                 //                   color: Colors.grey
                      //                 //                       .withOpacity(0.3),
                      //                 //                   spreadRadius: 2,
                      //                 //                   blurRadius: 3,
                      //                 //                   offset: Offset(0,
                      //                 //                       0), // changes position of shadow
                      //                 //                 ),
                      //                 //               ],
                      //                 //               borderRadius:
                      //                 //                   BorderRadius.all(
                      //                 //                       Radius.circular(
                      //                 //                           25.0)),
                      //                 //             ),
                      //                 //             child: new Text(
                      //                 //               'Shortlist',
                      //                 //               style: miniBlackTextStyle,
                      //                 //             ),
                      //                 //           ),
                      //                 //           Container(
                      //                 //             padding: EdgeInsets.all(10),
                      //                 //             decoration: BoxDecoration(
                      //                 //               border: Border.all(
                      //                 //                   color: redBtn),
                      //                 //               color: white,
                      //                 //               boxShadow: [
                      //                 //                 BoxShadow(
                      //                 //                   color: Colors.grey
                      //                 //                       .withOpacity(0.3),
                      //                 //                   spreadRadius: 2,
                      //                 //                   blurRadius: 3,
                      //                 //                   offset: Offset(0,
                      //                 //                       0), // changes position of shadow
                      //                 //                 ),
                      //                 //               ],
                      //                 //               borderRadius:
                      //                 //                   BorderRadius.all(
                      //                 //                       Radius.circular(
                      //                 //                           25.0)),
                      //                 //             ),
                      //                 //             child: new Text(
                      //                 //               'Ignore',
                      //                 //               style: miniBlackTextStyle,
                      //                 //             ),
                      //                 //           )
                      //                 //         ],
                      //                 //       )),
                      //                 //       SizedBox(height: 10),
                      //                 //       Row(
                      //                 //         mainAxisAlignment:
                      //                 //             MainAxisAlignment.start,
                      //                 //         crossAxisAlignment:
                      //                 //             CrossAxisAlignment.start,
                      //                 //         children: [
                      //                 //           SizedBox(height: 20),
                      //                 //           Text(
                      //                 //             _profiles[index]['name'],
                      //                 //             style: headingBBlackStyle,
                      //                 //           ),
                      //                 //           SizedBox(width: 20),
                      //                 //           SizedBox(
                      //                 //             child: Text(
                      //                 //               _profiles[index]['Age'] +
                      //                 //                   ' , ' +
                      //                 //                   _profiles[index]
                      //                 //                       ['Religion'] +
                      //                 //                   ' , ' +
                      //                 //                   _profiles[index]
                      //                 //                       ['Star'] +
                      //                 //                   ' , \n' +
                      //                 //                   _profiles[index]
                      //                 //                       ['Location'] +
                      //                 //                   ' , \n' +
                      //                 //                   _profiles[index]
                      //                 //                       ['Education'] +
                      //                 //                   ' , \n' +
                      //                 //                   _profiles[index]
                      //                 //                       ['Profession'],
                      //                 //               overflow:
                      //                 //                   TextOverflow.ellipsis,
                      //                 //             ),
                      //                 //           ),
                      //                 //           SizedBox(height: 20),
                      //                 //         ],
                      //                 //       )
                      //                 //     ],
                      //                 //   ),
                      //                 // )
                      //             //   ],
                      //             // );
                      //           },
                      //           // viewportFraction: 1,
                      //           // scale: 0.6,
                      //           index: _index,
                      //           onIndexChanged: (index) {
                      //             setState(() {
                      //               _index = index;
                      //             });
                      //           },
                      //           pagination: new SwiperPagination(
                      //             margin: new EdgeInsets.only(top: 100.0),
                      //             alignment: Alignment.bottomCenter,
                      //             builder: new DotSwiperPaginationBuilder(
                      //                 color: grey, activeColor: appColor),
                      //           ),
                      //         ),
                      //       ),
                    ],
                  )),
            ),
          ],
        ),
      ),
    ));
  }

  Widget dialogUI(String userId, String userName) {
    return new Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: <Widget>[
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              '$userId ',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            Container(
              child: InkWell(
                child: Icon(
                  Icons.close,
                  color: black,
                ),
                onTap: () {
                  Navigator.of(context).pop();
                },
              ),
            )
          ],
        ),
        SizedBox(
          height: 10,
        ),
        Text(
          'Enter Password',
          style: TextStyle(
            fontSize: 16,
          ),
        ),
        Container(
            height: 50,
            child: TextField(
              decoration: new InputDecoration(
                fillColor: appColor,
                border: new OutlineInputBorder(
                    borderSide: new BorderSide(color: Colors.black)),
              ),
            )),
        SizedBox(
          height: 10,
        ),
      ],
    );
  }
}
