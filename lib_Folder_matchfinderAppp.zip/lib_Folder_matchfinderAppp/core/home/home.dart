import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_picker_gallery_camera/image_picker_gallery_camera.dart';
import 'package:matchfinder/const/const.dart';
import 'package:matchfinder/const/general_methods.dart';
import 'package:matchfinder/core/home/partnerPreferences.dart';
import 'package:matchfinder/core/home/viewPhoto.dart';
import 'package:matchfinder/core/settings/accountSettings.dart';
import 'package:matchfinder/core/settings/addPhoto.dart';
import 'package:matchfinder/core/settings/manage_alerts.dart';
import 'package:matchfinder/utils/appBar.dart';
import 'package:matchfinder/utils/function.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'bottom_bar.dart';
import 'editProfile.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  var percent = 0;

  var hasEducation = false;
  var hasFamilyDetail = false;
  var hasFavourite = false;
  var hasPersonalDetails = false;
  var hasPhoto = false;
  var hasPartner = false;

  bool isLoading = true;

  var photoUrl = "";
  File image = null;

  getData() async {
    try {
      var value = getSession();
      final prefs = await SharedPreferences.getInstance();
      // print(value);
      if (value != null) {
        Response response = await getProfileData();
        if (await response.data != null) {
          print(response.data);
          var data = response.data;
          percent = data['percent'];
          photoUrl = data['photoURL'];
          prefs.setString('userImage', photoUrl);
          hasEducation = (data['procomp']['education'] == 'N' || data['procomp']['education'] == null) ? false : true;
          hasFamilyDetail = (data['procomp']['family_detail'] == 'N' || data['procomp']['family_detail'] == null) ? false : true;
          hasFavourite = (data['procomp']['favorite'] == 'N' || data['procomp']['favorite'] == null) ? false : true;
          hasPersonalDetails = (data['procomp']['personal_detail'] == 'N' || data['procomp']['personal_detail'] == null) ? false : true;
          hasPhoto = (data['procomp']['photo'] == 'N' || data['procomp']['photo'] == null) ? false : true;
          hasPartner = (data['procomp']['user_fld1'] == 'N' || data['procomp']['user_fld1'] == null) ? false : true;
          isLoading = false;
          setState(() {});
        }
      } else {
        print('No cache value');
        Navigator.pop(context);
      }
    } catch (e) {
      print(e);
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    getData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var screenSize = MediaQuery.of(context).size;

    return Scaffold(
        appBar: AppBarWidget(heading: 'Profile'),
        body: ListView(
          padding: EdgeInsets.all(25),
          children: [
            Container(
                margin: EdgeInsets.only(top: 10, bottom: 10),
                padding: EdgeInsets.all(15),
                height: 250,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.5),
                      blurRadius: 12,
                      offset: Offset(0, 3),
                    ),
                  ],
                  color: Color(0xffFFFFFF),
                  border: Border.all(
                    width: 2.00,
                    color: Color(0xffFFFFFF),
                  ),
                  borderRadius: BorderRadius.circular(10.00),
                ),
                child: isLoading
                    ? CircularProgressIndicator() : Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      width: screenSize.width * 0.35,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Stack(
                            children: [
                              InkWell(
                                child: Container(
                                  height: 153.75,
                                  width: 206.25,
                                  decoration: BoxDecoration(
                                      image: DecorationImage(
                                          image: NetworkImage(photoUrl),
                                          // image: AssetImage('assets/220220_3.jpg'),
                                          fit: BoxFit.fill)),
                                ),
                                onTap: () {
                                  changeScreen(context, AddPhoto());
                                },
                              ),
                              Positioned(
                                  right: -10,
                                  bottom: -10,
                                  child: IconButton(
                                    icon: Icon(
                                      Icons.camera_alt,
                                      color: Color(0xFFFCA020),
                                      size: 30,
                                    ),
                                    onPressed: () {
                                      changeScreen(context, AddPhoto());
                                    },
                                  ))
                            ],
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          GestureDetector(
                            onTap: () {
                              changeScreenReplacement(
                                  context, BottomBar(index: 3));
                            },
                            child: Container(
                                height: 50,
                                alignment: Alignment.center,
                                decoration: BoxDecoration(
                                  color: Color(0xFFFCA020),
                                  borderRadius: BorderRadius.circular(5.00),
                                ),
                                child: Text(
                                  'Upgrade Plan',
                                  style: TextStyle(
                                    fontFamily: 'Arial',
                                    fontSize: 14,
                                    color: const Color(0xffffffff),
                                    fontWeight: FontWeight.w700,
                                  ),
                                  textAlign: TextAlign.center,
                                )),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      width: screenSize.width * 0.4,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Your Profile',
                            style: TextStyle(
                                fontSize: 20,
                                fontFamily: 'Arial',
                                fontWeight: FontWeight.w700),
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Container(
                            height: 15,
                            decoration: BoxDecoration(
                              border: Border.all(
                                width: 2.00,
                                color: Color(0xFF2AC3E3),
                              ),
                              borderRadius: BorderRadius.circular(5.00),
                            ),
                            child: LinearProgressIndicator(
                              // minHeight: 8,
                              backgroundColor: Colors.white,
                              valueColor: new AlwaysStoppedAnimation<Color>(
                                  Color(0xFF2AC3E3)),
                              value: percent / 100,
                            ),
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Text(
                            percent.toString() + '% Complete',
                            style: TextStyle(
                              fontFamily: 'Arial',
                              fontSize: 16,
                              color: const Color(0xff040404),
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Row(
                            children: [
                              hasEducation
                                  ? Icon(
                                      Icons.check,
                                      color: appColor,
                                      size: 20,
                                    )
                                  : Icon(
                                      Icons.edit_outlined,
                                      color: appColor,
                                      size: 20,
                                    ),
                              SizedBox(
                                width: 10,
                              ),
                              Text(
                                'Education',
                                style: hasEducation
                                    ? TextStyle(
                                        fontFamily: 'Arial',
                                        fontSize: 16,
                                        color: const Color(0xff040404),
                                        fontWeight: FontWeight.w700,
                                      )
                                    : TextStyle(
                                        fontFamily: 'Arial',
                                        fontSize: 16,
                                        color: const Color(0xff236b8e),
                                        fontWeight: FontWeight.w700,
                                        decoration: TextDecoration.underline,
                                      ),
                              )
                            ],
                          ),
                          Row(
                            children: [
                              hasFamilyDetail
                                  ? Icon(
                                      Icons.check,
                                      color: appColor,
                                      size: 20,
                                    )
                                  : Icon(
                                      Icons.edit_outlined,
                                      color: appColor,
                                      size: 20,
                                    ),
                              SizedBox(
                                width: 10,
                              ),
                              Text(
                                'Family Details',
                                style: hasFamilyDetail
                                    ? TextStyle(
                                        fontFamily: 'Arial',
                                        fontSize: 16,
                                        color: const Color(0xff040404),
                                        fontWeight: FontWeight.w700,
                                      )
                                    : TextStyle(
                                        fontFamily: 'Arial',
                                        fontSize: 16,
                                        color: const Color(0xff236b8e),
                                        fontWeight: FontWeight.w700,
                                        decoration: TextDecoration.underline,
                                      ),
                              )
                            ],
                          ),
                          Row(
                            children: [
                              hasFavourite
                                  ? Icon(
                                      Icons.check,
                                      color: appColor,
                                      size: 20,
                                    )
                                  : Icon(
                                      Icons.edit_outlined,
                                      color: appColor,
                                      size: 20,
                                    ),
                              SizedBox(
                                width: 10,
                              ),
                              Text(
                                'Favourites',
                                style: hasFavourite
                                    ? TextStyle(
                                        fontFamily: 'Arial',
                                        fontSize: 16,
                                        color: const Color(0xff040404),
                                        fontWeight: FontWeight.w700,
                                      )
                                    : TextStyle(
                                        fontFamily: 'Arial',
                                        fontSize: 16,
                                        color: const Color(0xff236b8e),
                                        fontWeight: FontWeight.w700,
                                        decoration: TextDecoration.underline,
                                      ),
                              )
                            ],
                          ),
                          Row(
                            children: [
                              hasPhoto
                                  ? Icon(
                                      Icons.check,
                                      color: appColor,
                                      size: 20,
                                    )
                                  : Icon(
                                      Icons.edit_outlined,
                                      color: appColor,
                                      size: 20,
                                    ),
                              SizedBox(
                                width: 10,
                              ),
                              Text(
                                'Photo',
                                style: hasPhoto
                                    ? TextStyle(
                                        fontFamily: 'Arial',
                                        fontSize: 16,
                                        color: const Color(0xff040404),
                                        fontWeight: FontWeight.w700,
                                      )
                                    : TextStyle(
                                        fontFamily: 'Arial',
                                        fontSize: 16,
                                        color: const Color(0xff236b8e),
                                        fontWeight: FontWeight.w700,
                                        decoration: TextDecoration.underline,
                                      ),
                              )
                            ],
                          ),
                          Row(
                            children: [
                              hasPersonalDetails
                                  ? Icon(
                                      Icons.check,
                                      color: appColor,
                                      size: 20,
                                    )
                                  : Icon(
                                      Icons.edit_outlined,
                                      color: appColor,
                                      size: 20,
                                    ),
                              SizedBox(
                                width: 10,
                              ),
                              Text(
                                'Personal Details',
                                style: hasPersonalDetails
                                    ? TextStyle(
                                        fontFamily: 'Arial',
                                        fontSize: 16,
                                        color: const Color(0xff040404),
                                        fontWeight: FontWeight.w700,
                                      )
                                    : TextStyle(
                                        fontFamily: 'Arial',
                                        fontSize: 16,
                                        color: const Color(0xff236b8e),
                                        fontWeight: FontWeight.w700,
                                        decoration: TextDecoration.underline,
                                      ),
                              )
                            ],
                          ),
                          Row(
                            children: [
                              hasPartner
                                  ? Icon(
                                      Icons.check,
                                      color: appColor,
                                      size: 20,
                                    )
                                  : Icon(
                                      Icons.edit_outlined,
                                      color: appColor,
                                      size: 20,
                                    ),
                              SizedBox(
                                width: 10,
                              ),
                              GestureDetector(
                                onTap: () {
                                  changeScreen(context, PartnerPreferences());
                                },
                                child: Text(
                                  'Preferences',
                                  style: hasPartner
                                      ? TextStyle(
                                          fontFamily: 'Arial',
                                          fontSize: 16,
                                          color: const Color(0xff040404),
                                          fontWeight: FontWeight.w700,
                                        )
                                      : TextStyle(
                                          fontFamily: 'Arial',
                                          fontSize: 16,
                                          color: const Color(0xff236b8e),
                                          fontWeight: FontWeight.w700,
                                          decoration: TextDecoration.underline,
                                        ),
                                ),
                              )
                            ],
                          )
                        ],
                      ),
                    )
                  ],
                )),
            Container(
              margin: EdgeInsets.only(top: 10, bottom: 10),
              height: 70,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    blurRadius: 12,
                    offset: Offset(0, 3),
                  ),
                ],
                color: Color(0xffFFFFFF),
                border: Border.all(
                  width: 2.00,
                  color: Color(0xffFFFFFF),
                ),
                borderRadius: BorderRadius.circular(10.00),
              ),
              child: ListTile(
                onTap: () {
                  changeScreen(context, EditProfileView());
                },
                leading: Image.asset(
                  'assets/icon/pencil.png',
                  width: 24,
                  color: appColor,
                ),
                title: Text('Edit Profile'),
                trailing: Icon(
                  Icons.keyboard_arrow_right,
                  size: 30,
                ),
              ),
            ),
            Container(
              height: 70,
              margin: EdgeInsets.only(top: 10, bottom: 10),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    blurRadius: 12,
                    offset: Offset(0, 3),
                  ),
                ],
                color: Color(0xffFFFFFF),
                border: Border.all(
                  width: 2.00,
                  color: Color(0xffFFFFFF),
                ),
                borderRadius: BorderRadius.circular(10.00),
              ),
              child: ListTile(
                onTap: () {
                  changeScreen(context, AddPhoto());
                },
                leading: Icon(
                  Icons.image,
                  color: Color(0xFF236B8E),
                ),
                title: Text('Add Photo'),
                trailing: Icon(
                  Icons.keyboard_arrow_right,
                  size: 30,
                ),
              ),
            ),
            Container(
              height: 70,
              margin: EdgeInsets.only(top: 10, bottom: 10),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    blurRadius: 12,
                    offset: Offset(0, 3),
                  ),
                ],
                color: Color(0xffFFFFFF),
                border: Border.all(
                  width: 2.00,
                  color: Color(0xffFFFFFF),
                ),
                borderRadius: BorderRadius.circular(10.00),
              ),
              child: ListTile(
                onTap: () {
                  changeScreen(context, PartnerPreferences());
                },
                leading: Icon(
                  Icons.group_sharp,
                  color: Color(0xFF236B8E),
                ),
                title: Text('Partner Preferences'),
                trailing: Icon(
                  Icons.keyboard_arrow_right,
                  size: 30,
                ),
              ),
            ),
            Container(
              height: 70,
              margin: EdgeInsets.only(top: 10, bottom: 10),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    blurRadius: 12,
                    offset: Offset(0, 3),
                  ),
                ],
                color: Color(0xffFFFFFF),
                border: Border.all(
                  width: 2.00,
                  color: Color(0xffFFFFFF),
                ),
                borderRadius: BorderRadius.circular(10.00),
              ),
              child: ListTile(
                onTap: () {
                  changeScreen(context, ManageAlerts());
                },
                leading: Icon(
                  Icons.notifications_active,
                  color: appColor,
                ),
                title: Text('Manage Alerts'),
                trailing: Icon(
                  Icons.keyboard_arrow_right,
                  size: 30,
                ),
              ),
            ),
            Container(
              height: 70,
              margin: EdgeInsets.only(top: 10, bottom: 10),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    blurRadius: 12,
                    offset: Offset(0, 3),
                  ),
                ],
                color: Color(0xffFFFFFF),
                border: Border.all(
                  width: 2.00,
                  color: Color(0xffFFFFFF),
                ),
                borderRadius: BorderRadius.circular(10.00),
              ),
              child: ListTile(
                onTap: () {
                  changeScreen(context, AccountSettings());
                },
                leading: Icon(
                  Icons.settings,
                  color: appColor,
                ),
                title: Text('Account Settings'),
                trailing: Icon(
                  Icons.keyboard_arrow_right,
                  size: 30,
                ),
              ),
            ),
            Container(
              height: 70,
              margin: EdgeInsets.only(top: 10, bottom: 10),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    blurRadius: 12,
                    offset: Offset(0, 3),
                  ),
                ],
                color: Color(0xffFFFFFF),
                border: Border.all(
                  width: 2.00,
                  color: Color(0xffFFFFFF),
                ),
                borderRadius: BorderRadius.circular(10.00),
              ),
              child: ListTile(
                onTap: () {
                  //   changeScreen(context, AccountSettings());
                },
                leading: Image.asset(
                  'assets/icon/horoscope.png',
                  width: 24,
                  color: appColor,
                ),
                title: Text('Generate Horoscope'),
                trailing: Icon(
                  Icons.keyboard_arrow_right,
                  size: 30,
                ),
              ),
            )
          ],
        ));
  }

  Future selectCamera() async {
    File image = await imagePicker(context, ImgSource.Camera);
    if (image != null) {
      //   File cropped = await cropImage(image);
      setState(() {
        Navigator.pop(context);
        this.image = image;
      });
    } else {}
  }

  Future selectGallery() async {
    File image = await imagePicker(context, ImgSource.Gallery);
    if (image != null) {
      //   File cropped = await cropImage(image);
      setState(() {
        Navigator.pop(context);
        this.image = image;
      });
    } else {}
  }
}
