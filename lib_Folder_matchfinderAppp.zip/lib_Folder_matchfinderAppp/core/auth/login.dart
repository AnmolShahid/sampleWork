import 'package:country_list_pick/country_list_pick.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:matchfinder/const/general_methods.dart';
import 'package:matchfinder/core/auth/register.dart';
import 'package:matchfinder/core/auth/verify_otp_view.dart';
import 'package:matchfinder/core/home/bottom_bar.dart';
import 'package:matchfinder/core/payment/upgradePayment.dart';
import 'package:matchfinder/const/const.dart';
import 'package:matchfinder/utils/function.dart';
import 'package:matchfinder/utils/style.dart';
import 'package:matchfinder/widgets/text_field.dart';

import 'accountNotAccess.dart';

class Login extends StatefulWidget {
  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final _formKey = GlobalKey<FormState>();
  final _key = GlobalKey<ScaffoldState>();
  TextEditingController email = TextEditingController();
  TextEditingController password = TextEditingController();
  bool isLoading = false;

  @override
  void dispose() {
    email.dispose();
    password.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    email.text = 'test_india';
    password.text = '123456';
  }

  @override
  Widget build(BuildContext context) {

    Size screenSize = MediaQuery.of(context).size;

    return Scaffold(
      key: _key,
      backgroundColor: Colors.white,
      // appBar: AppBar(
      //   shadowColor: appColor,
      //   backgroundColor: appColor,
      //   automaticallyImplyLeading: false,
      //   centerTitle: true,
      //   title: Image.asset(
      //     'assets/logowhite.png',
      //     // width: 142,
      //     height: 50,
      //   ),
      //   leading: IconButton(
      //     icon: Icon(
      //       Icons.arrow_back,
      //       color: white,
      //     ),
      //     onPressed: () {
      //       Navigator.pop(context);
      //     },
      //   ),
      // ),
      body: SafeArea(
        child: Container(
            margin: EdgeInsets.symmetric(
              horizontal: 33,
              vertical: 30
            ),
            child: GestureDetector(
              onTap: (){
                FocusScope.of(context).requestFocus(new FocusNode());
              },
              child: Center(
              child: isLoading
                  ? CircularProgressIndicator()
                  : Form(
                      key: _formKey,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          // Spacer(),
                          SizedBox(
                            height: 0,
                          ),
                          Text(
                            'Login Here',
                            style: headingGreyTextStyle,
                          ),
                          // Spacer(),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                width: screenSize.width * 0.2,
                                child: Column(
                                  children: [
                                    Theme(
                                      data: ThemeData.light().copyWith(
                                          colorScheme: ColorScheme.light(
                                            primary: Colors.black,
                                          )
                                      ),
                                      child: CountryListPick(
                                          theme: CountryTheme(
                                            isShowFlag: true,
                                            isShowTitle: false,
                                            isShowCode: true,
                                            isDownIcon: false,
                                          ),
                                          initialSelection: 'IN',
                                          onChanged: (CountryCode code) {
                                            print(code.code);
                                          },
                                      ),
                                    ),
                                    Container(
                                      width: screenSize.width * 0.18,
                                        height: 4,
                                        color: greyColor,
                                        // padding: EdgeInsets.only(left: 10, right: 10),
                                    )
                                        // child: Divider(color: greyColor, thickness: 3,)),
                                  ],
                                ),
                              ),
                              Container(
                                width: screenSize.width * 0.65,
                                child: TextFormField(
                                  controller: email,
                                  style: TextStyle(
                                    fontWeight: FontWeight.w500,
                                    color: black,
                                    fontSize: 16,
                                  ),
                                  keyboardType: TextInputType.emailAddress,
                                  validator: (value) {
                                    if (value.isEmpty) {
                                      return 'Email field is Empty';
                                    }
                                    return null;
                                  },
                                  decoration: InputDecoration(
                                    hoverColor: Colors.white,
                                    // labelText: '10 Digit Mobile or Email',
                                    labelStyle: TextStyle(color: Colors.black),
                                    contentPadding: EdgeInsets.zero,
                                    errorStyle: TextStyle(
                                      backgroundColor: transparent,
                                    ),
                                    // errorBorder: UnderlineInputBorder(
                                    //   borderSide: BorderSide(color: red),
                                    // ),
                                    enabledBorder: UnderlineInputBorder(
                                      borderSide: BorderSide(color: greyColor, width: 4),
                                    ),
                                    focusedBorder: UnderlineInputBorder(
                                      borderSide: BorderSide(color: appColor, width: 4),
                                    ),
                                    border: UnderlineInputBorder(
                                      borderSide: BorderSide(color: greyColor, width: 4),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          // TextFieldCustom(
                          //   controller: password,
                          //   style: miniGreyTextStyle,
                          //   labelText: 'Password',
                          //   obscureText: true,
                          //   maxLines: 1,
                          //   inputType: TextInputType.text,
                          //   validator: (value) {
                          //     if (value.isEmpty) {
                          //       return 'Password field is Empty';
                          //     }
                          //     return null;
                          //   },
                          // ),
                          // SizedBox(
                          //   height: 33,
                          // ),
                          // InkWell(
                          //   onTap: () {
                          //     changeScreen(context, AccountNotAccess());
                          //   },
                          //   child: Row(
                          //     children: [
                          //       Expanded(
                          //         child: Text(
                          //           "I can't access my account",
                          //           textAlign: TextAlign.end,
                          //           style: miniAppColorUnderLineStyle,
                          //         ),
                          //       ),
                          //     ],
                          //   ),
                          // ),
                          // SizedBox(
                          //   height: 33,
                          // ),
                          MaterialButton(
                            onPressed: () async {
                              if (_formKey.currentState.validate()) {
                                changeScreen(context, VerifyOtpView(email.text, password.text));
                                // setState(() {
                                //   isLoading = true;
                                // });
                                // Response response = await login(
                                //     email.text.trim(), password.text.trim());
                                // setState(() {
                                //   isLoading = false;
                                // });
                                // if (response.data['reqstatus'] == 'success') {
                                //   _key.currentState
                                //       .showSnackBar(
                                //         snackBar(
                                //           'Login Successfully',
                                //           Colors.green,
                                //           Icons.verified_user,
                                //         ),
                                //       )
                                //       .closed
                                //       .then(
                                //           (value) => changeScreenReplacement(context, BottomBar()));
                                // } else {
                                //   _key.currentState.showSnackBar(
                                //     snackBar(
                                //       response.data['validationerrors'],
                                //       Colors.red,
                                //       Icons.security,
                                //     ),
                                //   );
                                // }
                              }
                            },
                            color: appColor,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(23.0),
                            ),
                            child: Container(
                              padding: EdgeInsets.symmetric(
                                vertical: 14,
                                horizontal: 69,
                              ),
                              child: Text(
                                'Get OTP',
                                textAlign: TextAlign.center,
                                style: smallWhiteTextStyle,
                              ),
                            ),
                          ),
                          // Spacer(),
                          InkWell(
                            onTap: () {
                              changeScreenReplacement(context, Register());
                            },
                            child: Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    "Don't have an account? Sign Up Free",
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
            ),
          ),
        ),
      ),
    );
  }
}
