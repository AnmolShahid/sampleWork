// import 'dart:async';
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
// import 'package:matchfinder/const/general_methods.dart';
// import 'package:matchfinder/core/auth/verify_otp_view.dart';
//
// class MobileNumberView extends StatefulWidget {
//   @override
//   _MobileNumberView createState() => _MobileNumberView();
// }
//
// class _MobileNumberView extends State<MobileNumberView> {
//   TextEditingController mobileNumberController = new TextEditingController();
//   final _key = GlobalKey<ScaffoldState>();
//   bool _isLoading = false;
//   bool status = false;
//
//   Future<void> verifyPhone() async {
//     // final PhoneCodeSent smsOTPSent = (String verId, [int forceCodeResend]) {
//       setState(() {
//         _isLoading = false;
//       });
//       Navigator.push(
//           context,
//           MaterialPageRoute(
//               builder: (context) => VerifyOtpView()));
//     // };
//   }
//
//   handleError(PlatformException error) {
//     setState(() {
//       _isLoading = false;
//     });
//     switch (error.code) {
//       case 'ERROR_INVALID_VERIFICATION_CODE':
//         FocusScope.of(context).requestFocus(new FocusNode());
//         _key.currentState.showSnackBar(
//           snackBar(
//             'Code does not match',
//             Colors.red,
//             Icons.security,
//           ),
//         );
//         break;
//       default:
//         _key.currentState.showSnackBar(
//           snackBar(
//             error.message,
//             Colors.red,
//             Icons.security,
//           ),
//         );
//         break;
//     }
//   }
//
//   @override
//   void initState() {
//     // TODO: implement initState
//     super.initState();
//   }
//
//   @override
//   void dispose() {
//     // TODO: implement dispose
//     mobileNumberController.dispose();
//     super.dispose();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     final _screenSize = MediaQuery.of(context).size;
//
//     final userNumber = TextFormField(
//       controller: mobileNumberController,
//       textAlignVertical: TextAlignVertical.center,
//       inputFormatters: [
//         MaskTextInputFormatter(
//             mask: '## ### ## ##', filter: {"#": RegExp(r'[0-9]')})
//       ],
//       style: TextStyle(
//         color: kDarkColor,
//         fontSize: 16,
//       ),
//       keyboardType: TextInputType.phone,
//       //validator: model.validationService.phoneValidator,
//       decoration: new InputDecoration(
//         hintText: 'Phone',
//         hintStyle: Theme.of(context).textTheme.body1.merge(
//               TextStyle(color: kDarkColor),
//             ),
//         enabledBorder: UnderlineInputBorder(
//           borderSide: BorderSide(
//             color: kGreyColor,
//           ),
//         ),
//         focusedBorder: UnderlineInputBorder(
//           borderSide: BorderSide(color: kMainColor),
//         ),
//         prefixIcon: Row(
//           mainAxisSize: MainAxisSize.min,
//           crossAxisAlignment: CrossAxisAlignment.center,
//           children: [
//             SizedBox(width: 12),
//             Icon(
//               Icons.phone_iphone,
//               color: kMainColor,
//             ),
//             SizedBox(width: 4),
//             Text(
//               dialingCode,
//               style: Theme.of(context).textTheme.bodyText1.copyWith(
//                     color: kMainColor,
//                     fontSize: 16,
//                     fontWeight: FontWeight.bold,
//                   ),
//             ),
//             SizedBox(width: 4),
//           ],
//         ),
//       ),
//     );
//
//     final body = SafeArea(
//       child: Container(
//         child: ListView(
//           children: [
//             SizedBox(
//               height: MediaQuery.of(context).size.height / 8,
//             ),
//             Center(
//               child: Text(
//                 "Enter Phone Number",
//                 textAlign: TextAlign.center,
//                 style: TextStyle(
//                   fontWeight: FontWeight.w600,
//                   fontFamily: "Helvetica",
//                   fontSize: 22,
//                   color: Colors.black,
//                 ),
//               ),
//             ),
//             SizedBox(
//               height: 10,
//             ),
//             Center(
//               child: Text(
//                 "Enter your mobile number we will sent\nyou OTP to verify",
//                 textAlign: TextAlign.center,
//                 style: TextStyle(
//                   fontFamily: "Helvetica",
//                   fontSize: 16,
//                   color: Color(0xffaaaaaa),
//                 ),
//               ),
//             ),
//             SizedBox(
//               height: MediaQuery.of(context).size.height / 15,
//             ),
//             Container(
//               width: MediaQuery.of(context).size.width / 2,
//               height: 50,
//               margin: EdgeInsets.only(left: 35.0, right: 35.0),
//               child: userNumber,
//             ),
//             SizedBox(
//               height: MediaQuery.of(context).size.height / 25,
//             ),
//             _isLoading
//                 ? Loader()
//                 : Padding(
//                     padding: const EdgeInsets.symmetric(horizontal: 25),
//                     child: Button(
//                       onTap: () async {
//                         if (mobileNumberController.text == "") {
//                           return;
//                         }
//                         setState(() {
//                           _isLoading = true;
//                         });
//                         mobileNumberController.text = mobileNumberController.text.replaceAll(" ", "");
//                         verifyPhone();
//                         // mobileNumberController.text = dialingCode + mobileNumberController.text;
//                         // mobileNumberController.text = '+923313675244';
//                         // Navigator.push(
//                         //     context,
//                         //     MaterialPageRoute(
//                         //         builder: (context) =>
//                         //             AddPersonalDetails(widget.name, widget.email, dialingCode + mobileNumberController.text, widget.password, widget.isGmail)));
//                       },
//                       height: 0.063,
//                       buttonText: 'Verify OTP',
//                     ),
//                   ),
//           ],
//         ),
//       ),
//     );
//
//     return Scaffold(
//       backgroundColor: kBackgroundColor,
//       body: body,
//     );
//   }
// }
