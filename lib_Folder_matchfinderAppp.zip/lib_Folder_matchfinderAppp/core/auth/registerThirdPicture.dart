import 'dart:io';

import 'package:cookie_jar/cookie_jar.dart';
import 'package:dio/dio.dart';
import 'package:dio_cookie_manager/dio_cookie_manager.dart';
import 'package:flutter/material.dart';
import 'package:image_picker_gallery_camera/image_picker_gallery_camera.dart';
import 'package:matchfinder/Model/image.dart';
import 'package:matchfinder/const/const.dart';
import 'package:matchfinder/const/general_methods.dart';
import 'package:matchfinder/core/payment/upgradePayment.dart';
import 'package:matchfinder/utils/function.dart';
import 'package:matchfinder/utils/style.dart';
import 'package:matchfinder/utils/url.dart';
import 'package:matchfinder/widgets/image_widget.dart';
import 'package:matchfinder/widgets/text_field.dart';

class RegisterThird extends StatefulWidget {
  @override
  _RegisterThirdState createState() => _RegisterThirdState();
}

class _RegisterThirdState extends State<RegisterThird> {
  final _key = GlobalKey<ScaffoldState>();
  final _formKey = GlobalKey<FormState>();
  TextEditingController caption = TextEditingController();
  bool isLoading = false;
  bool inProcess = false;
  bool inUploading = false;
  bool isFirstImage = true;
  File profileImage;
  Response response;
  double percentage = 0.0;
  List<Images> imagesList = List<Images>();
  bool upload = false;

  String buttonText = 'Complete  Registration';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: white,
      key: _key,
      appBar: AppBar(
        shadowColor: appColor,
        backgroundColor: appColor,
        automaticallyImplyLeading: false,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: white,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: Image.asset(
          'assets/logowhite.png',
          // width: 142,
          height: 50,
        ),
        actions: [
          Row(
            children: [
              roundCircle(
                '1',
                borderColorField,
                miniWhiteTextStyle,
              ),
              Container(
                width: 10,
                child: Divider(
                  color: borderColorField,
                  thickness: 2,
                ),
              ),
              roundCircle(
                '2',
                borderColorField,
                miniWhiteTextStyle,
              ),
              Container(
                width: 10,
                child: Divider(
                  color: borderColorField,
                  thickness: 2,
                ),
              ),
              roundCirclePresent(
                '3',
                white,
                miniGreyColorStyle,
              ),
              SizedBox(
                width: 15,
              ),
            ],
          ),
        ],
      ),
      body: Container(
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                Container(
                  padding: EdgeInsets.symmetric(
                    vertical: 15,
                    horizontal: 30,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Expanded(
                        child: Text(
                          'Add photos to your profile to get \n'
                          '20 times more response!',
                          textAlign: TextAlign.center,
                          style: miniGreyColorStyle,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  color: borderColorField,
                  height: 300,
                  width: MediaQuery.of(context).size.width,
                  child: profileImage != null
                      ? Image.file(
                    profileImage,
                    fit: BoxFit.cover,
                    height: 100,
                    width: 100,
                  )
                      : Container(
                      width: MediaQuery.of(context).size.width,
                      height: 150,
                      child: Column(
                        children: <Widget>[
                          imagesList.length != 0
                              ? Container(
                                  padding: EdgeInsets.all(10),
                                  child: Center(
                                    child: Text(
                                        'Select one of them as a profile picture.'),
                                  )
                              )
                              : Container(),
                          Container(
                            height: 185,
                            child: ListView.builder(
                               // shrinkWrap: true,
                                padding: EdgeInsets.fromLTRB(20, 5, 20, 5),
                                scrollDirection: Axis.horizontal,
                                itemCount: imagesList.length,
                                // padding: EdgeInsets.only(left: 5, right: 5),
                                itemBuilder: (BuildContext context,
                                    int index) =>
                                    GestureDetector(
                                      child: Column(
                                        children: [
                                          Stack(
                                              clipBehavior: Clip.none, children: [
                                                Container(
                                                  height: 150,
                                                  width: 150,
                                                  padding:
                                                  EdgeInsets.all(2),
                                                  child: Image.network(
                                                    imagesList
                                                        .elementAt(
                                                        index)
                                                        .photoUrl,
                                                    height: 150,
                                                    width: 150,
                                                    fit: BoxFit.fill,
                                                  ),
                                                ),
                                                Positioned(
                                                  bottom: 8,
                                                  right: 8,
                                                  child: GestureDetector(
                                                    onTap: () async {
                                                      _key.currentState
                                                          .showSnackBar(
                                                        snackBar(
                                                          'Updated as profile image',
                                                          Colors.green,
                                                          Icons.verified_user,
                                                        ),
                                                      );
                                                      await submitData(UrlLinks.photoProfileUrl, {
                                                        'photoId': imagesList.elementAt(index).photoId
                                                      });
                                                      setState(() {});
                                                    },
                                                    child: Icon(
                                                        imagesList.elementAt(index).profileImage == "Y"
                                                            ? Icons
                                                            .check_circle
                                                            : Icons
                                                            .select_all_outlined,
                                                        color: white),
                                                  ),
                                                ),
                                              ]),
                                          Text(imagesList
                                              .elementAt(index)
                                              .caption
                                              .toString()),
                                        ],
                                      ),
                                      onTap: () async {
                                        print('image list');
                                        Response response =
                                        await submitData(
                                            UrlLinks
                                                .photoProfileUrl,
                                            {
                                              'photoid': imagesList
                                                  .elementAt(index)
                                                  .photoId
                                            });
                                        for (int i = 0;
                                        i < imagesList.length;
                                        i++) {
                                          if (index == i) {
                                            imagesList
                                                .elementAt(i)
                                                .profileImage = "Y";
                                          } else {
                                            imagesList
                                                .elementAt(i)
                                                .profileImage = "N";
                                          }
                                        }

                                        setState(() {
                                          _key.currentState
                                              .showSnackBar(
                                            snackBar(
                                              'Updated as profile image',
                                              Colors.green,
                                              Icons.verified_user,
                                            ),
                                          );
                                        });
                                      },
                                    )),
                          ),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              AssetImageWidget(image: 'assets/image-gallery.svg',),
                              SizedBox(width: 10,),
                              Text('See All Photos'),
                            ],
                          )
                        ],
                      )
                  ),
                ),
                Container(
                  transform: Matrix4.translationValues(0.0, -25, 0.0),
                  decoration: BoxDecoration(
                      color: white,
                      shape: BoxShape.circle
                  ),
                  padding: EdgeInsets.all(15),
                  child: Center(
                      child: Text('OR', style: smallGreyTextStyle,)
                  ),
                ),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      if (profileImage == null && percentage == 0.0)
                        Text(
                          isFirstImage
                              ? 'Upload your profile photo!'
                              : 'Upload any other photo',
                          textAlign: TextAlign.center,
                          style: headingBlackStyle,
                        ),
                    ],
                  ),
                ),
                SizedBox(height: 15,),
                profileImage != null
                    ? Column(
                  children: [
                    //if( percentage==1.0)
                    Container(
                      margin: EdgeInsets.symmetric(
                        horizontal: 30,
                        // vertical: 40,
                      ),
                      child: TextFieldCustom(
                        controller: caption,
                        style: miniGreyTextStyle,
                        labelText:
                        'Say something about this photo...',
                        inputType: TextInputType.text,
                      ),
                    ),
                    SizedBox(
                      height: 5,
                    ),

                    SizedBox(
                      height: 30,
                    ),

                    isLoading || percentage != 0.0
                        ? Center(
                        child: Column(
                          children: [
                            CircularProgressIndicator(),
                            SizedBox(
                              height: 5,
                            ),
                            Text(
                                'Photos Upload in Progress, Please Wait...')
                          ],
                        ))
                        : MaterialButton(
                      onPressed: () async {
                        if (percentage == 0.0) {
                          response = await uploadImage(
                              profileImage);
                          isFirstImage
                              ? uploadImageDataBase(true)
                              : uploadImageDataBase(
                              false);
                        }
                      },
                      color: appColor,
                      shape: RoundedRectangleBorder(
                        borderRadius:
                        BorderRadius.circular(23.0),
                      ),
                      child: Container(
                        padding: EdgeInsets.symmetric(
                          vertical: 14,
                          horizontal: 40,
                        ),
                        child: Text(
                          percentage == 1.0
                              ? 'Update Caption'
                              : 'Upload Photo',
                          textAlign: TextAlign.center,
                          style: miniWhiteTextStyle,
                        ),
                      ),
                    ),
                  ],
                )
                    : Column(
                  children: [
                    Row(
                      mainAxisAlignment:
                      MainAxisAlignment.spaceEvenly,
                      children: [
                        displayFolder(() {
                          selectImage(ImgSource.Gallery);
                        }, 'Other Folders',
                            'assets/folder_open.svg'),
                        displayFolder(() {
                          selectImage(ImgSource.Camera);
                        }, 'Take A Photo', 'assets/folder.svg'),
                      ],
                    ),
                    SizedBox(
                      height: 55,
                    ),
                    gender == "F"
                        ? MaterialButton(
                      onPressed: () async {
                        if (imagesList.length != 0) {
                          changeScreen(
                              context, UpgradePayment());
                        } else {
                          _key.currentState.showSnackBar(
                            snackBar(
                              'Add photo to complete your registration',
                              Colors.red,
                              Icons.error,
                            ),
                          );
                        }

                        //  print(imagesList[0].caption);
                      },
                      color: appColor,
                      shape: RoundedRectangleBorder(
                        borderRadius:
                        BorderRadius.circular(0.0),
                      ),
                      child: Container(
                        padding: EdgeInsets.symmetric(
                          vertical: 14,
                          horizontal: 40,
                        ),
                        child: Text(
                          buttonText,
                          textAlign: TextAlign.center,
                          style: miniWhiteTextStyle,
                        ),
                      ),
                    )
                        : MaterialButton(
                      onPressed: () async {
                        if (imagesList.length != 0) {
                          changeScreen(
                              context, UpgradePayment());
                        } else {
                          //alert
                          showDialog(
                            context: context,
                            builder:
                                (BuildContext context) {
                              return AlertDialog(
                                title: Text("Warning"),
                                content: Text(
                                    "You can't view the photos of other profiles without adding your own photo. Do you want to Proceed?"),
                                actions: [
                                  FlatButton(
                                    child: Text("Cancel"),
                                    onPressed: () {
                                      Navigator.of(
                                          context)
                                          .pop();
                                    },
                                  ),
                                  FlatButton(
                                    child:
                                    Text("Continue"),
                                    onPressed: () {
                                      changeScreenReplacementUtils(
                                          context,
                                          UpgradePayment());
                                    },
                                  )
                                ],
                              );
                            },
                          );
                        }
                      },
                      color: appColor,
                      shape: RoundedRectangleBorder(
                        borderRadius:
                        BorderRadius.circular(0.0),
                      ),
                      child: Container(
                        padding: EdgeInsets.symmetric(
                          vertical: 14,
                          horizontal: 40,
                        ),
                        child: Text(
                          'Complete Registration',
                          textAlign: TextAlign.center,
                          style: miniWhiteTextStyle,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  displayFolder(GestureTapCallback onTap, String text, String assetImage) {
    return InkWell(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: borderColorField,
              ),
            ),
            padding: EdgeInsets.all(
              15,
            ),
            child: AssetImageWidget(image: assetImage,)
          ),
          SizedBox(
            height: 8,
          ),
          Row(
            children: [
              Text(
                text,
                textAlign: TextAlign.center,
                style: extraMiniGreyColorStyle,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Future selectImage(ImgSource source) async {
    setState(() {
      inProcess = true;
    });
    File image = await imagePicker(source);
    if (image != null) {
      //   File cropped = await cropImage(image);

      setState(() {
        profileImage = image; //cropped;
        inProcess = false;
      });
    } else {
      setState(() {
        inProcess = false;
      });
    }
  }

  imagePicker(ImgSource source) {
    return ImagePickerGC.pickImage(
      context: context,
      source: source,
      galleryText: Text(
        'Gallery',
        style: TextStyle(color: appColor),
      ),
      cameraText: Text(
        'Camera',
        style: TextStyle(color: appColor),
      ),
      galleryIcon: Icon(
        Icons.photo,
        color: appColor,
      ),
      cameraIcon: Icon(
        Icons.camera_alt,
        color: appColor,
      ),
    );
  }

  uploadImage(File file) async {
    final getAppraisalsKey = UrlLinks.photoUploadUrl;
    var formData = FormData();
    formData.files.addAll([
      MapEntry(
        "photoid",
        MultipartFile.fromFileSync(
          file.path,
          filename: "upload.jpg",
        ),
      ),
    ]);
    Dio dio = Dio();
    var cookieJar = CookieJar();
    dio.interceptors.add(CookieManager(cookieJar));
    Response respons = await dio.post(
      getAppraisalsKey,
      data: formData,
      onSendProgress: (int send, int total) {
        setState(() {
          percentage = (send / total);
        });
        print((send / total));
      },
    );
    setState(() {
      response = respons;
    });
    return respons;
  }

  uploadImageDataBase(bool isProfile) async {
    if (_formKey.currentState.validate() && profileImage != null) {
      FocusScope.of(context).requestFocus(new FocusNode());
      setState(() {
        percentage = 0.0;
        isLoading = true;
        inUploading = true;
      });
      //   Response response = await uploadImage(profileImage);
      if (response.data['photos'] != null) {
        print('phot not == null');
        print(response);
        print(response.data['photos'][0]['photoId']);
        var rs = await submitData(UrlLinks.photoCaptionUrl, {
          'photoid': response.data['photos'][0]['photoId'],
          'caption': caption.text,
        });
        print('photo id response');
        print(rs);
        setState(() {
          imagesList.add(Images(
            proId: response.data['photos'][0]['proId'],
            photoId: response.data['photos'][0]['photoId'],
            photoUrl: response.data['photos'][0]['url'],
            profileImage: response.data['photos'][0]['profilePhoto'],
            caption: caption.text,
          ));
          buttonText = 'Complete Registration';
          print(imagesList.length);
        });
        if (isProfile) {
          var value = getSession();
          if (value != null) {
            Response respons = await submitData(UrlLinks.photoProfileUrl,
                {'photoid': response.data['photos'][0]['photoId']});
            print('check profile url response');
            print(respons);
          }
        } else {
          print('Not profile');
        }
        _key.currentState.showSnackBar(
          snackBar(
            'Image uploaded',
            Colors.green,
            Icons.verified_user,
          ),
        );
        setState(() {
          profileImage = null;
          percentage = 0.0;
          caption.clear();
          isFirstImage = false;
          isLoading = false;
          inUploading = false;
        });
      }
    } else {
      _key.currentState.showSnackBar(
        snackBar(
          'Add image',
          Colors.red,
          Icons.security,
        ),
      );
    }
  }
}
