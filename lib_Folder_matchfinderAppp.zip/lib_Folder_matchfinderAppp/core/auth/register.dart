import 'package:dio/dio.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:matchfinder/const/general_methods.dart';
import 'package:matchfinder/core/auth/registerSecondStep.dart';
import 'package:matchfinder/const/const.dart';
import 'package:matchfinder/utils/function.dart';
import 'package:matchfinder/utils/privacyPolicy.dart';
import 'package:matchfinder/utils/style.dart';
import 'package:matchfinder/utils/termsConditions.dart';
import 'package:matchfinder/widgets/caste_select.dart';
import 'package:matchfinder/widgets/customDrop.dart';
import 'package:matchfinder/widgets/text_field.dart';
import '../../widgets/select_multiple.dart';
import 'dropDownCast.dart';
import 'dropDownCity.dart';
import 'login.dart';

class Register extends StatefulWidget {
  @override
  _RegisterState createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  final _formKey = GlobalKey<FormState>();
  final _key = GlobalKey<ScaffoldState>();

  TextEditingController email = TextEditingController();
  TextEditingController password = TextEditingController();
  TextEditingController phone = TextEditingController();
  TextEditingController name = TextEditingController();
  TextEditingController castTextController = TextEditingController();
  TextEditingController cityController = TextEditingController();

  String groupValue = "male";
  bool isChristian = false;

  bool isDay = true;
  bool isMonth = true;
  bool isYear = true;
  bool isMotherTounge = true;
  bool isReligion = true;
  bool isChurch = false;
  bool isPhone = true;
  bool isRelationShip = false;
  bool isCity = true;
  bool isCountry = false;
  bool isCast = true;
  bool isDisplay = false;
  bool isLoading = false;
  bool _autoValidate = false;

  String day;
  String month;
  String year;
  String city;
  String cast;
  String church;
  String motherTongue;
  String country = 'IN';
  String countryISD = '91';
  String religion;
  String relationShip = 'SELF';
  List<String> castString = <String>[];

  List<DropdownMenuItem<String>> dayDropDown = <DropdownMenuItem<String>>[];

  List<DropdownMenuItem<String>> monthDropDown = <DropdownMenuItem<String>>[];

  List<DropdownMenuItem<String>> yearDropDown = <DropdownMenuItem<String>>[];

  List<DropdownMenuItem<String>> countryDropDown = <DropdownMenuItem<String>>[];

  List<DropdownMenuItem<String>> countryISDDropDown =
      <DropdownMenuItem<String>>[];

  List<DropdownMenuItem<String>> religionDropDown =
      <DropdownMenuItem<String>>[];

  List<DropdownMenuItem<String>> churchDropDown = <DropdownMenuItem<String>>[];
  List<DropdownMenuItem<String>> motherTongueDropDown =
      <DropdownMenuItem<String>>[];

  List<DropdownMenuItem<String>> relationShipDropDown =
      <DropdownMenuItem<String>>[];

  getDateDropDown(String date) async {
    List<dynamic> res;
    if (date.contains('DAY')) {
      res = days;
    } else if (date.contains('MONTH')) {
      res = months;
    } else {
      res = years;
    }
    if (res.isNotEmpty) {
      List<dynamic> value = res.reversed.toList();
      List<DropdownMenuItem<String>> items = new List();
      for (int i = 0; i < value.length; i++) {
        setState(() {
          items.insert(
            0,
            DropdownMenuItem(
              child: Text(
                value[i][1],
              ),
              value: value[i][0],
            ),
          );
        });
      }
      return items;
    } else {
      return null;
    }
  }

  getCountryDropDown() async {
    // List<dynamic> res = await getCountry();
    if (countries.isNotEmpty) {
      List<dynamic> value = countries.reversed.toList();
      List<DropdownMenuItem<String>> items = new List();
      for (int i = 0; i < value.length; i++) {
        setState(() {
          items.insert(
            0,
            DropdownMenuItem(
              child: Text(
                value[i][1],
              ),
              value: value[i][0],
            ),
          );
        });
      }
      return items;
    } else {
      return null;
    }
  }

  getCountryISDDropDown() async {
    //List<dynamic> res = await getCountryISD();
    if (countryisd.isNotEmpty) {
      List<dynamic> value = countryisd.reversed.toList();
      List<DropdownMenuItem<String>> items = new List();
      for (int i = 0; i < value.length; i++) {
        setState(() {
          items.insert(
            0,
            DropdownMenuItem(
              child: Text(
                value[i][1],// + ' (+' + value[i][0] + ')',
              ),
              value: value[i][0],
            ),
          );
        });
      }
      return items;
    } else {
      return null;
    }
  }

  getMotherTongueDropDown() async {
    // List<dynamic> res = await getMotherTongue();
    if (motherTongueList.isNotEmpty) {
      List<dynamic> value = motherTongueList.reversed.toList();
      List<DropdownMenuItem<String>> items = new List();
      for (int i = 0; i < value.length; i++) {
        setState(() {
          items.insert(
            0,
            DropdownMenuItem(
              child: Text(
                value[i][1],
              ),
              value: value[i][0],
            ),
          );
        });
      }
      return items;
    } else {
      return null;
    }
  }

  getReligionDropDown() async {
    //  List<dynamic> res = await getReligion();
    if (religions.isNotEmpty) {
      List<dynamic> value = religions.reversed.toList();
      List<DropdownMenuItem<String>> items = new List();
      for (int i = 0; i < value.length; i++) {
        setState(() {
          items.insert(
            0,
            DropdownMenuItem(
              child: Text(
                value[i][1],
              ),
              value: value[i][0],
            ),
          );
        });
      }
      return items;
    } else {
      return null;
    }
  }

  getChurchDropDown() async {
    // List<dynamic> res = await getChurch();
    if (churchs.isNotEmpty) {
      List<dynamic> value = churchs.reversed.toList();
      List<DropdownMenuItem<String>> items = new List();
      for (int i = 0; i < value.length; i++) {
        setState(() {
          items.insert(
            0,
            DropdownMenuItem(
              child: Text(
                value[i][1],
              ),
              value: value[i][0],
            ),
          );
        });
      }
      return items;
    } else {
      return null;
    }
  }

  getRelationShipDropDown() async {
    // List<dynamic> res = await getRelationShip();
    if (relationship.isNotEmpty) {
      List<dynamic> value = relationship.reversed.toList();
      List<DropdownMenuItem<String>> items = new List();
      for (int i = 0; i < value.length; i++) {
        setState(() {
          items.insert(
            0,
            DropdownMenuItem(
              child: Text(
                value[i][1],
              ),
              value: value[i][0],
            ),
          );
        });
      }
      return items;
    } else {
      return null;
    }
  }

  @override
  void initState() {
    super.initState();
    getData();
  }

  getData() async {
    dayDropDown = await getDateDropDown('DAY');
    monthDropDown = await getDateDropDown('MONTH');
    yearDropDown = await getDateDropDown('YEAR');
    motherTongueDropDown = await getMotherTongueDropDown();
    religionDropDown = await getReligionDropDown();
    countryDropDown = await getCountryDropDown();
    relationShipDropDown = await getRelationShipDropDown();
    countryISDDropDown = await getCountryISDDropDown();
  }

  @override
  void dispose() {
    name.dispose();
    email.dispose();
    phone.dispose();
    password.dispose();
    if (dayDropDown.isNotEmpty) dayDropDown.clear();
    if (yearDropDown.isNotEmpty) yearDropDown.clear();
    if (monthDropDown.isNotEmpty) monthDropDown.clear();
    if (churchDropDown.isNotEmpty) churchDropDown.clear();
    if (countryDropDown.isNotEmpty) countryDropDown.clear();
    if (religionDropDown.isNotEmpty) religionDropDown.clear();
    if (countryISDDropDown.isNotEmpty) countryISDDropDown.clear();
    if (relationShipDropDown.isNotEmpty) relationShipDropDown.clear();
    if (motherTongueDropDown.isNotEmpty) motherTongueDropDown.clear();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _key,
      appBar: buildAppBar(context),
      body: Center(
        child: isLoading
            ? CircularProgressIndicator()
            : Container(
                child: Form(
                    key: _formKey,
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                    child: ListView(
                      children: [
                        Card(
                          child: Container(
                            decoration: BoxDecoration(
                              border: Border.all(
                                color: Colors.grey.withOpacity(.5),
                                width: 1,
                              ),
                            ),
                            padding: EdgeInsets.symmetric(
                              vertical: 36,
                              horizontal: 100,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Expanded(
                                  child: Text(
                                    'Most Affordable Matrimony Site in India',
                                    textAlign: TextAlign.center,
                                    style: regularAppColorTextStyle,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          color: backGroundColor,
                          padding: EdgeInsets.symmetric(
                            horizontal: 40,
                            vertical: 18,
                          ),
                          child: Column(
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      'Create Account',
                                      textAlign: TextAlign.start,
                                      style: headingAppColorTextStyle,
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 30,
                              ),
                              TextFieldCustom(
                                controller: email,
                                style: miniGreyTextStyle,
                                labelText: 'Your Email ID',
                                inputType: TextInputType.emailAddress,
                                validator: (value) {
                                  if (value.isEmpty) {
                                    return 'Please enter your Email';
                                  }
                                  return null;
                                },
                              ),
                              TextFieldCustom(
                                controller: password,
                                style: miniGreyTextStyle,
                                labelText: 'Choose Password',
                                obscureText: true,
                                maxLines: 1,
                                inputType: TextInputType.text,
                                validator: (value) {
                                  if (value.length < 4 || value.length > 20) {
                                    return 'Password must between 4 to 20 characters';
                                  } else if (value.isEmpty) {
                                    return 'Please enter your Password';
                                  }
                                  return null;
                                },
                              ),
                              Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      'Bride or Groom Details',
                                      textAlign: TextAlign.start,
                                      style: headingAppColorTextStyle,
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 15,
                              ),
                              TextFieldCustom(
                                controller: name,
                                style: miniGreyTextStyle,
                                labelText: 'Name',
                                inputType: TextInputType.text,
                                validator: (value) {
                                  if (value.isEmpty) {
                                    return 'Please enter your Name';
                                  }
                                  return null;
                                },
                              ),
                              Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      'Gender',
                                      textAlign: TextAlign.start,
                                      style: miniGreyFontWeightStyle,
                                    ),
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  Expanded(
                                    child: ListTile(
                                      title: Row(
                                        children: [
                                          Radio(
                                            value: "male",
                                            groupValue: groupValue,
                                            onChanged: (e) => valueChanged(e),
                                          ),
                                          Text(
                                            "Male",
                                            textAlign: TextAlign.end,
                                            style: miniGreyTextStyle,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: ListTile(
                                      title: Row(
                                        children: [
                                          Radio(
                                            value: "female",
                                            groupValue: groupValue,
                                            onChanged: (e) => valueChanged(e),
                                          ),
                                          Text(
                                            "Female",
                                            textAlign: TextAlign.end,
                                            style: miniGreyTextStyle,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 15,
                              ),
                              Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      'Date of Birth',
                                      textAlign: TextAlign.start,
                                      style: miniGreyFontWeightStyle,
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 5,
                              ),
                              Row(
                                children: [
                                  Expanded(
                                    child: CustomDropDown(
                                      heading: null,
                                      hint: 'Day',
                                      value: day,
                                      items: dayDropDown,
                                      validator: (value) {
                                        if (value == null) {
                                          return '*Required';
                                        }
                                        return null;
                                      },
                                      onChanged: (value) {
                                        setState(() {
                                          isDay = false;
                                          day = value;
                                        });
                                        print('changed to $value');
                                      },
                                    ),
                                  ),
                                  SizedBox(
                                    width: 10,
                                  ),
                                  Expanded(
                                    child: CustomDropDown(
                                      heading: null,
                                      hint: 'Month',
                                      value: month,
                                      items: monthDropDown,
                                      validator: (value) {
                                        if (value == null) {
                                          return '*Required';
                                        }
                                        return null;
                                      },
                                      onChanged: (value) {
                                        setState(() {
                                          isMonth = false;
                                          month = value;
                                        });
                                        print('changed to $value');
                                      },
                                    ),
                                  ),
                                  SizedBox(
                                    width: 10,
                                  ),
                                  Expanded(
                                    child: CustomDropDown(
                                      heading: null,
                                      hint: 'Year',
                                      value: year,
                                      items: yearDropDown,
                                      validator: (value) {
                                        if (value == null) {
                                          return '*Required';
                                        }
                                        return null;
                                      },
                                      onChanged: (value) {
                                        setState(() {
                                          isYear = false;
                                          year = value;
                                        });
                                        print('changed to $value');
                                      },
                                    ),
                                  ),
                                ],
                              ),
                              CustomDropDown(
                                heading: 'Mother Tongue',
                                hint: 'Select',
                                value: motherTongue,
                                items: motherTongueDropDown,
                                validator: (value) {
                                  if (value == null && value != "0") {
                                    return '*Required';
                                  }
                                  return null;
                                },
                                onChanged: (value) {
                                  if(value != "0"){
                                    setState(() {
                                      isMotherTounge = false;
                                      motherTongue = value;
                                    });
                                  }
                                  print('changed to $value');
                                },
                              ),
                              CustomDropDown(
                                heading: 'Religion',
                                hint: 'Select',
                                value: religion,
                                items: religionDropDown,
                                validator: (value) {
                                  if (value == null) {
                                    return '*Required';
                                  }
                                  return null;
                                },
                                onChanged: (value) async {
                                  setState(() {
                                    isReligion = false;
                                    religion = value;
                                  });
                                  if (religion == '62') {
                                    setState(() {
                                      isChurch = true;
                                      isChristian = true;
                                    });
                                    churchDropDown = await getChurchDropDown();
                                  } else {
                                    setState(() {
                                      isChristian = false;
                                    });
                                  }
                                },
                              ),
                              InkWell(
                                onTap: () {
                                  _navigateAndDisplaySelection(context);
                                  // changeScreen(
                                  //     context,
                                  //     DropDownCast(
                                  //       keyScaffold: _key,
                                  //       onSelect: (value) {
                                  //         if (value.isNotEmpty) {
                                  //           setState(() {
                                  //             cast = value;
                                  //             isCast = false;
                                  //           });
                                  //           print(cast);
                                  //         }
                                  //       },
                                  //     ));
                                },
                                child: Column(
                                  children: [
                                    Row(
                                      children: [
                                        Expanded(
                                          child: Text(
                                            'Caste',
                                            textAlign: TextAlign.start,
                                            style: miniGreyFontWeightStyle,
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(
                                      height: 5,
                                    ),
                                    Container(
                                      padding: EdgeInsets.symmetric(
                                        vertical: 15,
                                        horizontal: 15,
                                      ),
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.circular(5),
                                        border: Border.all(
                                          color: borderColorField,
                                          width: 1,
                                        ),
                                      ),
                                      child: Row(
                                        children: [
                                          Text(
                                            cast != null
                                                ? cast
                                                : 'Your Community',
                                            style: cast != null ? TextStyle(
                                                fontSize: 14,
                                                color: Colors.black
                                            ) : miniGreyColorStyle,
                                          ),
                                        ],
                                      ),
                                    ),
                                    (isDisplay && isCast)
                                        ? displayError('Please select Cast')
                                        : Container(),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: 15,
                              ),
                              isChristian
                                  ? CustomDropDown(
                                      heading: 'Church',
                                      hint: '',
                                      value: church,
                                      items: churchDropDown,
                                      validator: (value) {
                                        if (value == null) {
                                          return '*Required';
                                        }
                                        return null;
                                      },
                                      onChanged: (value) {
                                        setState(() {
                                          isChurch = false;
                                          church = value;
                                        });
                                        print('changed to $value');
                                      },
                                    )
                                  : Container(),
                              CustomDropDown(
                                heading: 'Country living in',
                                hint: '',
                                value: country,
                                items: countryDropDown,
                                validator: (value) {
                                  if (value == null) {
                                    return '*Required';
                                  }
                                  return null;
                                },
                                onChanged: (value) async {
                                  print('changed to $value');
                                  setState(() {
                                    isCountry = false;
                                    country = value;
                                  });
                                },
                              ),
                              InkWell(
                                onTap: () {
                                  changeScreen(
                                      context,
                                      DropDownCity(
                                        keyScaffold: _key,
                                        onSelect: (value) {
                                          if (value.isNotEmpty) {
                                            setState(() {
                                              city = value;
                                              isCity = false;
                                            });
                                            print(city);
                                          }
                                        },
                                      ));
                                },
                                child: Column(
                                  children: [
                                    Row(
                                      children: [
                                        Expanded(
                                          child: Text(
                                            'City',
                                            textAlign: TextAlign.start,
                                            style: miniGreyFontWeightStyle,
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(
                                      height: 5,
                                    ),
                                    Container(
                                      padding: EdgeInsets.symmetric(
                                        vertical: 15,
                                        horizontal: 15,
                                      ),
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.circular(5),
                                        border: Border.all(
                                          color: borderColorField,
                                          width: 1,
                                        ),
                                      ),
                                      child: Row(
                                        children: [
                                          Text(
                                            city != null
                                                ? city
                                                : 'City Living In',
                                            style:  city != null
                                                ? TextStyle(
                                              fontSize: 14,
                                              color:Colors.black
                                            ) : miniGreyColorStyle,
                                          ),
                                        ],
                                      ),
                                    ),
                                    (isDisplay && isCity)
                                        ? displayError('Please select City')
                                        : Container(),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: 15,
                              ),
                              Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      'Your Contact Details',
                                      textAlign: TextAlign.start,
                                      style: headingAppColorTextStyle,
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 20,
                              ),
                              CustomDropDown(
                                heading: 'Your Relationship',
                                hint: '',
                                value: relationShip,
                                items: relationShipDropDown,
                                validator: (value) {
                                  if (value == null) {
                                    return '*Required';
                                  }
                                  return null;
                                },
                                onChanged: (value) {
                                  setState(() {
                                    isRelationShip = false;
                                    relationShip = value;
                                  });
                                  print('changed to $value');
                                },
                              ),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  CustomDropDown(
                                    heading: 'Your Phone Number',
                                    hint: '',
                                    value: countryISD,
                                    items: countryISDDropDown,
                                    validator: (value) {
                                      if (value == null) {
                                        return '*Required';
                                      }
                                      return null;
                                    },
                                    onChanged: (value) {
                                      setState(() {
                                        countryISD = value.toString();
                                      });
                                      print('changed to $value');
                                    },
                                  ),
                                  TextFieldCustom(
                                    controller: phone,
                                    style: miniGreyTextStyle,
                                    labelText: 'Your Phone No',
                                    inputType: TextInputType.phone,
                                    onChanged: (value) {
                                      setState(() {
                                        isPhone = false;
                                      });
                                    },
                                    validator: (value) {
                                      if (value.isEmpty) {
                                        return 'Please enter your Phone No';
                                      }
                                      return null;
                                    },
                                  ),
                                ],
                              ),
                              MaterialButton(
                                height: 60,
                                onPressed: () {
                                  register();
                                  // print(name.text);
                                  // print(
                                  //   gender,
                                  // );
                                  // print(
                                  //   day,
                                  // );
                                  // print(
                                  //   month,
                                  // );
                                  // print(
                                  //   year,
                                  // );
                                  // print(
                                  //   motherTongue,
                                  // );
                                  // print(
                                  //   religion,
                                  // );
                                  // print(
                                  //   cast,
                                  // );
                                  // print(
                                  //   country,
                                  // );
                                  // print(city);
                                  // print(
                                  //   relationShip,
                                  // );
                                  // print(
                                  //   countryISD,
                                  // );
                                  // print(phone.text);
                                },
                                color: appColor,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Text(
                                      'Submit',
                                      style: miniWhiteTextStyle,
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: 5,
                              ),
                              RichText(
                                text: TextSpan(
                                  text:
                                      'By choosing to continue, you agree to our ',
                                  style: miniGreyTextStyle,
                                  children: <TextSpan>[
                                    TextSpan(
                                      text: 'Terms & Conditions',
                                      style: miniAppColorTextStyle,
                                      recognizer: TapGestureRecognizer()
                                        ..onTap = () {
                                          changeScreen(
                                              context, TermsConditions());
                                        },
                                    ),
                                    TextSpan(
                                      text: ' & ',
                                      style: miniGreyTextStyle,
                                    ),
                                    TextSpan(
                                      text: 'Privacy Policy',
                                      recognizer: TapGestureRecognizer()
                                        ..onTap = () {
                                          changeScreen(
                                              context, PrivacyPolicy());
                                        },
                                      style: miniAppColorTextStyle,
                                    ),
                                    TextSpan(
                                      text: '.',
                                      style: miniGreyTextStyle,
                                    ),
                                  ],
                                ),
                              ),
                              isDisplay
                                  ? Column(
                                      children: [
                                        isDay
                                            ? displayError('Please select Day')
                                            : Container(),
                                        isMonth
                                            ? displayError(
                                                'Please select Month')
                                            : Container(),
                                        isYear
                                            ? displayError('Please select Year')
                                            : Container(),
                                        isMotherTounge
                                            ? displayError(
                                                'Please select Mother Tongue')
                                            : Container(),
                                        isChurch
                                            ? displayError(
                                                'Please select Church')
                                            : Container(),
                                        isReligion
                                            ? displayError(
                                                'Please select Religion')
                                            : Container(),
                                        isPhone
                                            ? displayError(
                                                'Please select Phone Code')
                                            : Container(),
                                        isRelationShip
                                            ? displayError(
                                                'Please select Relationship')
                                            : Container(),
                                        isCity
                                            ? displayError('Please select City')
                                            : Container(),
                                        isCountry
                                            ? displayError(
                                                'Please select Country')
                                            : Container(),
                                        isCast
                                            ? displayError(
                                                'Please select Caste')
                                            : Container(),
                                      ],
                                    )
                                  : Container(),
                              SizedBox(
                                height: 10,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
              ),
      ),
    );
  }

  // _navigateAndSelectCast(BuildContext context) async {
  //   await Navigator.push(
  //     context,
  //     MaterialPageRoute(
  //         builder: (context) => SelectMultiple(casteList.sublist(1, casteList.length), cast != null && cast.length > 0 ? cast+', ' : '')),
  //   ).then((result) {
  //     if (result != null) {
  //       setState(() {
  //         cast = result;
  //         result.toString().isEmpty ? isCast = true : isCast = false;
  //       });
  //     }
  //   });
  // }
  //
  // Widget containerTile({String heading, String value, bool val, bool isDrawer = false}) {
  //   List<String> values = value != null && value != '' ? value.split(',') : [];
  //   return InkWell(
  //     onTap: () {
  //       _navigateAndSelectCast(context);
  //     },
  //     child: Column(
  //       crossAxisAlignment: CrossAxisAlignment.start,
  //       children: [
  //         Text(
  //           heading,
  //           style: miniGreyFontWeightStyle,
  //         ),
  //         SizedBox(
  //           height: 5,
  //         ),
  //         Container(
  //           padding: EdgeInsets.symmetric(
  //             vertical: 15,
  //             horizontal: 15,
  //           ),
  //           decoration: BoxDecoration(
  //             color: Colors.white,
  //             borderRadius: BorderRadius.circular(5),
  //             border: Border.all(
  //               color: borderColorField,
  //               width: 1,
  //             ),
  //           ),
  //           child: Row(
  //             mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //             children: [
  //               values.length > 0
  //                   ? Container(
  //                 height: 40,
  //                 padding: EdgeInsets.only(left: 5, right: 5),
  //                 width: MediaQuery.of(context).size.width * 0.7,
  //                 child: ListView.separated(
  //                     itemCount: values.length,
  //                     scrollDirection: Axis.horizontal,
  //                     shrinkWrap: true,
  //                     separatorBuilder: (context, index) {
  //                       return Container(
  //                         width: 10,
  //                       );
  //                     },
  //                     itemBuilder: (context, index) {
  //                       return Container(
  //                         padding: EdgeInsets.all(10),
  //                         decoration: BoxDecoration(
  //                           color: borderColorField,
  //                           borderRadius:
  //                           BorderRadius.all(Radius.circular(30.0)),
  //                         ),
  //                         child: Column(
  //                           mainAxisAlignment: MainAxisAlignment.center,
  //                           crossAxisAlignment: CrossAxisAlignment.center,
  //                           children: [
  //                             Text(
  //                               values[index],
  //                               style: TextStyle(fontSize: 12),
  //                             ),
  //                           ],
  //                         ),
  //                       );
  //                     }),
  //               )
  //                   : Flexible(
  //                 child: Text(
  //                   'Select $heading',
  //                   maxLines: null,
  //                   textAlign: TextAlign.justify,
  //                   style: TextStyle(
  //                     fontSize: 14,
  //                     color: greyTextField,
  //                   ),
  //                 ),
  //               ),
  //               Icon(
  //                 Icons.arrow_forward_ios,
  //                 color: grey,
  //               )
  //             ],
  //           ),
  //         ),
  //         (isDisplay && val)
  //             ? displayError('Please select $heading')
  //             : Container(),
  //       ],
  //     ),
  //   );
  // }

  buildAppBar(BuildContext context) {
    return AppBar(
      shadowColor: appColor,
      backgroundColor: appColor,
      automaticallyImplyLeading: false,
      leading: IconButton(
        icon: Icon(
          Icons.arrow_back,
          color: white,
        ),
        onPressed: () {
          Navigator.pop(context);
        },
      ),
      centerTitle: true,
      title: Image.asset(
        'assets/logowhite.png',
        // width: 142,
        height: 50,
      ),
      actions: [
        InkWell(
          onTap: () {
            changeScreen(context, Login());
          },
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                'Login',
                style: smallWhiteTextStyle,
              ),
              SizedBox(
                width: 5,
              ),
              Icon(
                Icons.arrow_forward_ios,
                color: white,
                size: 20,
              ),
              SizedBox(
                width: 10,
              ),
            ],
          ),
        ),
      ],
    );
  }

  valueChanged(e) {
    setState(() {
      if (e == "male") {
        groupValue = e;
        gender = e;
      } else if (e == "female") {
        groupValue = e;
        gender = e;
      }
    });
  }

  displayError(String error) {
    return Column(
      children: [
        SizedBox(
          height: 15,
        ),
        Row(
          children: [
            Expanded(
              child: Text(
                error,
                style: miniRedTextStyle,
              ),
            ),
          ],
        ),
      ],
    );
  }

  register() async {
    if (_formKey.currentState.validate() &&
        !isCity &&
        !isCast &&
        !isReligion &&
        !isMotherTounge &&
        !isYear &&
        !isMonth &&
        !isDay &&
        !isChurch) {
      String nameValue = name.text.trim();
      // List<String> value = nameValue.split(' ');
      setState(() {
        isLoading = true;
        isDisplay = false;
      });
      gender = gender == "male" ? "M" : "F";
      // print("Details");
      // print(gender);
      // print(day);
      // print(month);
      // print(year);
      // print(motherTongue);
      // print(religion);
      // print(cast);
      // print(country);
      // print(relationShip);
      // print(countryISD);
      // print(phone.text);
      Response response = await signUp(
        email: email.text.trim(),
        password: password.text.trim(),
        name: nameValue,
        lastName: '',
        gender: gender,
        day: day,
        month: month,
        year: year,
        motherTongue: motherTongue,
        religion: religion,
        cast: cast,//.replaceAll(', ', ','),
        city: city,
        country: country,
        relationShip: relationShip,
        countryISD: countryISD,
        phone: phone.text.trim(),
      );
      setState(() {
        isLoading = false;
      });
      print(response.data);
      if (response.data['reqstatus'] == 'success') {
        changeScreen(context, RegisterSecond());
        /*  _key.currentState
            .showSnackBar(
              snackBar(
                'User Registered',
                Colors.green,
                Icons.verified_user,
              ),
            )
            .closed
            .then((value) => changeScreen(context, RegisterSecond()));
      */
      } else {
        setState(() {
          isDisplay = true;
        });

        _key.currentState.showSnackBar(
          snackBar(
            response.data['regerrors'],
            Colors.red,
            Icons.security,
          ),
        );
      }
    } else {
      setState(() {
        isDisplay = true;
      });
    }
  }

  _navigateAndDisplaySelection(BuildContext context) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => SearchCast()),
    );
    setState(() {
      cast = result;
      result.toString().isEmpty ? isCast = true : isCast = false;
    });
  }
}
