import 'dart:async';
import 'package:dio/dio.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:matchfinder/const/const.dart';
import 'package:matchfinder/const/general_methods.dart';
import 'package:matchfinder/core/home/bottom_bar.dart';
import 'package:matchfinder/utils/function.dart';
import 'package:matchfinder/utils/style.dart';
import 'package:matchfinder/widgets/toast.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../utils/url.dart';
import '../../widgets/countdown_flutter.dart';
import '../../widgets/material_button.dart';
import 'package:pin_code_fields/pin_code_fields.dart';

class VerifyOtpView extends StatefulWidget {
  String email;
  String password;

  VerifyOtpView(this.email, this.password);

  @override
  _VerifyOtpViewState createState() => _VerifyOtpViewState();
}

class _VerifyOtpViewState extends State<VerifyOtpView> {
  bool _isLoading = false;
  bool showVerifyButton = true;
  var onTapRecognizer;

  final prefs = SharedPreferences.getInstance();
  StreamController<ErrorAnimationType> errorController;

  TextEditingController textEditingController = TextEditingController();
  bool hasError = false;
  final GlobalKey<ScaffoldState> _key = GlobalKey<ScaffoldState>();
  final formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    super.dispose();
  }

  @override
  void initState() {
    onTapRecognizer = TapGestureRecognizer()
      ..onTap = () {
        Navigator.pop(context);
      };
    super.initState();
  }

  Future<void> verifyPhone() async {

  }

  matchOtp() async {
    try {
      if (formKey.currentState.validate()) {
        setState(() {
          _isLoading = true;
        });
        // ToastUtil.showToast(context, UrlLinks.loginUrl);
        Response response = await login(
            widget.email.trim(), widget.password.trim());
        setState(() {
          _isLoading = false;
        });
        if (response.data['reqstatus'] == 'success') {
          // print(response.data);
          // prefs.then((value) {
          //   value.setString('userId', 'value');
          // });
          // ToastUtil.showToast(context, 'Login Successfully');
          Navigator.of(context).popUntil((route) => route.isFirst);
          changeScreenReplacement(context, BottomBar());
          // _key.currentState
          //     .showSnackBar(
          //       snackBar(
          //         'Login Successfully',
          //         Colors.green,
          //         Icons.verified_user,
          //       ),
          //     )
          //     .closed
          //     .then(
          //         (value) {
          //           Navigator.of(context).popUntil((route) => route.isFirst);
          //           changeScreenReplacement(context, BottomBar());
          //         });
        } else {
          _key.currentState.showSnackBar(
            snackBar(
              response.data['validationerrors'],
              Colors.red,
              Icons.security,
            ),
          );
        }
      }
    } catch (e) {
      handleError(e);
    }
  }


  void clearControllers(bool status) {
    setState(() {
      _isLoading = status;
      textEditingController.clear();
      showVerifyButton = true;
    });
  }

  handleError(PlatformException error) {
   setState(() {
      _isLoading = false;
    });
    switch (error.code) {
      case 'ERROR_INVALID_VERIFICATION_CODE':
        FocusScope.of(context).requestFocus(new FocusNode());
        _key.currentState.showSnackBar(
          snackBar(
            'Code does not match',
            Colors.red,
            Icons.security,
          ),
        );
        break;
      default:
        _key.currentState.showSnackBar(
          snackBar(
            error.message,
            Colors.red,
            Icons.security,
          ),
        );
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final _screenSize = MediaQuery.of(context).size;
    final body = Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        Text(
          'OTP',
          style: headingGreyTextStyle,
        ),
        SizedBox(
          height: _screenSize.height * 0.15,
        ),
        Form(
          key: formKey,
          child: Padding(
              padding: const EdgeInsets.all(30),
              child: PinCodeTextField(
                appContext: context,
                pastedTextStyle: TextStyle(fontSize: 12.0, color: Colors.black),
                length: 6,
                showCursor: true,
                obscureText: false,
                obscuringCharacter: '*',
                animationType: AnimationType.fade,
                // validator: (v) {
                //   if (v.length < 3) {
                //     return "*Required";
                //   } else {
                //     return null;
                //   }
                // },
                pinTheme: PinTheme(
                  shape: PinCodeFieldShape.underline,
                  // borderRadius: BorderRadius.zero,
                  borderWidth: 4.0,
                  fieldHeight: 45,
                  fieldWidth: 45,
                  activeColor: greyColor,
                  selectedColor: greyColor,
                  inactiveColor: greyColor,
                  selectedFillColor: Colors.white,
                  inactiveFillColor: Colors.white,
                  activeFillColor: Colors.white,
                ),
                animationDuration: Duration(milliseconds: 300),
                textStyle: TextStyle(fontSize: 20.0, color: greyColor),
                backgroundColor: Colors.white,
                enableActiveFill: true,
                autoFocus: true,
                errorAnimationController: errorController,
                controller: textEditingController,
                keyboardType: TextInputType.number,
                onCompleted: (v) {
                  print("Completed");
                },
                onChanged: (value) {
                  print(value);
                },
                beforeTextPaste: (text) {
                  print("Allowing to paste $text");
                  return true;
                },
              )),
        ),
        SizedBox(
          height: _screenSize.height * 0.1,
        ),
        showVerifyButton
            ? CountdownFormatted(
                onFinish: () {
                  setState(() {
                    if (showVerifyButton) {
                      clearControllers(false);
                      showVerifyButton = false;
                    }
                  });
                },
                duration: showVerifyButton
                    ? Duration(seconds: 60)
                    : Duration(seconds: 0),
                builder: (BuildContext ctx, String remaining) {
                  return Text(
                    "Pin expires in $remaining",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.black,
                    ),
                  );
                },
              )
            : Container(),
        SizedBox(
          height: _screenSize.height * 0.1,
        ),
        _isLoading
            ? CircularProgressIndicator()
            : Column(
              children: [
                showVerifyButton
                    ? Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 50),
                        child: Button(
                          onPressed: matchOtp,
                          text: 'Login',
                        ))
                    : Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 50),
                        child: Button(
                          onPressed: () {
                            setState(() {
                              showVerifyButton = true;
                            });
                            // Navigator.pop(context);
                          },
                          text: 'Resend',
                        ),
                      ),
                SizedBox(height: 15),
                GestureDetector(
                    onTap: (){
                      Navigator.pop(context);
                    }, child: Text('Go Back', style: maxAppColorUnderLineStyle,))
              ],
            ),
      ],
    );

    return new Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: Colors.white,
        key: _key,
        body: SafeArea(child: body));
  }

  void callResendCodeApi() {
    setState(() {
      _isLoading = true;
    });
    clearControllers(true);
    verifyPhone();
  }

}
