import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:matchfinder/const/const.dart';
import 'package:matchfinder/model/chat_messages.dart';
import 'package:matchfinder/utils/appBar.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ChatView extends StatefulWidget {

  var chatId, userId, userName, userImage;
  ChatView(this.chatId, this.userId, this.userName, this.userImage);

  @override
  ChatViewState createState() => new ChatViewState();
}

class ChatViewState extends State<ChatView> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  TextEditingController sendTextController = new TextEditingController();
  // ChatMsgApi _chatMsgApi = new ChatMsgApi();
  final prefs = SharedPreferences.getInstance();
  // var messages = null;
  List<ChatMsg> messages = new List();
  var userId = '1', userName = '';

  @override
  void initState() {
    // getUserInfo();
    super.initState();
    messages.add(ChatMsg(id: '1', text: 'fine', messageFrom: '2', messageTo: '1', createdOn: DateTime.now().toString(), image: ''));
    messages.add(ChatMsg(id: '2', text: 'yes', messageFrom: '1', messageTo: '2', createdOn: DateTime.now().toString(), image: ''));
    setState(() { });
  }

  getUserInfo() async {
    final prefs = await SharedPreferences.getInstance();
    userId = prefs.getString('userId');
    userName = prefs.getString('userName');
  }

  _chatBubble(ChatMsg message, bool isMe, bool isSameUser) {
    if (!isMe) {
      return Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: <Widget>[
              Container(
                alignment: Alignment.topRight,
                child: Container(
                  constraints: BoxConstraints(
                    maxWidth: MediaQuery.of(context).size.width * 0.80,
                  ),
                  padding: EdgeInsets.all(15),
                  margin: EdgeInsets.symmetric(vertical: 10),
                  decoration: BoxDecoration(
                    color: Color(0xFF94A5A6),
                    borderRadius: BorderRadius.only(
                      topRight: Radius.circular(30),
                      topLeft: Radius.circular(30),
                      bottomLeft: Radius.circular(30),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 2,
                        blurRadius: 5,
                      ),
                    ],
                  ),
                  child: Text(
                    message.text,
                    style: TextStyle(
                      fontFamily: 'Europa',
                      fontSize: 14,
                      color: const Color(0xffffffff),
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
              ),
              Text(
                DateFormat('hh:mm a')
                    .format(DateTime.parse(message.createdOn)),
                style: TextStyle(
                  fontFamily: 'Europa',
                  fontSize: 12,
                  color: const Color(0xff8d8c8c),
                  fontWeight: FontWeight.w400,
                ),
              ),
            ],
          ),
          SizedBox(width: 15),
          Container(
            height: 50,
            width: 50,
            decoration: BoxDecoration(
              image: DecorationImage(
                image: message.image == '' ? AssetImage(widget.userImage) : NetworkImage(message.image),
                fit: BoxFit.contain,
              ),
            ),
          ),
        ],
      );
    } else {
      return Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Container(
            height: 50,
            width: 50,
            decoration: BoxDecoration(
              image: DecorationImage(
                image: message.image == '' ? AssetImage("assets/220220_3.jpg") : NetworkImage(message.image),
                fit: BoxFit.contain,
              ),
            ),
          ),
          SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                alignment: Alignment.topLeft,
                child: Container(
                  constraints: BoxConstraints(
                    maxWidth: MediaQuery.of(context).size.width * 0.80,
                  ),
                  padding: EdgeInsets.all(15),
                  margin: EdgeInsets.symmetric(vertical: 10),
                  decoration: BoxDecoration(
                    color: appColor,
                    borderRadius: BorderRadius.only(
                      topRight: Radius.circular(30),
                      topLeft: Radius.circular(30),
                      bottomRight: Radius.circular(30),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 2,
                        blurRadius: 5,
                      ),
                    ],
                  ),
                  child: Text(
                    message.text,
                    style: TextStyle(
                      fontFamily: 'Europa',
                      fontSize: 14,
                      color: const Color(0xffffffff),
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
              ),
              Text(
                DateFormat('hh:mm a')
                    .format(DateTime.parse(message.createdOn)),
                style: TextStyle(
                  fontFamily: 'Europa',
                  fontSize: 12,
                  color: const Color(0xff8d8c8c),
                  fontWeight: FontWeight.w400,
                ),
              ),
            ],
          ),
        ],
      );
    }
  }

  _sendMessageArea() {
    return Container(
      padding: EdgeInsets.all(10),
      margin: EdgeInsets.all(10),
      height: 80,
      color: white,
      child: Container(
        padding: EdgeInsets.all(15),
        decoration: BoxDecoration(
            color: white,
            border: Border.all(width: 1.00, color: Colors.grey.shade400,),
            borderRadius: BorderRadius.all(Radius.circular(30))),
        child: TextFormField(
          controller: sendTextController,
          maxLines: null,
          textInputAction: TextInputAction.send,
          decoration: InputDecoration.collapsed(
              hintText: 'Type message here',
              hintStyle: TextStyle(
                fontFamily: "Montserrat",
                fontSize: 14,
                color: Color(0xff333348),
              )),
          textCapitalization: TextCapitalization.sentences,
          onFieldSubmitted: (val) {
            val = val.trim();
            if (val.length > 0) {
              // _chatMsgApi.addChatMsg(sendTextController.text, userImage,
              //     userId, messageToId);
              messages.add(ChatMsg(id: (messages.length-1).toString(), text: sendTextController.text, messageFrom: userId, messageTo: '2', createdOn: DateTime.now().toString(), image: ''));
              val = "";
              sendTextController.text = "";
              setState(() { });
            }
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    messages.sort((a,b) => b.createdOn.compareTo(a.createdOn));
    String prevUserId;
    return Scaffold(
      key: _scaffoldKey,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(60),
        child: AppBar(
            iconTheme: IconThemeData(color: appColor),
            shadowColor: appColor,
            backgroundColor: appColor,
            automaticallyImplyLeading: false,
            leading: IconButton(
              icon: Icon(
                Icons.arrow_back_ios,
                color: white,
              ),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
            title: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  height: 50,
                  width: 50,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      // image: widget.userImage == '' ? AssetImage("assets/220220_1.jpg") : NetworkImage(widget.userImage),
                      image: AssetImage(widget.userImage),
                      fit: BoxFit.contain,
                    ),
                  ),
                ),
                SizedBox(width: 20,),
                Text(widget.userName, style: TextStyle(fontSize: 20, color: Colors.white)),
              ],
            ),
        ),
      ),
      body: Column(
        children: [
          // Expanded(
          //     child: StreamBuilder(
          //         stream: messages,
          //         builder: (context, snapshot) {
          //           if (snapshot.data != null &&
          //               snapshot.data.docs.length > 0) {
          //             return ListView.builder(
          //               shrinkWrap: true,
          //               reverse: true,
          //               padding: EdgeInsets.all(20),
          //               itemCount: snapshot.data.docs.length,
          //               itemBuilder: (BuildContext context, int index) {
          //                 ChatMsg message = ChatMsg.fromMap(
          //                     snapshot.data.docs[index].data(),
          //                     snapshot.data.docs[index].id);
          //                 final bool isMe = message.messageFrom == userId;
          //                 final bool isSameUser =
          //                     prevUserId == message.messageFrom;
          //                 prevUserId = message.messageFrom;
          //                 return _chatBubble(message, isMe, isSameUser);
          //               },
          //             );
          //           } else {
          //             return Container();
          //           }
          //         })),
          Expanded(
            child: ListView.builder(
              shrinkWrap: true,
              reverse: true,
              padding: EdgeInsets.all(20),
              itemCount: messages.length,
              itemBuilder: (BuildContext context, int index) {
                ChatMsg message = messages[index];
                final bool isMe = message.messageFrom == userId;
                final bool isSameUser = prevUserId == message.messageFrom;
                prevUserId = message.messageFrom;
                return _chatBubble(message, isMe, isSameUser);
              },
            ),
          ),
          _sendMessageArea(),
        ],
      ),
    );
  }


}