import 'dart:io';
import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_picker_gallery_camera/image_picker_gallery_camera.dart';
import 'package:matchfinder/const/const.dart';
import 'package:matchfinder/const/general_methods.dart';
import 'package:matchfinder/utils/style.dart';
import 'package:matchfinder/widgets/image_widget.dart';
import 'package:matchfinder/widgets/show_dialog.dart';
import 'package:matchfinder/widgets/text_field.dart';
import '../../utils/appBar.dart';

class AddPhoto extends StatefulWidget {
  @override
  _AddPhotoState createState() => _AddPhotoState();
}

class _AddPhotoState extends State<AddPhoto> {
  List<File> images = [];
  bool isProfile = false;
  TextEditingController passwordController = TextEditingController();
  var protected = false;
  List<TextEditingController> controllers = new List<TextEditingController>(2);

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    controllers[0] = new TextEditingController();
    controllers[0].text = 'This is my new photo';
    controllers[1] = new TextEditingController();
    controllers[1].text = 'This is my new photo';
  }

  @override
  Widget build(BuildContext context) {
    var screenSize = MediaQuery.of(context).size;

    Widget dialogUI() {
      return new Column(
        children: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Protect my Photos',
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Arial'),
              ),
              Checkbox(
                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                value: protected,
                onChanged: (val) {
                  setState(() {
                    protected = !protected;
                  });
                },
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                  width: screenSize.width * 0.4,
                  child: Text('Your Photo Password: ')),
              Container(
                width: screenSize.width * 0.32,
                height: 50,
                child: TextFieldCustom(
                  controller: passwordController,
                  style: miniBlackTextStyle,
                  inputType: TextInputType.text,
                ),
              ),
            ],
          ),
        ],
      );
    }

    return Scaffold(
        appBar: AppBarWidget(
          heading: 'Add Photo',
          showIcon: true,
        ),
        body: GestureDetector(
          onTap: (){
            FocusScope.of(context).requestFocus(new FocusNode());
          },
          child: Container(
            padding: EdgeInsets.all(20),
            child: ListView(
              children: [
                Text(
                  'Manage Media',
                  style: headingBlackStyle,
                ),
                SizedBox(
                  height: 10,
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(60, 10, 60, 30),
                  child: DottedBorder(
                    borderType: BorderType.RRect,
                    radius: Radius.circular(5),
                    padding: EdgeInsets.fromLTRB(135, 80, 135, 80),
                    color: Colors.black,
                    strokeWidth: 1,
                    child: GestureDetector(
                        onTap: () {
                          getImageChoice(
                              context: context,
                              cameraMethod: selectCamera,
                              galleryMethod: selectGallery);
                        },
                        child: AssetImageWidget(
                          image: 'assets/upload.svg',
                          height: 50,
                          width: 50,
                          color: grey,
                        )),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                GestureDetector(
                  onTap: () {
                    getImageChoice(
                        context: context,
                        cameraMethod: selectCamera,
                        galleryMethod: selectGallery);

                  },
                  child: Align(
                    alignment: Alignment.center,
                    child: Container(
                      width: screenSize.width * 0.4,
                      color: greenBtn,
                      height: 50,
                      child: Center(
                          child: Text('Add Photo', style: smallWhiteTextStyle)),
                    ),
                  ),
                ),
                Container(
                  padding: EdgeInsets.only(top: 20, bottom: 20),
                  child: Divider(),
                ),
                Text(
                  'Photos Protected',
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,),
                ),
                SizedBox(
                  height: 20,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'No',
                      style: TextStyle(fontSize: 16),
                    ),
                    GestureDetector(
                        onTap: () {
                          showAlertDialog(
                              context, screenSize, 'Save', dialogUI(), 170.0,
                              onSave: () {
                            print(passwordController.text);
                            Navigator.pop(context);
                          });
                        },
                        child: Text(
                          'Edit',
                          style: TextStyle(
                              fontSize: 18, color: appColor),
                        ))
                  ],
                ),
                SizedBox(
                  height: 30,
                ),
                // Container(
                //   height: 230,
                //   child: ListView.builder(
                //       shrinkWrap: true,
                //       scrollDirection: Axis.horizontal,
                //       itemCount: this.images.length,
                //       itemBuilder: (context, index) {
                //         if (this.images.length == 0) {
                //           return Center(child: Text('No Pictures Found.'));
                //         }
                //         return Container(
                //           width: screenSize.width * 0.35,
                //           child: Column(
                //             crossAxisAlignment: CrossAxisAlignment.start,
                //             children: [
                //               Image.file(
                //                 this.images[index],
                //                 width: 150,
                //                 height: 130,
                //               ),
                //               Row(
                //                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
                //                 children: [
                //                   Row(
                //                     children: [
                //                       Container(
                //                         width: screenSize.width * 0.12,
                //                         padding: EdgeInsets.all(0),
                //                         child: Switch(
                //                           onChanged: (val) {
                //                             setState(() {
                //                               isProfile = !isProfile;
                //                             });
                //                           },
                //                           value: isProfile,
                //                           activeColor: Colors.blue,
                //                           inactiveTrackColor: Colors.orange,
                //                         ),
                //                       ),
                //                       Text(
                //                         'Profile Picture',
                //                         style: TextStyle(
                //                             color: Colors.orange, fontSize: 10),
                //                       ),
                //                     ],
                //                   ),
                //                   GestureDetector(
                //                     onTap: () {
                //                       setState(() {
                //                         this.images.removeAt(index);
                //                       });
                //                     },
                //                     child: Icon(
                //                       Icons.delete,
                //                       color: Colors.orange,
                //                       size: 16,
                //                     ),
                //                   )
                //                 ],
                //               ),
                //               Container(
                //                   width: double.infinity,
                //                   padding: EdgeInsets.all(10),
                //                   color: grey.withOpacity(0.2),
                //                   child: Text(
                //                     'This is my new photo',
                //                     style: TextStyle(fontSize: 12),
                //                   )),
                //             ],
                //           ),
                //         );
                //       }),
                // ),
                Container(
                  width: MediaQuery.of(context).size.width,
                  height: 340,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: 2,
                    itemBuilder:
                        (BuildContext context, int index) =>
                            Column(
                              children: [
                                Card(
                                  child: Column(
                                    children: [
                                      Container(
                                        width: 180,
                                        height: 180,
                                        decoration: BoxDecoration(
                                            image: DecorationImage(
                                                image: AssetImage(
                                                    "assets/220220_3.jpg"),
                                                fit: BoxFit.fill)
                                        ),
                                      ),
                                      SizedBox(height: 10),
                                      Container(
                                        width: screenSize.width * 0.35,
                                        child: Row(
                                          mainAxisSize: MainAxisSize.max,
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          // crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Row(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              // crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  height: 20,
                                                  width: 60,
                                                  child: Switch(
                                                    activeColor: white,
                                                      activeTrackColor: orange,
                                                      inactiveThumbColor: white,
                                                      inactiveTrackColor: grey,
                                                      value: isProfile,
                                                      onChanged: (val){
                                                        isProfile = val;
                                                        setState(() { });
                                                      }),
                                                ),
                                                Text('Profile Picture', style: TextStyle(color: orange, fontSize: 10),),
                                              ],
                                            ),
                                            Icon(Icons.delete, color: orange, size: 20,)
                                          ],
                                        ),
                                      ),
                                      SizedBox(height: 5,),
                                    ],
                                  ),
                                ),
                                SizedBox(height: 10,),
                                Container(
                                    width: screenSize.width * 0.38,
                                    color: Colors.grey[200],
                                    // height: 30,
                                    padding: EdgeInsets.all(5),
                                    child:
                                    TextFormField(
                                      maxLines: 3,
                                      controller: controllers[index],
                                      style: TextStyle(fontSize: 14),
                                    )
                                ),
                              ],
                            ),
                  ),
                )
              ],
            ),
          ),
        )
    );
  }

  Future selectCamera() async {
    File image = await imagePicker(context, ImgSource.Camera);
    if (image != null) {
      //   File cropped = await cropImage(image);
      setState(() {
        Navigator.pop(context);
        this.images.add(image);
      });
    } else {}
  }

  Future selectGallery() async {
    File image = await imagePicker(context, ImgSource.Gallery);
    if (image != null) {
      //   File cropped = await cropImage(image);
      setState(() {
        Navigator.pop(context);
        this.images.add(image);
      });
    } else {}
  }
}
