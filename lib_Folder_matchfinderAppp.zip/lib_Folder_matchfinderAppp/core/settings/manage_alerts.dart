import 'package:flutter/material.dart';
import 'package:matchfinder/const/const.dart';
import 'package:matchfinder/utils/style.dart';
import 'package:matchfinder/utils/appBar.dart';
import 'package:matchfinder/widgets/material_button.dart';

class ManageAlerts extends StatefulWidget {
  @override
  _ManageAlertsState createState() => _ManageAlertsState();
}

class _ManageAlertsState extends State<ManageAlerts> {

  List selectedIDsEmail = List<String>();
  List selectedIDsMobile = List<String>();
  var emailAlerts = List<Map<String, String>>();
  var mobileAlerts = List<Map<String, String>>();

  void onItemSelected(List selectedIds, bool selected, id) {
    if (selected) {
      selectedIds.add(id);
    } else {
      selectedIds.remove(id);
    }
    setState(() { });
  }

  @override
  void initState() {
    mobileAlerts.add({
      'id': '1',
      'title': 'Interest alerts',
    });
    mobileAlerts.add({
      'id': '2',
      'title': 'Request alerts',
    });
    mobileAlerts.add({
      'id': '3',
      'title': 'Validation alerts',
    });

    emailAlerts.add({
      'id': '1',
      'title': 'Daily Matches',
    });
    emailAlerts.add({
      'id': '2',
      'title': 'Weekly Matches',
    });
    emailAlerts.add({
      'id': '3',
      'title': 'Interest emails',
    });
    emailAlerts.add({
      'id': '4',
      'title': 'Request emails',
    });
    emailAlerts.add({
      'id': '5',
      'title': 'Validation emails',
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var screenSize = MediaQuery.of(context).size;
    return Scaffold(
        appBar: AppBarWidget(heading: 'Manage Alerts', showIcon: true,),
        body: Container(
          padding: EdgeInsets.all(20),
          child: ListView(
            // crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Email & Mobile Alert Settings', style: headingBlackStyle,),
              SizedBox(height: 10,),
              Text('Email Alerts', style: headingSmallBlackStyle,),
              ListView.builder(
                    shrinkWrap: true,
                    itemCount: emailAlerts.length,
                    primary: false,
                    itemBuilder: (context, index) {
                      return CheckboxListTile(
                        controlAffinity: ListTileControlAffinity.leading,
                        contentPadding: EdgeInsets.all(0),
                        selected: false,
                        value: selectedIDsEmail.contains(emailAlerts[index]['id']),
                        onChanged: (bool selected) {
                          onItemSelected(selectedIDsEmail, selected, emailAlerts[index]['id']);
                        },
                        title: Text(emailAlerts[index]['title']),
                      );
                    }),
              SizedBox(height: 20,),
              GestureDetector(
                onTap:() { },
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Container(
                    width: screenSize.width * 0.4,
                    color: greenBtn,
                    height: 50,
                    child: Center(child: Text('Save Email Alerts', style: smallWhiteTextStyle)),
                  ),
                ),
              ),
              SizedBox(height: 40,),
              Text('Mobile Alerts', style: headingSmallBlackStyle,),
              SizedBox(height: 10,),
              ListView.builder(
                    shrinkWrap: true,
                    itemCount: mobileAlerts.length,
                    primary: false,
                    itemBuilder: (context, index) {
                      return CheckboxListTile(
                        controlAffinity: ListTileControlAffinity.leading,
                        contentPadding: EdgeInsets.all(0),
                        selected: false,
                        value: selectedIDsMobile.contains(mobileAlerts[index]['id']),
                        onChanged: (bool selected) {
                          onItemSelected(selectedIDsMobile, selected, mobileAlerts[index]['id']);
                        },
                        title: Text(mobileAlerts[index]['title']),
                      );
                    }),
              SizedBox(height: 20,),
              GestureDetector(
                onTap:() { },
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Container(
                    width: screenSize.width * 0.4,
                    color: greenBtn,
                    height: 50,
                    child: Center(child: Text('Save Mobile Alerts', style: smallWhiteTextStyle)),
                  ),
                ),
              ),
            ],
          ),
        ));
  }
}
