import 'package:flutter/material.dart';
import 'package:matchfinder/const/const.dart';
import 'package:matchfinder/widgets/customDrop.dart';
import 'package:matchfinder/widgets/image_widget.dart';
import 'package:matchfinder/widgets/text_field.dart';
import '../../model/complaint.dart';
import 'package:matchfinder/const/general_methods.dart';
import 'package:matchfinder/utils/style.dart';
import '../../utils/appBar.dart';

class Help extends StatefulWidget {
  @override
  _HelpState createState() => _HelpState();
}

class _HelpState extends State<Help> {

  List<String> items = ['Customer Care', 'Write to Us'];
  var selectedItem = '';
  List<String> problems = ['Select Problem Type', 'Problem 1', 'Problem 2'];
  var selectedProblem = '';
  List<DropdownMenuItem<String>> dropdownItems = new List();
  TextEditingController msgController = new TextEditingController();
  List<Complaint> complaints = new List();

  @override
  void initState() {
    // TODO: implement initState
    selectedItem = items[0];
    selectedProblem = problems[0];
    complaints.add(Complaint(text: 'I didn\'t get any call back', createdOn: DateTime.now().toString()));
    complaints.add(Complaint(text: 'I didn\'t get any call back', createdOn: DateTime.now().toString()));
    complaints.add(Complaint(text: 'I didn\'t get any call back', createdOn: DateTime.now().toString()));

    for (int i = 0; i < problems.length; i++) {
      setState(() {
        dropdownItems.insert(
          0,
          DropdownMenuItem(
            child: Text(problems[i]),
            value: problems[i],
          ),
        );
      });
    }
    setState(() {});
    super.initState();
  }

  @override
  Widget build(BuildContext context) {

    final message = TextFieldCustom(
        controller: msgController,
        inputType: TextInputType.text,
        validator: (value) {
          if (value.isEmpty) {
            return 'Please enter Description';
          }
          return null;
        },
        style: smallGreyTextStyle,
        maxLines: 4);

    return Scaffold(
      backgroundColor: white,
      appBar: AppBarWidget(heading: 'Help',),
      body: Container(
        padding: EdgeInsets.all(15),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                GestureDetector(
                  onTap: (){
                    setState(() {
                      selectedItem = items[0];
                    });
                  },
                  child: Container(
                    padding: EdgeInsets.all(15),
                    decoration: selectedItem == items[0] ? BoxDecoration(
                      color: grey.withOpacity(0.3),
                      borderRadius: BorderRadius.all(Radius.circular(
                        30.0,
                      )),
                    ) : null,
                    child: Text(
                      items[0],
                      style: headingAppColorTextStyle
                    ),
                  ),
                ),
                GestureDetector(
                  onTap: (){
                    setState(() {
                      selectedItem = items[1];
                    });
                  },
                  child: Container(
                    padding: EdgeInsets.all(15),
                    decoration: selectedItem == items[1] ? BoxDecoration(
                      color: grey.withOpacity(0.3),
                      borderRadius: BorderRadius.all(Radius.circular(
                        30.0,
                      )),
                    ) : null,
                    child: Text(
                      items[1],
                      style: headingAppColorTextStyle
                    ),
                  ),
                ),
              ],
            ),
            Expanded(child: renderView(selectedItem, message))
          ],
        ),
      ),
    );
  }

  renderView(selectedItem, messageTextBox){
    if(selectedItem == items[0]){
      return ListView(
          padding: EdgeInsets.all(10),
          children: [
            SizedBox(height: 20,),
            Text('Here To Help', style: headingSmallBlackStyle,),
            SizedBox(height: 20,),
            Row(
              children: [
                Image.asset('assets/help-lady168186.png'),
                SizedBox(width: 20,),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Need Instant Help', style: headingSmallBlackStyle,),
                    SizedBox(height: 5),
                    Text('LIVE Chat now with our experts'),
                    SizedBox(height: 5),
                    Text('10 AM - 6 PM, Mon-Sat'),
                    SizedBox(height: 10,),
                    GestureDetector(
                      onTap:() { },
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Container(
                          width: 120,
                          color: greenBtn,
                          height: 40,
                          child: Center(child: Text('Chat Now', style: smallWhiteTextStyle)),
                        ),
                      ),
                    ),
                  ],
                )
              ],
            ),
            SizedBox(height: 20,),
            Row(
              children: [
                AssetImageWidget(image: 'assets/email_open.svg', color: black),
                SizedBox(width: 20,),
                Text('info@matchfinder.in', style: headingSmallBlackStyle,),
              ],
            ),
            SizedBox(height: 10,),
            Row(
              children: [
                AssetImageWidget(image: 'assets/call.svg', color: black),
                SizedBox(width: 20,),
                Text('09394950001', style: headingSmallBlackStyle,),
              ],
            ),
            SizedBox(height: 30,),
            Text('Hyderabad', style: headingSmallBlackStyle,),
            SizedBox(height: 10,),
            Text('Call us on 040-30911272'),
            SizedBox(height: 10,),
            Text('Walk-in support address', style: headingSmallBlackStyle,),
            SizedBox(height: 10,),
            Text('Matchfinder Online Services Pvt Ltd,'),
            SizedBox(height: 10,),
            Text('Flat no 101, H No 5-679, 5-682, Gokul Plots,'),
            SizedBox(height: 10,),
            Text('Venkataramana Colony, Hafeezpet, Hyderabad,'),
            SizedBox(height: 10,),
            Text('500085'),
          ],
        );
    }
    else if(selectedItem == items[1]){
      return ListView(
        padding: EdgeInsets.all(10),
          children: [
            Text('Your Feedback Matters', style: headingSmallBlackStyle,),
            SizedBox(height: 20,),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  width: MediaQuery.of(context).size.width * 0.4,
                    child: Text('Your Problem Type', style: headingSmallBlackStyle,)
                ),
                Container(
                  width: MediaQuery.of(context).size.width * 0.45,
                  child: CustomDropDown(
                    hint: 'From',
                    value: selectedProblem,
                    items: dropdownItems,
                    validator: (value) {
                      if (value == null && value != "0") {
                        return '*Required';
                      }
                      return null;
                    },
                    onChanged: (value) {
                      setState(() {
                        selectedProblem = value;
                      });
                    },
                  ),
                ),
              ],
            ),
            SizedBox(height: 20,),
            Text('Problem Description', style: headingSmallBlackStyle,),
            SizedBox(height: 20,),
            messageTextBox,
            SizedBox(height: 20,),
            GestureDetector(
              onTap:() { },
              child: Align(
                alignment: Alignment.center,
                child: Container(
                  width: 150,
                  color: greenBtn,
                  height: 50,
                  child: Center(child: Text('Post', style: headingWhiteTextStyle)),
                ),
              ),
            ),
            SizedBox(height: 20,),
            Text('Previous Complaints', style: headingSmallBlackStyle,),
            SizedBox(height: 20,),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Text('Complaint', style: headingSmallBlackStyle,),
                Text('Log Time', style: headingSmallBlackStyle,),
              ],
            ),
            ListView.builder(
              shrinkWrap: true,
              primary: false,
              itemCount: complaints.length,
                itemBuilder: (context, index){
                return Container(
                  padding: EdgeInsets.only(top: 10, bottom: 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Text(complaints[index].text),
                      Text(getDateFormattedAsDDMMYYYYHHMM(DateTime.parse(complaints[index].createdOn))),
                    ],
                  ),
                );
                })
          ],
      );
    }
  }
}
