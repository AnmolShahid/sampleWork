import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker_gallery_camera/image_picker_gallery_camera.dart';
import 'package:matchfinder/const/const.dart';
import 'package:matchfinder/const/general_methods.dart';
import 'package:matchfinder/utils/style.dart';
import 'package:matchfinder/widgets/show_dialog.dart';
import 'package:matchfinder/widgets/text_field.dart';
import '../../utils/appBar.dart';

class AccountSettings extends StatefulWidget {
  @override
  _AccountSettingsState createState() => _AccountSettingsState();
}

class _AccountSettingsState extends State<AccountSettings> {
  List<String> options = ['Select a reason', 'I found my partner through Matchfinder', 'I found my partner through other source', 'Matchfinder services are not helpful', 'My partner search is put on hold'];
  String selectedOption = '';
  bool showHoroscope = false;

  @override
  Widget build(BuildContext context) {
    var screenSize = MediaQuery.of(context).size;

    return Scaffold(
        appBar: AppBarWidget(
          heading: 'Account Settings',
          showIcon: true,
        ),
        body: Container(
          padding: EdgeInsets.all(20),
          child: ListView(
            children: [
              Text(
                'Activate or Inactive',
                style: headingBlackStyle,
              ),
              SizedBox(
                height: 10,
              ),
              Text('Your profile is currently Active'),
              SizedBox(
                height: 20,
              ),
              GestureDetector(
                onTap: () {
                  showAlertDialog(context, screenSize, 'Delete Profile', 380.0,
                      onSave: (){
                        Navigator.pop(context);
                      });
                },
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Container(
                    width: screenSize.width * 0.4,
                    color: greenBtn,
                    height: 50,
                    child: Center(
                        child: Text('Deactivate', style: smallWhiteTextStyle)),
                  ),
                ),
              ),
              SizedBox(
                height: screenSize.width * 0.4,
              ),
              Text(
                'Your Profile Settings',
                style: headingBlackStyle,
              ),
              SizedBox(
                height: 10,
              ),
              Row(
                children: [
                  Checkbox(
                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    value: showHoroscope,
                    onChanged: (val) {
                      setState(() {
                        showHoroscope = !showHoroscope;
                      });
                    },
                  ),
                  SizedBox(width: 15,),
                  Text('Show Horoscope to Profile Visitors (What\'s this?)'),
                ],
              ),
              SizedBox(
                height: 10,
              ),
              GestureDetector(
                onTap: () {},
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Container(
                    width: screenSize.width * 0.4,
                    color: greenBtn,
                    height: 50,
                    child: Center(
                        child: Text('Save Settings', style: smallWhiteTextStyle)),
                  ),
                ),
              ),
            ],
          ),
        )
    );
  }

  showAlertDialog(BuildContext context, screenSize, String btnText, height, {Function onSave, Map params}) async {

    return await showGeneralDialog(
        barrierColor: Colors.black.withOpacity(0.5),
        transitionBuilder: (context, a1, a2, widget) {
          return StatefulBuilder(builder: (context, setState) {
            final curvedValue = Curves.easeInOutBack.transform(a1.value) - 1.0;
            return Transform(
              transform: Matrix4.translationValues(0.0, curvedValue * 200, 0.0),
              child: Opacity(
                opacity: a1.value,
                child: AlertDialog(
                  // shape: OutlineInputBorder(
                  //     borderRadius: BorderRadius.circular(16.0)),
                  content: Container(
                    height: height,
                    width: screenSize.width * 0.95,
                    child: new ListView(
                      padding: EdgeInsets.all(0),
                      children: <Widget>[
                        ListView(
                          shrinkWrap: true,
                          primary: false,
                          children: <Widget>[
                            Text(
                                'Delete Profile',
                                style: headingBlackStyle
                            ),
                            ListView.builder(
                                shrinkWrap: true,
                                primary: false,
                                itemCount: options.length,
                                itemBuilder: (context, index){
                                  return Container(
                                    child: Row(
                                      children: [
                                        Radio(
                                          value: options[index],
                                          groupValue: selectedOption,
                                          activeColor: appColor,
                                          onChanged: (String value) {
                                            setState(() {
                                              selectedOption = options[index];
                                            });
                                          },
                                        ),
                                        Text(options[index], style: TextStyle(fontSize: 14),),
                                      ],
                                    ),
                                  );
                                })
                          ],
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            GestureDetector(
                              onTap: onSave,
                              child: Container(
                                width: screenSize.width * 0.3,
                                color: greenBtn,
                                height: 50,
                                child: Center(child: Text(btnText, style: smallWhiteTextStyle)),
                              ),
                            ),
                            GestureDetector(
                              onTap: () => Navigator.pop(context),
                              child: Container(
                                width: screenSize.width * 0.3,
                                color: redBtn,
                                height: 50,
                                child: Center(child: Text('Cancel', style: smallWhiteTextStyle)),
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                ),
              ),
            );
          });
        },
        transitionDuration: Duration(milliseconds: 200),
        barrierDismissible: true,
        barrierLabel: '',
        context: context,
        pageBuilder: (context, animation1, animation2) {});
  }
}
