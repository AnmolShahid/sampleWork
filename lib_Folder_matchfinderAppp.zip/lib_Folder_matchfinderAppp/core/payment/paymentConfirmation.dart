import 'package:flutter/material.dart';
import 'package:flutter_credit_card/credit_card_form.dart';
import 'package:flutter_credit_card/credit_card_model.dart';
import 'package:flutter_credit_card/credit_card_widget.dart';
import 'package:matchfinder/const/general_methods.dart';
import 'package:matchfinder/core/home/bottom_bar.dart';
import 'package:matchfinder/core/home/home.dart';
import 'package:matchfinder/utils/style.dart';
import 'package:matchfinder/widgets/image_widget.dart';
import 'package:matchfinder/widgets/text_field.dart';
import '../../utils/custom_expansion_tile.dart' as custom;
import 'package:matchfinder/const/const.dart';

class PaymentConfirmation extends StatefulWidget {

  var amount;
  PaymentConfirmation(this.amount);
  @override
  _PaymentConfirmationState createState() => _PaymentConfirmationState();
}

class _PaymentConfirmationState extends State<PaymentConfirmation> {

  List<String> _paymentOptions = ['Debit Card', 'Net Banking', 'UPI', 'Paytm'];
  List<String> _paymentIcons = ['credit_card.svg', 'globe_icon.png', 'upi_icon.png', 'paytm.svg'];
  List<String> _banksList = ['HDFC BANK', 'ICICI BANK', 'AXIS BANK', 'State Bank of India', 'IDBI BANK', 'Punjab national Bank'];
  TextEditingController accountNo = TextEditingController();
  String cardNumber = '';
  String expiryDate = '';
  String cardHolderName = '';
  String cvvCode = '';
  bool isCvvFocused = false;
  String _selectedBank = "1";
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    _selectedBank = _banksList[0];
  }

  Widget _myRadioButton({String value, Function onChanged}) {
    return Radio(
      hoverColor: appColor,
      focusColor: appColor,
      activeColor: appColor,
      groupValue: _selectedBank,
      value: value,
      onChanged: onChanged,
    );
  }

  @override
  Widget build(BuildContext context) {

    var screenSize = MediaQuery.of(context).size;

    Widget getTitleRow(index){
      return Row(
        children: <Widget>[
          _paymentIcons[index].contains('svg') ? AssetImageWidget(image: 'assets/'+_paymentIcons[index]) : Image.asset('assets/'+_paymentIcons[index], width: 30, height: 30,),
          SizedBox(width: 10,),
          Text(_paymentOptions[index]),
        ],
      );
    }

    var debitCard = custom.ExpansionTile(
      headerBackgroundColor: white,
      initiallyExpanded: false,
      iconColor: Colors.white,
      title: getTitleRow(0),
      trailing: Icon(Icons.keyboard_arrow_down),
      children: <Widget>[
        CreditCardWidget(
          cardBgColor: appColor,
          cardNumber: cardNumber,
          expiryDate: expiryDate,
          cardHolderName: cardHolderName,
          cvvCode: cvvCode,
          showBackView: isCvvFocused,
          obscureCardNumber: true,
          obscureCardCvv: true,
        ),
        CreditCardForm(
          formKey: formKey,
          obscureCvv: true,
          obscureNumber: true,
          cardNumber: cardNumber,
          cvvCode: cvvCode,
          cardHolderName: cardHolderName,
          expiryDate: expiryDate,
          themeColor: Colors.blue,
          cardNumberDecoration: const InputDecoration(
            border: OutlineInputBorder(),
            labelText: 'Number',
            hintText: 'XXXX XXXX XXXX XXXX',
          ),
          expiryDateDecoration: const InputDecoration(
            border: OutlineInputBorder(),
            labelText: 'Expired Date',
            hintText: 'XX/XX',
          ),
          cvvCodeDecoration: const InputDecoration(
            border: OutlineInputBorder(),
            labelText: 'CVV',
            hintText: 'XXX',
          ),
          cardHolderDecoration: const InputDecoration(
            border: OutlineInputBorder(),
            labelText: 'Card Holder',
          ),
          onCreditCardModelChange: onCreditCardModelChange,
        ),
        Center(
          child: Container(
            margin: EdgeInsets.only(top: 10, bottom: 20),
            height: 50,
            width: 200,
            child: RaisedButton(
              shape: RoundedRectangleBorder(
                borderRadius:
                BorderRadius.circular(
                    10.0),
              ),
              color: appColor,
              onPressed: () async {
                // if (formKey.currentState.validate()) {
                //   print('valid!');
                // } else {
                //   print('invalid!');
                // }
                changeScreen(context, BottomBar());
              },
              child: Text('Validate',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 14)),
            ),
          ),
        ),
      ],
    );

    var netBanking = custom.ExpansionTile(
        headerBackgroundColor: white,
        iconColor: Colors.white,
        title: getTitleRow(1),
        trailing: Icon(Icons.keyboard_arrow_down),
        children: [
          Text('Popular Banks', textAlign: TextAlign.start,),
          SizedBox(height: 10),
          GridView.builder(
              padding: EdgeInsets.all(10),
              shrinkWrap: true,
              itemCount: _banksList.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  childAspectRatio: (screenSize.height) * 0.00125),
              itemBuilder: (context, index) {
                return Container(
                  decoration: BoxDecoration(
                    border: Border.all(width: 1.00, color: greyColor),
                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                  ),
                  padding: const EdgeInsets.all(15.0),
                  margin: const EdgeInsets.all(10.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 30,
                        height: 10,
                        child: Theme(
                          data: Theme.of(context).copyWith(
                              unselectedWidgetColor:
                              appColor),
                          child: _myRadioButton(
                            value: _banksList[index],
                            onChanged: (item) {
                              setState(() {
                                _selectedBank = item;
                              });
                            },
                          ),
                        ),
                      ),
                      SizedBox(height: 10),
                      GestureDetector(
                          onTap: () {
                            setState(() {
                              _selectedBank = _banksList[index];
                            });
                          },
                          child: Text(_banksList[index],
                              textAlign: TextAlign.center,
                              style:
                              TextStyle(fontSize: 12))),
                    ],
                  ),
                );
              }),
          Container(
            padding: EdgeInsets.only(left: 15, right: 15),
            child: TextFieldCustom(
              controller: accountNo,
              style: miniGreyTextStyle,
              labelText: _selectedBank,
              inputType: TextInputType.text,
              validator: (value) {
                if (value.isEmpty) {
                  return 'Please enter Account No';
                }
                return null;
              },
            ),
          ),
          Center(
            child: Container(
              margin: EdgeInsets.only(top: 10, bottom: 20),
              height: 50,
              width: 200,
              child: RaisedButton(
                shape: RoundedRectangleBorder(
                  borderRadius:
                  BorderRadius.circular(
                      10.0),
                ),
                color: appColor,
                onPressed: () async {

                },
                child: Text('Next',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 14)),
              ),
            ),
          ),
          Text('Total Payable: '+widget.amount,
              style: miniGreyTextStyle),
          SizedBox(height: 20.0),
        ]);

    var upi = custom.ExpansionTile(
        headerBackgroundColor: white,
        iconColor: Colors.white,
        title: getTitleRow(2),
        trailing: Icon(Icons.keyboard_arrow_down),
        children: [

        ]);

    var paytm = custom.ExpansionTile(
        headerBackgroundColor: white,
        iconColor: Colors.white,
        title: getTitleRow(3),
        trailing: Icon(Icons.keyboard_arrow_down),
        children: [

        ]);

    Widget FormUI() {
      return ListView(
        shrinkWrap: true,
        physics: ScrollPhysics(),
        padding: EdgeInsets.only(left: 10.0, right: 10.0),
        children: <Widget>[
          SizedBox(height: 10.0),
          debitCard,
          SizedBox(height: 20.0),
          netBanking,
          SizedBox(height: 20.0),
          upi,
          SizedBox(height: 20.0),
          paytm,
          SizedBox(height: 20.0),
        ],
      );
    }

    return Scaffold(
        resizeToAvoidBottomInset: true,
        backgroundColor: white,
        appBar: AppBar(
          shadowColor: white,
          backgroundColor: appColor,
          // centerTitle: true,
          iconTheme: IconThemeData(
            color: Colors.white,
          ),
          title: Text('Payment Options', style: TextStyle(color: Colors.white),)
        ),
        body: Container(
            child: FormUI()
        )
    );
  }

  void onCreditCardModelChange(CreditCardModel creditCardModel) {
    setState(() {
      cardNumber = creditCardModel.cardNumber;
      expiryDate = creditCardModel.expiryDate;
      cardHolderName = creditCardModel.cardHolderName;
      cvvCode = creditCardModel.cvvCode;
      isCvvFocused = creditCardModel.isCvvFocused;
    });
  }
}
