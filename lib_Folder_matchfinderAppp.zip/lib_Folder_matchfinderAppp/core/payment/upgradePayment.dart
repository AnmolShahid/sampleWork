import 'dart:convert';

import 'package:carousel_slider/carousel_slider.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:matchfinder/Model/packages.dart';
import 'package:matchfinder/Model/plans.dart';
import 'package:cookie_jar/cookie_jar.dart';
import 'package:dio_cookie_manager/dio_cookie_manager.dart';
import 'package:matchfinder/const/general_methods.dart';
import 'package:matchfinder/core/home/home.dart';
import 'package:matchfinder/const/const.dart';
import 'package:matchfinder/core/payment/paymentConfirmation.dart';
import 'package:matchfinder/model/profile_list.dart';
import 'package:matchfinder/utils/function.dart';
import 'package:matchfinder/utils/url.dart';

class UpgradePayment extends StatefulWidget {
  @override
  _UpgradePaymentState createState() => _UpgradePaymentState();
}

class _UpgradePaymentState extends State<UpgradePayment> {
  ScrollController _controller;
  String packageTitle = 'Silver';
  String packagePrice = '';
  List<String> check = ['N', 'N', 'N'];
  String cartcurrency;
  double totalcartprice = 0;
  List<Plans> plans = List<Plans>();
  List<Packages> packages = List<Packages>();
  List<Items> item = List<Items>();
  List<dynamic> planList = [];
  List<dynamic> profileList = [];
  List<dynamic> addonList = [];
  double total = 0;
  var selectedTitle = '';
  var queryString = "";
  int _counter = 0;

  CarouselController crscontroller = CarouselController();

  List<bool> isCheck = new List<bool>();

  List<Result> profileListResults;

  _scrollListener() {
    setState(() {});
  }

  @override
  void initState() {
    _controller = ScrollController();
    _controller.addListener(_scrollListener);

    // TODO: implement initState
    super.initState();

    getData();
    setState(() {});
  }

  bool isLoading = false;
  bool dataLoading = false;

  // getPlansData() async {
  //   try {
  //     var value = getSession();
  //     if (value != null) {
  //       Response response = await getPlans();
  //       if (await response.data != null) {
  //         planList = await response.data['plans'];
  //         profileList = await response.data['result'];
  //         print('profile list check');
  //         print(profileList);
  //       }
  //     } else {
  //       print('No cache value');
  //       Navigator.pop(context);
  //     }
  //   } catch (e) {}
  // }

  getPhotos() async {
    try {
      var value = getSession();
      if (value != null) {
        Response response = await getLoadingPhoto();
        if (await response.data != null) {
          // print(response.data);

          //   planList =  await response.data['plans'];

        }
      } else {
        print('No cache value');
        Navigator.pop(context);
      }
    } catch (e) {}
  }

  getData() async {
    Dio dio = Dio();

    //ProfileList profileList=ProfileList.fromJson(map);
    //profileListResults=profileList.result;

    try {
      setState(() {
        isLoading = true;
      });
      var value = getSession();
      if (value != null) {
        Response d = await getPlans();
        // Response v = await getLoadingPhoto();
        // print(v.data);
        if (await d.data != null) {
          planList = await d.data['plans'];
          selectedTitle = planList[0][1][0];
          profileList = await d.data['result'];
          // print(profileList);
          addonList = await d.data['addons'];
          cartcurrency = await d.data['currency'] ?? "";
          isCheck = List.filled(addonList.length, false);
          // print(addonList);
          setState(() {
            isLoading = false;
          });
        }
      } else {
        print('No cache value');
        Navigator.pop(context);
      }
    } catch (e) {}
  }

  delete(String link, query) async {
    Dio dio = Dio();
    var cookieJar = CookieJar();
    dio.interceptors.add(CookieManager(cookieJar));
    Response response = await dio.post(link, queryParameters: query);
    // print(response);
    return response;
  }

  update(String link, query) async {
    Dio dio = Dio();
    var cookieJar = CookieJar();
    dio.interceptors.add(CookieManager(cookieJar));
    Response response = await dio.post(link, queryParameters: query);
    // print(response);
    return response;
  }

  void rebuildAllChildren(BuildContext context) {
    void rebuild(Element el) {
      el.markNeedsBuild();
      el.visitChildren(rebuild);
    }

    (context as Element).visitChildren(rebuild);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: appColor,
          elevation: 0.0,
          automaticallyImplyLeading: false,
          centerTitle: true,
          title: Text('Upgrade to Premium',
              style: TextStyle(fontSize: 16, color: Colors.white)),
          // leading: IconButton(
          //   icon: Icon(
          //     Icons.arrow_back,
          //     color: white,
          //   ),
          //   onPressed: () {
          //     changeScreen(context, Home());
          //   },
          // ),
        ),
        body: isLoading
            ? Center(child: CircularProgressIndicator())
            : SingleChildScrollView(
                child: Stack(
                children: [
                  Container(color: Colors.white),
                  // Container(
                  //     height: MediaQuery.of(context).size.height / 15,
                  //     color: appColor),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                        height: 50,
                        child: ListView.builder(
                            shrinkWrap: true,
                            padding: EdgeInsets.all(5),
                            scrollDirection: Axis.horizontal,
                            itemCount: planList.length,
                            itemBuilder: (BuildContext context, int index) {
                              return offersTab(planList[index][1][0], index);
                            }),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      CarouselSlider(
                        carouselController: crscontroller,
                        options: CarouselOptions(
                            height: 450.0,
                            onPageChanged: (v, index) {
                              setState(() {
                                selectedTitle = planList[v][1][0];
                                _counter = v;
                              });
                            }),
                        items: planList.map((i) {
                          // print(i);
                          return Builder(
                            builder: (BuildContext context) {
                              return Container(
                                  margin: EdgeInsets.all(10),
                                  height: 380,
                                  width: 350,
                                  decoration: BoxDecoration(
                                    color: getTileColor(i[4].toString()), //Colors.white,
                                    borderRadius: BorderRadius.circular(40),
                                    // border: Border.all(
                                    //     width: 1,
                                    //     color: Colors.white,
                                    //     style: BorderStyle.solid),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.grey.withOpacity(0.3),
                                        spreadRadius: 5,
                                        blurRadius: 7,
                                        offset: Offset(
                                            0, 3), // changes position of shadow
                                      ),
                                    ],
                                  ),
                                  child: Container(
                                      child: Stack(
                                    children: [
                                      // header
                                      Align(
                                          alignment: Alignment.topCenter,
                                          child: Container(
                                              padding: EdgeInsets.all(15),
                                              child: Column(
                                                children: [
                                                  Text(i[1],
                                                      style: TextStyle(
                                                          fontSize: 14)),
                                                  SizedBox(
                                                    height: 30,
                                                  ),
                                                  Padding(
                                                    padding: const EdgeInsets.only(left: 50, right: 50),
                                                    child: Divider(
                                                      height: 2,
                                                      thickness: 2,
                                                    ),
                                                  ),
                                                ],
                                              ))),
                                      // body
                                      Align(
                                        alignment: Alignment.center,
                                        child: Container(
                                            padding: EdgeInsets.all(25),
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                Text(
                                                  i[3].toString() +
                                                      ' ' +
                                                      i[4].toString(),
                                                  style: TextStyle(
                                                      fontSize: 36,
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                                SizedBox(
                                                  height: 5,
                                                ),
                                                Text(
                                                    i[3].toString() +
                                                        ' ' +
                                                        i[4].toString() +
                                                        ' per month',
                                                    style: TextStyle(
                                                        fontSize: 14)),
                                                SizedBox(
                                                  height: 10,
                                                ),
                                                Container(
                                                  height: 150,
                                                  child: ListView.builder(
                                                      itemCount: i[2].length,
                                                      primary: false,
                                                      itemBuilder:
                                                          (BuildContext context,
                                                              int ii) {
                                                        return Row(
                                                          children: [
                                                            Icon(
                                                              Icons.check,
                                                              color: i[2][ii]
                                                                          [1] ==
                                                                      'Y'
                                                                  ? appColor
                                                                  : Colors
                                                                      .white,
                                                              size: 10,
                                                            ),
                                                            SizedBox(
                                                              width: 5,
                                                            ),
                                                            Text(
                                                                i[2][ii][0]
                                                                    .toString(),
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        14)),
                                                          ],
                                                        );
                                                      }),
                                                )
                                              ],
                                            )), // Your fixed Footer here,
                                      ),
                                      // footer
                                      Align(
                                        alignment: Alignment.bottomCenter,
                                        child: Container(
                                          padding: EdgeInsets.all(20),
                                          child: MaterialButton(
                                            onPressed: () async {
                                              isCheck = List.filled(
                                                  addonList.length, false);
                                              totalcartprice = 0;
                                              queryString =
                                                  i[0].toString() + ",";
                                              total =
                                                  double.parse(i[4].toString());
                                              display(_counter, total);
                                            },
                                            color: appColor,
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(23.0),
                                            ),
                                            child: Container(
                                              padding: EdgeInsets.symmetric(
                                                vertical: 12,
                                                horizontal: 40,
                                              ),
                                              child: Text('Continue',
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                      fontSize: 14,
                                                      color: Colors.white)),
                                            ),
                                          ),
                                        ), // Your fixed Footer here,
                                      ),
                                    ],
                                  )));
                            },
                          );
                        }).toList(),
                      ),
                      SizedBox(
                        height: 30,
                      ),
                      profileList == null || profileList.isEmpty
                          ? Container(
                              width: MediaQuery.of(context).size.width,
                              height: 215,
                              padding: EdgeInsets.only(left: 20, right: 20),
                              child: ListView.builder(
                                scrollDirection: Axis.horizontal,
                                itemCount: 1,
                                itemBuilder:
                                    (BuildContext context, int index) =>
                                        Padding(
                                  padding: const EdgeInsets.all(4.0),
                                  child: Card(
                                    child: Column(
                                      children: [
                                        Container(
                                          width: 150,
                                          height: 150,
                                          decoration: BoxDecoration(
                                              image: DecorationImage(
                                                  image: AssetImage(
                                                      "assets/sample_image.png"),
                                                  fit: BoxFit.fill)),
                                        ),
                                        Container(
                                            width: 150,
                                            color: Colors.grey[200],
                                            padding: EdgeInsets.all(5),
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                SizedBox(
                                                  height: 1,
                                                ),
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    Text('Sumera Raj, 20 Years',
                                                        style: TextStyle(
                                                            fontSize: 9)),
                                                  ],
                                                ),
                                                SizedBox(
                                                  height: 5,
                                                ),
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    Text('Hindu - Madiga',
                                                        style: TextStyle(
                                                            fontSize: 9)),
                                                  ],
                                                ),
                                              ],
                                            )),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            )
                          : Container(
                              width: MediaQuery.of(context).size.width,
                              height: 210,
                              padding: EdgeInsets.only(left: 20, right: 20),
                              child: ListView.builder(
                                scrollDirection: Axis.horizontal,
                                itemCount: profileList.length,
                                itemBuilder:
                                    (BuildContext context, int index) => Card(
                                  color: Colors.grey[200],
                                  child: Column(
                                    children: [
                                      Container(
                                        width: 150,
                                        height: 150,
                                        decoration: BoxDecoration(
                                            image: DecorationImage(
                                                image: NetworkImage(profileList[
                                                                    index]
                                                                ['thumbUrl']
                                                            .toString()
                                                            .isEmpty ||
                                                        profileList[index]
                                                                    ['thumbURL']
                                                                .toString() ==
                                                            null
                                                    ? 'https://eitrawmaterials.eu/wp-content/uploads/2016/09/person-icon.png'
                                                    : profileList[index]
                                                        ['thumbURL']),
                                                fit: BoxFit.cover)),
                                      ),
                                      Container(
                                          width: 150,
                                          // color: Colors.grey[200],
                                          padding: EdgeInsets.all(5),
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              SizedBox(
                                                height: 1,
                                              ),
                                              Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  Container(
                                                    // width: 70,
                                                    child: Text(
                                                        profileList[index]
                                                                ['firstName'] +
                                                            ', ' +
                                                            profileList[index]
                                                                ['ageStr'],
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        style: TextStyle(
                                                            fontSize: 9)),
                                                  ),
                                                ],
                                              ),
                                              SizedBox(
                                                height: 5,
                                              ),
                                              Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  Expanded(
                                                    // width: 70,
                                                    child: Text(
                                                        profileList[index]
                                                                ['religion'] +
                                                            ' - ' +
                                                            profileList[index]
                                                                ['caste'],
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        style: TextStyle(
                                                            fontSize: 9)),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          )),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                      SizedBox(
                        height: 20,
                      ),
                      Container(
                        padding: EdgeInsets.all(10),
                        alignment: Alignment.center,
                        child: Text(
                            'Contact Profiles Instantly after making the payment',
                            textAlign: TextAlign.center,
                            style: TextStyle(fontSize: 14)),
                      ),
                      SizedBox(
                        height: 30,
                      ),
                    ],
                  )
                ],
              )));
  }

  getTileColor(text){
    if(text == '100'){
      return lightGreen;
    }
    else if(text == '500'){
      return lightPurple;
    }
    else if(text == '800'){
      return lightPink;
    }
    else if(text == '2000'){
      return lightSkin;
    }
    else if(text == '4000'){
      return lightGrey;
    }
    else if(text == '6000'){
      return lightBlue;
    }
  }

  display(index, total) async {
    dataLoading = false;
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return StatefulBuilder(builder: (context, setState) {
            return Stack(children: [
              Positioned(
                  bottom: 0,
                  child: Container(
                      color: Colors.white,
                      height: 420,
                      width: MediaQuery.of(context).size.width,
                      child: Scaffold(
                          body: dataLoading == true
                              ? Center(child: CircularProgressIndicator())
                              : Column(
                                  children: [
                                    //header
                                    Align(
                                      alignment: Alignment.topLeft,
                                      child: Container(
                                          width:
                                              MediaQuery.of(context).size.width,
                                          padding: EdgeInsets.all(10),
                                          color: Colors.grey[200],
                                          height: 50,
                                          child: Text('Order Summary',
                                              style: TextStyle(fontSize: 18))),
                                    ),
                                    SizedBox(
                                      height: 10,
                                    ),
                                    //body
                                    Align(
                                      alignment: Alignment.center,
                                      child: Container(
                                        height: 350,
                                        width:
                                            MediaQuery.of(context).size.width,
                                        padding: EdgeInsets.all(10),
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Padding(
                                              padding: const EdgeInsets.only(left: 5.0, right: 5),
                                              child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    Text(
                                                        planList[index][1]
                                                            .toString(),
                                                        style: TextStyle(
                                                            fontFamily: 'Arial',
                                                            fontSize: 14)),
                                                    Text(
                                                        cartcurrency + '\ $total',
                                                        style: TextStyle(
                                                            fontFamily: 'Arial',
                                                            fontSize: 14,
                                                            fontWeight:
                                                                FontWeight.bold)),
                                                  ]),
                                            ),
                                            Divider(),
                                            // SizedBox(
                                            //   height: 10,
                                            // ),
                                            ListView.builder(
                                                shrinkWrap: true,
                                                itemCount: addonList.length,
                                                itemBuilder: (context, index) {
                                                  return CheckboxListTile(
                                                    title: Text(addonList[index]
                                                            [1]
                                                        .toString(), style: TextStyle(fontFamily: 'Arial', fontSize: 16),),
                                                    secondary: Padding(
                                                      padding: const EdgeInsets.only(left: 5.0),
                                                      child: Text(
                                                          addonList[index][2]
                                                                  .toString() +
                                                              addonList[index][3]
                                                                  .toString(),
                                                        style: TextStyle(fontFamily: 'Arial', fontSize: 16),),
                                                    ),
                                                    controlAffinity:
                                                        ListTileControlAffinity
                                                            .leading,
                                                    value: isCheck[index],
                                                    onChanged: (v) async {
                                                      isCheck[index] =
                                                          !isCheck[index];
                                                      if (isCheck[index]) {
                                                        queryString +=
                                                            addonList[index][0]
                                                                    .toString() +
                                                                ",";
                                                      } else {
                                                        queryString = queryString
                                                            .replaceFirst(
                                                                addonList[index]
                                                                            [0]
                                                                        .toString() +
                                                                    ",",
                                                                "");
                                                      }
                                                      v
                                                          ? totalcartprice +=
                                                              addonList[index]
                                                                  [3]
                                                          : totalcartprice -=
                                                              addonList[index]
                                                                  [3];
                                                      setState(() {});
                                                    },
                                                    activeColor:
                                                        Colors.transparent,
                                                    checkColor: Colors.green,
                                                    contentPadding:
                                                        EdgeInsets.all(0),
                                                  );
                                                }),
                                            Padding(
                                              padding: const EdgeInsets.only(left: 5.0, right: 5, top: 10),
                                              child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    Text('Total Amount',
                                                        style: TextStyle(
                                                            fontFamily: 'Arial',
                                                            fontSize: 16,
                                                            fontWeight:
                                                                FontWeight.w600)),
                                                    Text(
                                                        cartcurrency +
                                                            '\ ${total + totalcartprice}',
                                                        style: TextStyle(
                                                            fontFamily: 'Arial',
                                                            fontSize: 16,
                                                            fontWeight:
                                                                FontWeight.bold)),
                                                  ]),
                                            ),
                                            SizedBox(
                                              height: 20,
                                            ),
                                            Center(
                                              child: Container(
                                                height: 50,
                                                width: 200,
                                                child: RaisedButton(
                                                  shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            10.0),
                                                  ),
                                                  color: appColor,
                                                  onPressed: () async {
                                                    queryString =
                                                        queryString.substring(
                                                            0,
                                                            queryString.length -
                                                                1);
                                                    Response response =
                                                        await submitData(
                                                            UrlLinks.checkout, {
                                                      'addonno': queryString
                                                    });
                                                    // print('response.data');
                                                    // print(response.data);
                                                    var value = '$cartcurrency ${total + totalcartprice}';
                                                    changeScreen(context,
                                                        PaymentConfirmation(value));
                                                  },
                                                  child: Text('Proceed',
                                                      style: TextStyle(
                                                          color: Colors.white,
                                                          fontSize: 14)),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ))))
            ]);
          });
        });
  }

  Widget offersTab(String title, int index) {
    return GestureDetector(
      child: Container(
          margin: EdgeInsets.all(5),
          height: 30,
          width: 30,
          decoration: BoxDecoration(
              color: title == selectedTitle ? Colors.white : appColor,
              borderRadius: BorderRadius.circular(40),
              border: Border.all(
                  width: 1, color: appColor, style: BorderStyle.solid)),
          child: Center(
            child: Text(
              title,
              style: TextStyle(
                color: title == selectedTitle ? Colors.black : Colors.white,
                fontSize: 14,
              ),
            ),
          )),
      onTap: () {
        crscontroller.animateToPage(index);
        selectedTitle = title;
        setState(() {});
      },
    );
  }
}
