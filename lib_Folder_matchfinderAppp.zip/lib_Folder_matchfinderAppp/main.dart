import 'package:flutter/material.dart';
import 'package:matchfinder/const/const.dart';
import 'package:matchfinder/utils/initialize_basic_data.dart';
import './core/intro_screen/splash.dart';
import 'package:responsive_framework/responsive_wrapper.dart';

void main() {
  initializeBasicData();
  runApp(MyApp());
}


class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

    return MaterialApp(
      home: SplashScreen(),
      debugShowCheckedModeBanner: false,
      title: 'Matchfinder',
      theme: ThemeData(
        fontFamily: "Poppins-Medium",
        primaryColor: Colors.white,
        accentColor: appColor,
        iconTheme: IconThemeData(
          color: Colors.white,),
      ),
      builder: (context, widget) => ResponsiveWrapper.builder(widget,
          maxWidth: 1200,
          minWidth: 480,
          defaultScale: true,
          breakpoints: [
            ResponsiveBreakpoint.resize(480, name: MOBILE),
            ResponsiveBreakpoint.autoScale(800, name: TABLET),
            ResponsiveBreakpoint.resize(1000, name: DESKTOP),
          ],
          background: Container(color: Color(0xFFF5F5F5),)),
    );
  }
}


//
// class MyApp extends StatelessWidget {
//   // This widget is the root of your application.
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       debugShowCheckedModeBanner: false,
//       title: 'Matchfinder',
//       home: MainScreen(),
//       theme: ThemeData(
//             fontFamily: "Poppins-Medium",
//             primaryColor: Colors.white,
//             accentColor: appColor,
//             iconTheme: IconThemeData(
//               color: Colors.white,
//             ),
//       ),
//     );
//   }
// }
