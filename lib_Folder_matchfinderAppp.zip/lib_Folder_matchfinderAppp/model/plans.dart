class Plans{
  String addon;
  String id;
  String title;
  String price;
  String status;

  Plans({
  this.addon,
  this.id,
  this.price,
  this.status,
  this.title
  });
}