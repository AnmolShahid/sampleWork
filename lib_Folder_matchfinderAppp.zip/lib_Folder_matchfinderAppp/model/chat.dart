class Chat {
  Chat(
      {this.id,
      this.userId1,
      this.userId2,
      this.userName1,
      this.userName2,
        this.userAddress1,
        this.userAddress2,
      this.image1,
      this.image2,
      this.createdOn,
      this.isOnline,
      this.lastMsg,
      this.unread});

  String id;
  String lastMsg;
  bool unread;
  String userId1;
  String userId2;
  String userAddress1;
  String userAddress2;
  String userName1;
  String userName2;
  String image1;
  String image2;
  bool isOnline;
  String createdOn;

  Chat.fromMap(json, id)
      : id = id,
        lastMsg = json['lastMsg'].toString(),
        unread = json['unread'],
        userId1 = json['userId1'].toString(),
        userId2 = json['userId2'].toString(),
        userName1 = json['userName1'].toString(),
        userName2 = json['userName2'].toString(),
        userAddress1 = json['userAddress1'].toString(),
        userAddress2 = json['userAddress2'].toString(),
        image1 = json['userImage1'].toString(),
        image2 = json['userImage2'].toString(),
        isOnline = json['isOnline'],
        createdOn = json['createdOn'].toString();
}

Chat JsonToChat(
    json, id, userId1, userName1, userImage1, userId2, userName2, userImage2) {
  Chat obj = new Chat();

  obj.id = id;
  obj.userId1 = userId1;
  obj.userName1 = userName1;
  obj.image1 = userImage1;
  obj.userId2 = userId2;
  obj.userName2 = userName2;
  obj.image2 = userImage2;
  obj.lastMsg = json['lastMsg'].toString();
  obj.unread = json['unread'];
  obj.isOnline = json['isOnline'];
  obj.createdOn = json['createdOn'].toString();

  return obj;
}
