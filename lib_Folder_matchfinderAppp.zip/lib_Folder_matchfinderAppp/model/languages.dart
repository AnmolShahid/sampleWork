// To parse this JSON data, do
//
//     final languages = languagesFromJson(jsonString);
import 'dart:convert';
class Languages {
  Languages({
    this.mothertongue,
  });

  List<List<String>> mothertongue;

  factory Languages.fromJson(Map<String, dynamic> json) => Languages(
    mothertongue: List<List<String>>.from(json["mothertongue"].map((x) => List<String>.from(x.map((x) => x)))),
  );

}