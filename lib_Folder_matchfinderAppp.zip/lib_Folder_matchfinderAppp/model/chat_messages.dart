class ChatMsg {
  ChatMsg(
      {this.id,
      this.image,
      this.text,
      this.status,
      this.messageFrom,
      this.messageTo,
      this.createdOn});

  String id;
  String text;
  String status;
  String image;
  String messageTo;
  String messageFrom;
  String createdOn;

  ChatMsg.fromMap(json, id)
      : id = id,
        text = json['text'].toString(),
        status = json['status'].toString(),
        image = json['image'].toString(),
        messageFrom = json['messageFrom'].toString(),
        messageTo = json['messageTo'].toString(),
        createdOn = json['createdOn'].toString();
}
