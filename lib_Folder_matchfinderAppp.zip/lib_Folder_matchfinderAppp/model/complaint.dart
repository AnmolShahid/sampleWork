import 'dart:convert';

class Complaint {
  Complaint({
    this.text,
    this.createdOn,
  });

  String text;
  String createdOn;

  factory Complaint.fromJson(Map<String, dynamic> json) => Complaint(
    text: json["text"].toString(),
    createdOn: json["createdOn"].toString(),
  );

}