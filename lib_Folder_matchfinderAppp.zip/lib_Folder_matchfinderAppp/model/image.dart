class Images{
  String photoUrl;
  String photoId;
  String profileImage;
  String caption;
  String proId;

  Images({
   this.photoId,
   this.photoUrl,
   this.caption,
   this.profileImage,
   this.proId
  });
}