
import 'dart:convert';

class ProfileList {
  ProfileList({
    this.result,
    this.plans,
    this.defaultplan,
    this.resultcount,
  });

  List<Result> result;
  List<List<dynamic>> plans;
  int defaultplan;
  int resultcount;

  factory ProfileList.fromJson(Map<String, dynamic> json) => ProfileList(
    result: List<Result>.from(json["result"].map((x) => Result.fromJson(x))),
    plans: List<List<dynamic>>.from(json["plans"].map((x) => List<dynamic>.from(x.map((x) => x)))),
    defaultplan: json["defaultplan"],
    resultcount: json["resultcount"],
  );

  Map<String, dynamic> toJson() => {
    "result": List<dynamic>.from(result.map((x) => x.toJson())),
    "plans": List<dynamic>.from(plans.map((x) => List<dynamic>.from(x.map((x) => x)))),
    "defaultplan": defaultplan,
    "resultcount": resultcount,
  };
}

class Result {
  Result({
    this.profileNo,
    this.profileId,
    this.gender,
    this.profilePhoto,
    this.caste,
    this.religion,
    this.firstName,
    this.occupation,
    this.education,
    this.specialOccupation,
    this.specialDegree,
    this.city,
    this.state,
    this.country,
    this.visa,
    this.maritalStatus,
    this.motherTongue,
    this.profileCreatedBy,
    this.thumbUrl,
    this.photosProtected,
    this.validPhotos,
    this.profileStatus,
    this.blockedProfiles,
    this.userFld7,
    this.ageStr,
    this.heightStr,
    this.salaryStr,
    this.photoKey,
    this.loginTime,
    this.abtMyself,
    this.abtFamily,
    this.abtPartner,
  });

  int profileNo;
  String profileId;
  Gender gender;
  int profilePhoto;
  String caste;
  Religion religion;
  String firstName;
  String occupation;
  String education;
  String specialOccupation;
  String specialDegree;
  String city;
  dynamic state;
  dynamic country;
  dynamic visa;
  MaritalStatus maritalStatus;
  dynamic motherTongue;
  ProfileCreatedBy profileCreatedBy;
  String thumbUrl;
  PhotosProtected photosProtected;
  String validPhotos;
  dynamic profileStatus;
  dynamic blockedProfiles;
  int userFld7;
  String ageStr;
  String heightStr;
  String salaryStr;
  String photoKey;
  String loginTime;
  dynamic abtMyself;
  dynamic abtFamily;
  dynamic abtPartner;

  factory Result.fromJson(Map<String, dynamic> json) => Result(
    profileNo: json["profileNo"],
    profileId: json["profileId"],
    gender: genderValues.map[json["gender"]],
    profilePhoto: json["profilePhoto"],
    caste: json["caste"],
    religion: religionValues.map[json["religion"]],
    firstName: json["firstName"],
    occupation: json["occupation"] == null ? null : json["occupation"],
    education: json["education"] == null ? null : json["education"],
    specialOccupation: json["specialOccupation"] == null ? null : json["specialOccupation"],
    specialDegree: json["specialDegree"] == null ? null : json["specialDegree"],
    city: json["city"],
    state: json["state"],
    country: json["country"],
    visa: json["visa"],
    maritalStatus: maritalStatusValues.map[json["maritalStatus"]],
    motherTongue: json["motherTongue"],
    profileCreatedBy: profileCreatedByValues.map[json["profileCreatedBy"]],
    thumbUrl: json["thumbURL"],
    photosProtected: photosProtectedValues.map[json["photosProtected"]],
    validPhotos: json["validPhotos"],
    profileStatus: json["profileStatus"],
    blockedProfiles: json["blockedProfiles"],
    userFld7: json["userFld7"] == null ? null : json["userFld7"],
    ageStr: json["ageStr"],
    heightStr: json["heightStr"] == null ? null : json["heightStr"],
    salaryStr: json["salaryStr"] == null ? null : json["salaryStr"],
    photoKey: json["photoKey"],
    loginTime: json["loginTime"],
    abtMyself: json["abtMyself"],
    abtFamily: json["abtFamily"],
    abtPartner: json["abtPartner"],
  );

  Map<String, dynamic> toJson() => {
    "profileNo": profileNo,
    "profileId": profileId,
    "gender": genderValues.reverse[gender],
    "profilePhoto": profilePhoto,
    "caste": caste,
    "religion": religionValues.reverse[religion],
    "firstName": firstName,
    "occupation": occupation == null ? null : occupation,
    "education": education == null ? null : education,
    "specialOccupation": specialOccupation == null ? null : specialOccupation,
    "specialDegree": specialDegree == null ? null : specialDegree,
    "city": city,
    "state": state,
    "country": country,
    "visa": visa,
    "maritalStatus": maritalStatusValues.reverse[maritalStatus],
    "motherTongue": motherTongue,
    "profileCreatedBy": profileCreatedByValues.reverse[profileCreatedBy],
    "thumbURL": thumbUrl,
    "photosProtected": photosProtectedValues.reverse[photosProtected],
    "validPhotos": validPhotos,
    "profileStatus": profileStatus,
    "blockedProfiles": blockedProfiles,
    "userFld7": userFld7 == null ? null : userFld7,
    "ageStr": ageStr,
    "heightStr": heightStr == null ? null : heightStr,
    "salaryStr": salaryStr == null ? null : salaryStr,
    "photoKey": photoKey,
    "loginTime": loginTime,
    "abtMyself": abtMyself,
    "abtFamily": abtFamily,
    "abtPartner": abtPartner,
  };
}

enum Gender { M }

final genderValues = EnumValues({
  "M": Gender.M
});

enum MaritalStatus { SINGLE }

final maritalStatusValues = EnumValues({
  "Single": MaritalStatus.SINGLE
});

enum PhotosProtected { N, Y }

final photosProtectedValues = EnumValues({
  "N": PhotosProtected.N,
  "Y": PhotosProtected.Y
});

enum ProfileCreatedBy { RELATIVES, SELF, PARENTS }

final profileCreatedByValues = EnumValues({
  "Parents": ProfileCreatedBy.PARENTS,
  "Relatives": ProfileCreatedBy.RELATIVES,
  "Self": ProfileCreatedBy.SELF
});

enum Religion { HINDU }

final religionValues = EnumValues({
  "Hindu": Religion.HINDU
});

class EnumValues<T> {
  Map<String, T> map;
  Map<T, String> reverseMap;

  EnumValues(this.map);

  Map<T, String> get reverse {
    if (reverseMap == null) {
      reverseMap = map.map((k, v) => new MapEntry(v, k));
    }
    return reverseMap;
  }
}
