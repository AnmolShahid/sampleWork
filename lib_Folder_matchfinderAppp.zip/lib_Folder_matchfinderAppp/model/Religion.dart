class Religion {
  Religion({
    this.religion,
  });

  List<List<String>> religion;

  factory Religion.fromJson(Map<String, dynamic> json) => Religion(
    religion: List<List<String>>.from(json["religion"].map((x) => List<String>.from(x.map((x) => x)))),
  );

}