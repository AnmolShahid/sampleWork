import 'package:flutter/material.dart';
import 'package:matchfinder/const/const.dart';

class AppBarWidget extends StatelessWidget implements PreferredSizeWidget {
  String heading;
  bool showIcon;
  Color color;
  var actions;
  AppBarWidget({this.heading, this.showIcon = false, this.color, this.actions});

  @override
  Size get preferredSize => const Size.fromHeight(60);

  @override
  Widget build(BuildContext context) {
    return PreferredSize(
      child: AppBar(
          iconTheme: IconThemeData(color: appColor),
          shadowColor: color ?? appColor,
          backgroundColor: color ?? appColor,
          automaticallyImplyLeading: false,
          leading: showIcon
              ? IconButton(
                  icon: Icon(
                    Icons.arrow_back,
                    color: color == null ? white : greyColor,
                  ),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                )
              : null,
          title: Text(heading ?? '',
              style: TextStyle(fontSize: 20, color: Colors.white)),
          actions: actions ?? []),
    );
  }
}
