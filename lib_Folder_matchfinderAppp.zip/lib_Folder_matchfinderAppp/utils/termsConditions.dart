import 'package:flutter/material.dart';
import 'package:matchfinder/utils/style.dart';
import 'package:matchfinder/const/const.dart';

class TermsConditions extends StatefulWidget {
  @override
  _TermsConditionsState createState() => _TermsConditionsState();
}

class _TermsConditionsState extends State<TermsConditions> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: HexColor('F1F1F1'),
      appBar: AppBar(
        shadowColor: appColor,
        backgroundColor: appColor,
        automaticallyImplyLeading: false,
        centerTitle: true,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: white,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Image.asset(
          'assets/logowhite.png',
          // width: 142,
          height: 50,
        ),
      ),
      body: Container(
        padding: EdgeInsets.symmetric(
          vertical: 15,
          horizontal: 20,
        ),
        child: SingleChildScrollView(
          child: Column(
            children: [
              // Text('About Matchfinder.in\n',
              //   style: smallAppColorTextStyle,
              //   textAlign: TextAlign.start,
              // ),
              RichText(
                text: TextSpan(
                  text:
                      'Matchfinder.in is an intermediary as defined under sub-clause (w) of Section 2 of the Information Technology Act, 2000. Visitors to matchfinder.in matrimonial website are granted a nonexclusive, limited license to use and access the content and services offered in accordance with these Terms and Conditions (the "License").'
                      'BY YOUR POSITIVE ACTS OF ACCESSING MATCHFINDER.IN, YOU AGREE TO BE BOUND BY THE TERMS AND CONDITIONS SET FORTH BELOW. IF YOU DO NOT AGREE WITH ANY OF THESE TERMS AND CONDITIONS, YOU SHOULD NOT ACCESS OR USE matchfinder.in. "matchfinder.in" is registered by Match Finder Online Services Private Limited directors/promoters under class 38,45 with Trademarks authorities in India.'
                      'This website - matchfinder.in - found at the uniform resource locator (URL) id - www.matchfinder.in - has been developed,promoted and maintained, by Matchfinder Online Services Private Limited. (hereinafter referred to as "Matchfinder matrimony"), which term shall, for the purposes hereof, be deemed to include its subsidiaries, affiliates, partners, shareholders, directors, executives, officers, employees, agents, attorneys, accountants and any person vested with any responsibility for any task relating to the affairs of the company), with its registered office at'
                      'MIG-125, KPHB Colony, Hyderabad,A.P-500072.\n\n',
                  style: miniGreyTextStyle,
                  children: <TextSpan>[
                    TextSpan(
                      text: 'Eligibility\n',
                      style: smallAppColorTextStyle,
                    ),
                    TextSpan(
                      text:
                          "Matchfinder matrimony shall act on the basis of the information that may be submitted by you, believing the same to be true and accurate even if the information is provided during the registration by your family, friends, relatives on your behalf under your express consent . Matchfinder matrimony is under no obligation to verify the accuracy or genuineness of the information submitted by you.\n"
                          "1.The minimum age for registering in matchfinder matrimony is 18 years for women and 21 years for men.\n"
                          "2.You represent and warrant that you have the right, authority and legal capability to enter into this Agreement and that you are neither prohibited nor disabled by any law in force from entering into a contract.\n"
                          "3.You have gone through the Terms and Conditions and agree to be bound by them.\n"
                          "4.If at any time Matchfinder matrimony, in its sole discretion, is of the opinion or has any reason to believe that You are not eligible to become a member or that you have made any misrepresentation about your eligibility, Matchfinder matrimony hereby reserves the right to forthwith terminate your membership and/or your right to use the services of Matchfinder matrimony without any refund of any monies paid to matchfinder matrimony.\n\n",
                      style: miniGreyTextStyle,
                    ),
                    TextSpan(
                      text: 'Communication\n',
                      style: smallAppColorTextStyle,
                    ),
                    TextSpan(
                      text:
                          "1. You hereby expressly solicit and invite Matchfinder matrimony and/or its authorized personnel to communicate to you through any telecom resources in the registered number provided by you to explain, explicate and clarify the various services provided by Matchfinder matrimony and to assist, aid or support you in availing the said services of Matchfinder matrimony.\n"
                          "2. By choosing to continue with registration on Matchfinder, you agree to receive transactional SMS and promotional SMS from Matchfinder. If at any time, you wish to discontinue receiving the communications (including, but not limited to emails, sms and phone calls) from matchfinder matrimony, you may by email to info@matchfinder.in to indicate the same to Matchfinder matrimony and/or its authorized personnel regarding such discontinuance and You hereby agree that, unless expressly communicated to You about discontinuing communications from Matchfinder matrimony to Matchfinder matrimony and/or its authorized personnel, it will be deemed to be that you want to continue and solicit and invite all such or other communications from Matchfinder matrimony.\n"
                          "3. You are representing that you or the mobile number submitted by you is not registered with the Do Not Disturb / National Customer Preference Register and/or you have already changed your registration suitably.\n"
                          "4. Further and in any event, you do hereby also unconditionally agree and undertake that this invitation and solicitation shall supersede any preferences set by you with or registration done with the Do Not Disturb ('DND Register')/ National Customer Preference Register ('NCPR'). Without prejudice to the aforesaid and in any event, by expressly inviting and soliciting the services from Matchfinder matrimony, you also unconditionally agree that your rights under the Telecom Commercial Communications Customer Preference Regulations, 2010 or any subsequent amendments thereto or under NCPR, are kept in abeyance or remain extinguished till you expressly communicate for discontinuation of relationship.\n"
                          "5. You also unconditionally agree to indemnify Matchfinder matrimony against all losses, damages, penalties, costs or consequences whether direct or indirect, that may arise out of any breach or violation of the aforesaid representation, commitment and undertaking.\n\n",
                      style: miniGreyTextStyle,
                    ),
                    TextSpan(
                      text: 'Trademarks and Site Content\n',
                      style: smallAppColorTextStyle,
                    ),
                    TextSpan(
                      text:
                          "Trademarks indicated on our site is the property of Matchfinder matrimony, or its subsidiaries, in India and other countries. Other Matchfinder matrimony graphics, logos, page headers, button icons, scripts, and service names are trademarks or trade address of Matchfinder matrimony or its subsidiaries. Matchfinder matrimony's trademarks and trade address may not be used in connection with any product or service that is not Matchfinder matrimony, in any manner that is likely to cause confusion among customers or in any manner that disparages or discredits Matchfinder matrimony. All other trademarks not owned by Matchfinder matrimony or its subsidiaries that appear on this site are the property of their respective owners, who may or may not be affiliated with, connected to, or sponsored by Matchfinder matrimony or its subsidiaries. You shall not use/copy/modify and reuse any CSS,site design,images in any format without the prior permission from Matchfinder matrimony.\n\n",
                      style: miniGreyTextStyle,
                    ),
                    TextSpan(
                      text: 'No Guarantee Matchmaking\n',
                      style: smallAppColorTextStyle,
                    ),
                    TextSpan(
                      text:
                          "Matchfinder matrimony doesn't assure that the registered users whether free/paid, will be able to find their match of interest. Matchfinder is only a online platform to help you in your partner search. We do not offer guarantee matchmaking services and the availability of matching profiles within a community.\n\n",
                      style: miniGreyTextStyle,
                    ),
                    TextSpan(
                      text: "Authenticity of Profiles.\n",
                      style: smallAppColorTextStyle,
                    ),
                    TextSpan(
                      text:
                          "Matchfinder matrimony does not authenticate, vet, screen, endorse or investigate any information or assertion comprised in the matrimonial listings, or any other content on the website, nor does it in any manner whatsoever certify or attest the same to be correct or true. It does not recommend matches and profiles in any manner, but an implied presumption is cast on the users / members that the information(s) furnished are exclusively / solely to curve out / frame a suitable profile for the purpose of matrimonial alliance and they are true and correct. All due diligence, effort and initiatives must be exercised by those wishing to use any information found on the website, and should take adequate precautions with the full and complete knowledge that all information contained in the matrimonial listings have been placed there directly by visitors to the website without any prior intimation, consent or verification of or by Matchfinder matrimony. Matchfinder matrimony advices its registered users to verify the authenticity of all the profile details provided in matchfinder.in before entering into marriage alliance.\n\n",
                      style: miniGreyTextStyle,
                    ),
                    TextSpan(
                      text: "Online Conduct.\n",
                      style: smallAppColorTextStyle,
                    ),
                    TextSpan(
                      text:
                          "You are responsible for the content and information [including profile and photograph] you post or transmit through Matchfinder matrimony's services. You will not post or transmit any content or information [in whatever form they may be contained] that is defamatory, blasphemous, abusive, obscene, sexually oriented, profane, intimidating, illegal or in violation of the rights of any person, including intellectual property rights. No content or information shall contain details or particulars of any of Matchfinder matrimony's competitors, including their contact details. Matchfinder matrimony has the right to suspend your profile without any prior notice. Matchfinder matrimony reserves the right to edit/delete your photo/horoscope/profile details if it's not a valid/clear/related one. Matchfinder matrimony reserves the right to modify your profile if any prohibitive or objectionable content is found, or in the case of your contact details being entered in irrelevant fields. Matchfinder matrimony may also modify the profile for other reasons not mentioned herewith.\n\n",
                      style: miniGreyTextStyle,
                    ),
                    TextSpan(
                      text: "Information loss or misuse.\n",
                      style: smallAppColorTextStyle,
                    ),
                    TextSpan(
                      text:
                          "Incase of any information/data loss related to registered Users in matchfinder.in due to any reason, Matchfinder matrimony will not be responsible for data/information recovery. All the information provided by Profiles including documents will be viewed/screened/modified(if required) by Matchfinder matrimony employees including Express Interest messages, Chat messages and any other information exchanged between two Profiles . Matchfinder matrimony facilitates 'Identity documents' sharing only to validate authenticity of Profiles between themselves.These identity documents can include your CASTE/EDUCATION/VISA and any such documents that proves your authenticity. Matchfinder matrimony is not responsible for any mis-use of your data or your documents by other registered Profiles.\n\n",
                      style: miniGreyTextStyle,
                    ),
                    TextSpan(
                      text: "Memberships.\n",
                      style: smallAppColorTextStyle,
                    ),
                    TextSpan(
                      text:
                          "Registration on Matchfinder is free. Registered users can purchase Add-Ons to contact profiles of their interest. Some of the Add-ons are Horoscope generation,Professional Services,Profile Highlighting feature.\n\n",
                      style: miniGreyTextStyle,
                    ),
                    TextSpan(
                      text: "Payments & Purpose of Payment Gateway.\n",
                      style: smallAppColorTextStyle,
                    ),
                    TextSpan(
                      text:
                          "We accept your payments through secured and trusted Payment Gateways. We don't support any other Payment mode currently. Payment gateways protect your Payment Card details or Net Banking details by encrypting sensitive information, such as credit card numbers, to ensure that information is passed securely between the customer and the merchant and also between merchant and the payment processor.\n\n",
                      style: miniGreyTextStyle,
                    ),
                    TextSpan(
                      text: "Refund & Cancellation Policy.\n",
                      style: smallAppColorTextStyle,
                    ),
                    TextSpan(
                      text:
                          "If you choose to terminate your Paid membership or request for refund of any Add-on that has been bought in matchfinder.in, the MEMBERSHIP/ADD-ON FEES ARE NOT REFUNDABLE under any circumstances. Your membership in the matchfinder service is for your sole, personal use. You may not authorize others to use your membership and you may not assign or transfer your account to any other person or entity.\n\n",
                      style: miniGreyTextStyle,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
