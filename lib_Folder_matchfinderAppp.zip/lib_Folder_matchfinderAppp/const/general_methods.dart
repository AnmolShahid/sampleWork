import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_picker_gallery_camera/image_picker_gallery_camera.dart';
import 'package:matchfinder/utils/style.dart';
import 'package:intl/intl.dart';
import 'const.dart';

displayError(String error) {
  return Column(
    children: [
      SizedBox(
        height: 15,
      ),
      Row(
        children: [
          Expanded(
            child: Text(
              error,
              style: miniRedTextStyle,
            ),
          ),
        ],
      ),
    ],
  );
}

void changeScreen(BuildContext context, Widget widget) {
  Navigator.push(context, MaterialPageRoute(builder: (context) => widget));
}

void changeScreenReplacement(BuildContext context, Widget widget) {
  Navigator.pushReplacement(
      context, MaterialPageRoute(builder: (context) => widget));
}

void changeScreenReplacementUtils(BuildContext context, Widget widget) {
  Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (BuildContext context) => widget),
          (route) => false);
}

Future getImageChoice({BuildContext context, Function cameraMethod, Function galleryMethod}) async {
  showDialog(
      context: context,
      builder: (context) {
        return Dialog(
          shape:
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          elevation: 16,
          child: Container(
            // decoration: DecorationBoxes.decorationSquareWithShadowWithNormalRadius(),
            padding: EdgeInsets.all(20),
            height: 150.0,
            width: MediaQuery
                .of(context)
                .size
                .width - 30,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Text(
                  "Camera or Gallery?",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                ),
                SizedBox(height: 10,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    RawMaterialButton(
                      onPressed: cameraMethod,
                      child: new Icon(
                        Icons.add_a_photo,
                        color: appColor,
                        size: 35.0,
                      ),
                      shape: new CircleBorder(),
                      elevation: 2.0,
                      fillColor: Colors.white,
                      padding: const EdgeInsets.all(15.0),
                    ),
                    RawMaterialButton(
                      onPressed: galleryMethod,
                      child: new Icon(
                        Icons.image,
                        color: appColor,
                        size: 35.0,
                      ),
                      shape: new CircleBorder(),
                      elevation: 2.0,
                      fillColor: Colors.white,
                      padding: const EdgeInsets.all(15.0),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      });
}

String getDateFormattedAsDDMMYYYYHHMM(DateTime date) {
  return DateFormat('yyyy-MM-dd hh:mm:ss a').format(date).toString();
}

roundCirclePresent(String text, Color color, TextStyle textStyle) {
  return Container(
    alignment: Alignment.center,
    decoration: BoxDecoration(
      shape: BoxShape.circle,
      color: color,
    ),
    padding: EdgeInsets.all(
      10,
    ),
    child: Container(
      child: Text(
        text,
        style: textStyle,
      ),
    ),
  );
}

roundCircle(String text, Color color, TextStyle textStyle) {
  return Container(
    alignment: Alignment.center,
    decoration: BoxDecoration(
      shape: BoxShape.circle,
      color: color,
    ),
    padding: EdgeInsets.all(
      6,
    ),
    child: Container(
      child: Text(
        text,
        style: textStyle,
      ),
    ),
  );
}

snackBar(String name, MaterialColor color, IconData icon) {
  return SnackBar(
    duration: Duration(
      milliseconds: 2000,
    ),
    backgroundColor: color.withOpacity(
      0.9,
    ),
    content: Row(
      children: [
        Icon(
          icon,
          color: white,
        ),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.only(
              left: 10.0,
            ),
            child: Text(
              name,
              style: TextStyle(
                fontSize: 20,
                color: white,
              ),
            ),
          ),
        ),
      ],
    ),
  );
}

String twoDigits(int n) {
  if (n >= 10) return '$n';
  return '0$n';
}

String formatBySeconds(Duration duration) =>
    twoDigits(duration.inSeconds.remainder(60));

String formatByMinutes(Duration duration) {
  String twoDigitMinutes = twoDigits(duration.inMinutes.remainder(60));
  return '$twoDigitMinutes:${formatBySeconds(duration)}';
}

String formatByHours(Duration duration) {
  return '${twoDigits(duration.inHours)}:${formatByMinutes(duration)}';
}

imagePicker(BuildContext context, ImgSource source) {
  return ImagePickerGC.pickImage(
    context: context,
    source: source,
    galleryText: Text(
      'Gallery',
      style: TextStyle(color: appColor),
    ),
    cameraText: Text(
      'Camera',
      style: TextStyle(color: appColor),
    ),
    galleryIcon: Icon(
      Icons.photo,
      color: appColor,
    ),
    cameraIcon: Icon(
      Icons.camera_alt,
      color: appColor,
    ),
  );
}

setAssetImage(image){
  return image == "" || image ==  null || image == "null" ? AssetImage('assets/help-lady168186.png') : AssetImage(image);
}