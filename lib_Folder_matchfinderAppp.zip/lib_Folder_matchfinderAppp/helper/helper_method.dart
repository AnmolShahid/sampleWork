import 'dart:io';
import 'package:dio/dio.dart';
import 'package:cookie_jar/cookie_jar.dart';
import 'package:dio_cookie_manager/dio_cookie_manager.dart';
import 'package:dio_http_cache/dio_http_cache.dart';
import 'package:matchfinder/const/const.dart';

import 'package:matchfinder/utils/url.dart';

class HelperMethod{
  static Dio dio = Dio();

  static resetMail(String email) async {
    final response = await dio.post(
      UrlLinks.resetUrl, queryParameters: {"marsid": email,},
    );
    return response;
  }

  static getSession() async {
    var cookieJar = CookieJar();
    dio.interceptors.add(CookieManager(cookieJar));
    List<Cookie> value = cookieJar.loadForRequest(Uri.parse(UrlLinks.loginUrl));
    if (value.isNotEmpty) {
      print(value);
      if (value[0].name == 'JSESSIONID' && value[0].path == '/matrimony/') {
        return value[0].value;
      }
    }
  }

  static getDetails() async {
    final getAppraisalsKey = UrlLinks.editAllDetails;
    var cookieJar = CookieJar();
    dio.interceptors.add(CookieManager(cookieJar));
    Response response = await dio.post(getAppraisalsKey);
    return response;
  }

  static getCaste() async {
    final getAppraisalsKey = UrlLinks.getCasteDetails;
    BaseOptions baseOptions = new BaseOptions(
      baseUrl: UrlLinks.baseUrl,
      validateStatus: (status) {
        return status <= 500;
      },
      // connectTimeout: 300,
    );
    dio = new Dio(baseOptions);
    dio.interceptors.add(DioCacheManager(
      CacheConfig(
        baseUrl: UrlLinks.baseUrl,
        defaultMaxAge: Duration(hours: 1),
      ),
    ).interceptor);
    Response response = await dio.get(getAppraisalsKey);
    return response.data['casteList'];
  }

  static getPaymentPackages() async {
    final getAppraisalsKey = UrlLinks.addons;
    var cookieJar = CookieJar();
    dio.interceptors.add(CookieManager(cookieJar));
    Response response = await dio.post(getAppraisalsKey);
    print(response.data);
    return response;
  }

  static get_memberships_Plans() async {
    final getAppraisalsKey = UrlLinks.plans;
    var cookieJar = CookieJar();
    dio.interceptors.add(CookieManager(cookieJar));
    Response response = await dio.post(getAppraisalsKey);
    print(response.data);
    return response;
  }

  static getLoadingPhoto() async {
    final getAppraisalsKey = UrlLinks.lodaingPhoto;
    var cookieJar = CookieJar();
    dio.interceptors.add(CookieManager(cookieJar));
    Response response = await dio.post(getAppraisalsKey);
    print(response.data);
    return response;
  }

  static submitData(String link, query) async {
    var cookieJar = CookieJar();
    dio.interceptors.add(CookieManager(cookieJar));
    Response response = await dio.post(link, queryParameters: query);
    print(response);
    return response;
  }

  static checkoutData(String link) async {
    var cookieJar = CookieJar();
    dio.interceptors.add(CookieManager(cookieJar));
    Response response = await dio.post(link);
    print(response);
    return response;
  }

  signUp({
    String email, String password,String name,
    String lastName, String gender, String day,
    String month, String year, String motherTongue,
    String religion, String cast, String country, String relationShip,
    String countryISD, String phone,})async {

    var cookieJar = CookieJar();
    dio.interceptors.add(CookieManager(cookieJar));
    final response = await dio.post(
      UrlLinks.signUpUrl,
      queryParameters: {
        "emailbd": email,
        "pwordbd": password,
        "firstnamebd": name,
        "lastnamebd": lastName,
        "genderbd": gender,
        "daybd": day,
        "monthbd": month,
        "yearbd": year,
        "mothertonguebd": motherTongue,
        "religionbd": religion,
        "castenamebd": cast,
        "countrybd": country,
        "profilecreatorbd": relationShip,
        "phoneisdbd": countryISD,
        "phonenobd": phone,
      },
    );
    return response;
  }

  login({String email, String password}) async {
    var dio = Dio();
    var cookieJar = CookieJar();
    dio.interceptors.add(CookieManager(cookieJar));
    final response = await dio.post(
      UrlLinks.loginUrl,
      queryParameters: {
        "username": email,
        "password": password,
      },
    );
    return response;
  }

  static getMonth(String month)async{
    final getAppraisalsKey = UrlLinks.systemCodeUrl;
    Response response = await dio.post(getAppraisalsKey, data: FormData.fromMap({"type": month}));
    return response.data['code'];
  }

  static getYear(String year)async{
    final getAppraisalsKey = UrlLinks.systemCodeUrl;
    Response response = await dio.post(getAppraisalsKey, data: FormData.fromMap({"type": year}));
    return response.data['code'];
  }
}

